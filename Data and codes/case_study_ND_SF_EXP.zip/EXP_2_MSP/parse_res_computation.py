
import time
from matplotlib import artist
import numpy as np
import pandas as pd
import copy
from utils import load_json

# # from main import instance_range
# test_range = np.arange(0,5,1)
# #############################
# ##-- specify inputs --##
# net = 'SF'
# #############################


def parse_res (res_name, ins_range):
    # with open(res_name,'r') as f:
    #     for line in f.readlines():
    #         dic = line #string
    # res = eval(eval(dic))
    res = load_json(res_name)

    instance_range = ins_range #np.arange(0,20,1)
    # instance_range = res['setting']['instance_range']
    subsidy_range = res['setting']['subsidy_range']
    fare_range = res['setting']['fare_range']
    demand_ratios = res['setting']['demand_ratios']
    params = res['setting'][0,subsidy_range[0],fare_range[0]]['params']
    data = res['setting'][0,subsidy_range[0],fare_range[0]]['data']
    followers = list(params['A_var'].keys())
    players = ['leader'] + followers

    A_var_set = {a for a_set in params['A_var'].values() for a in a_set}  # decision links
    link_fare, link_flow = {a:{} for a in A_var_set}, {a:{} for a in A_var_set}
    running_time, iter, gap = {}, {}, {}
    for ins_i in instance_range:
        for a in A_var_set:
            for s in subsidy_range:
                for fare in fare_range:
                    link_fare[a][ins_i, s, fare] = {}
                    link_flow[a][ins_i, s, fare] = {}
                    for dr in [1.0]:
                        try:
                            # link_fare[a][ins_i, s, fare] = res['res'][ins_i,s,fare]['link_res'][dr]['fare'][a]
                            # link_flow[a][ins_i, s, fare] = res['res'][ins_i,s,fare]['link_res'][dr]['link_flow'][a]
                            running_time[ins_i, s, fare] = res['res'][ins_i, s, fare]['running_time'][dr]
                            iter[ins_i, s, fare] = res['res'][ins_i, s, fare]['iter'][dr]
                            gap[ins_i, s, fare] = res['res'][ins_i, s, fare]['gap'][dr]
                        except:
                            # print('Reading error: res_name: %s, \ninstance: %s'%(res_name, (ins_i+1)))
                            # print('Resean: the instance is not solved')
                            pass
    
    ErrorList = []
    obj = {player:{} for player in players}
    for player in players:
        for ins_i in instance_range:
            for s in subsidy_range:
                for fare in fare_range:
                    path_res = res['res'][ins_i,s,fare]['path_res']
                    obj[player][ins_i, s, fare] = {}
                    for dr in [1.0]:
                        obj[player][ins_i, s, fare] = res['res'][ins_i,s,fare]['obj_res'][dr][player]
                        try:
                            total_s = sum([path_res[dr]['path_flow'][r,k] * path_res[dr]['subsidy'][r,k] for r in data['ODs'] for k in data['path_idx'][r]])
                           # print('total_s',total_s)
                        except:
                            ErrorList.append((ins_i))
                            pass
    if len(ErrorList) != 0:
        print('\nReading error: res_name: %s, \ninstance: %s'%(res_name, (ins_i+1)))
        print('Resean: the instance is not solved')

    rt = [running_time[i,subsidy_range[0],fare_range[0]] for i in instance_range]
    ave_running_time = np.mean(rt)
    return link_fare, link_flow, obj,  running_time, iter,gap, ave_running_time

def parse_res_computation(ins_range, net):

    ## specify net configurations ##
    if net == 'SF':
        from params_SF import params
    elif net == 'ND':
        from params_ND import params
    else:
        print('the params_%s file is not found'%net)

    # branch_rules = ['max_violation','fmax_fmin_gcap','fmax_gcap_fmin','gcap_fmax_fmin']
    
    #brs = ['max_violation_DF_False_GS_False_%s'%params['paral_len'],'max_violation_DF_True_GS_True_%s'%params['paral_len'],'fmax_fmin_gcap_DF_False_GS_False_%s'%params['paral_len'],'fmax_fmin_gcap_DF_True_GS_True_%s'%params['paral_len']]
    #col_names = ['benchmark','BB_DH_GS','BB_fmax','BB_fmax_DH_GS']
    
    #---algo_MNPP
    #brs = ['max_violation_DF_True_GS_True_GS_%s'%params['paral_len'],'max_violation_DF_True_GS_True_s-param_%s'%params['paral_len'],'max_violation_DF_True_GS_True_f-param_%s'%params['paral_len'],'max_violation_DF_True_GS_True_MC_f-param_%s'%params['paral_len']]
    #col_names = ['GS', 's-param', 'f-param', 'MC_f-param'] 
    
    #---algo_MNPP2
    brs = ['max_violation_DF_True_GS_True_GS_%s'%params['paral_len'],'max_violation_DF_True_GS_True_GS_MC_%s'%params['paral_len'],'max_violation_DF_True_GS_True_GS_f_%s'%params['paral_len'],'max_violation_DF_True_GS_True_GS_MC_f_%s'%params['paral_len']]
    col_names = ['GS', 'GS_MC', 'GS_f', 'GS_MC_f']
    
    df = pd.DataFrame()
    df_obj = pd.DataFrame()
    for idx in range(len(brs)):
        br = brs[idx]
    # for br in brs:
        # cols_name = [(br,cols) for cols in ['Iteration','Time','Obj','Gap']]
        cols_name = [(col_names[idx],cols) for cols in ['Iteration','Time','Obj','Gap']]

        out = []
        out_obj = []
        info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
        res = r'res/%s/json/results_%s.txt'%(net,info)
        link_fare, link_flow, obj, running_t, iter, gap, ave_running_time = parse_res(res, ins_range)
        cols_name_obj = [(col_names[idx],cols) for cols in obj.keys()]

        keys = list(obj['leader'].keys())
        _, s, f = keys[0]
        dr = 1.0
        # for i in np.arange(0,params['num_of_instances'],1):
        for i in ins_range: #np.arange(0,20,1):
            out.append([iter[i,s,f], running_t[i,s,f], obj['leader'][i,s,f], gap[i, s, f]*100]) # percentage
            out_obj.append([obj[foll][i,s,f] for foll in obj.keys()])
        df = pd.concat([df,pd.DataFrame(out,columns=cols_name)],axis=1)
        df_obj = pd.concat([df_obj,pd.DataFrame(out_obj,columns=cols_name_obj)],axis=1)

    df_ = copy.deepcopy(df)
    df_.index = np.arange(1, len(df_) + 1)
    df_.loc['Sum'] = df.sum(axis=0)
    df_.loc['Ave'] = df.mean(axis=0)
    # df_.loc['Median'] = df.median(axis=0)
    df_.loc['Std'] = df.std(axis=0)
    ##-- deal with obnoraml values: 0 in Obj and 10**4 in Gap
    for br in brs:
        for ab_val, col in zip([0,10**6],['Obj','Gap']):
            temp = list(df[col_names[idx],col].values)
            if ab_val in temp:
                temp = [i for i in temp if i != ab_val]
                for metric, stat in zip(['Sum','Ave','Std'],[np.sum, np.mean, np.std]):
                    df_[br,col].loc[metric] = stat(temp)
                print('abnormal value %s in %s is removed'%(ab_val,br))

    df_.columns = pd.MultiIndex.from_tuples(df.columns, names=['Branching rule','Instance'])
    df_.to_csv('res/%s/json/results_%s.csv'%(net,net))
    print(df_)

    df_obj.columns = pd.MultiIndex.from_tuples(df_obj.columns, names=['Branching rule','Instance'])
    df_obj.to_csv('res/%s/json/results_%s_obj.csv'%(net,net))


# parse_res_computation([0], 'ND')

###  plot the profits
"""
import seaborn as sns
import matplotlib.pyplot as plt
name_ = ['max_violation','max_violation_DF_GS','fmax_fmin_gcap','fmax_fmin_gcap_DF_GS']

plt.rcParams['font.size'] = '14'
# colors = {1:'pink', 2:'lightblue',3:'lightgreen',4:'lightcoral'}
colors = ['pink', 'lightblue','lightgreen','lightcoral']
if net == 'ND':
    ylim = [2.5*1e5, 5.8*1e5]
if net == 'SF':
    ylim = [2.3*1e5, 4*1e5]
i=0
for br in brs:
    data=df_obj[br]
    opers = [oper for oper in obj.keys() if oper != 'leader']
    data_ = data[opers]
    plt.figure(figsize=(3.5,4))
    labels_ = [str(oper) for oper in obj.keys() if oper != 'leader']
    box = plt.boxplot(data_.T, patch_artist=True)
    for patch, color in zip(box['boxes'], colors[0:len(opers)]):
        patch.set_facecolor(color)
    # plt.boxplot(data_.T, patch_artist=True, boxprops={'facecolor':{'pink', 'lightblue'}})#colors[0:len(opers)]})
    x_ticks = ['Oper %s'%oper for oper in opers]
    plt.xticks(np.arange(1,len(opers)+1),x_ticks)
    plt.ylabel('Profit (\$)')
    # plt.ylim(ylim)
    ax = plt.gca()
    ax.ticklabel_format(style='sci', scilimits=(-1,2), axis='y')
    plt.tight_layout()
    plt.savefig('res/%s/fig/%s_obj_bp.png'%(net,name_[i]))
    i+=1
"""


