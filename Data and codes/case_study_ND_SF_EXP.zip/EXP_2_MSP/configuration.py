
import numpy as np
import ujson
from get_net_data import get_net_data
import os
from copy import deepcopy
import itertools

def instance_generator(base_fare, oper_cost, COV, num, folder_json):
    np.random.seed(2022)
    instances = {'base_fare':{},'oper_cost':{}}
    for key, val in zip(['base_fare','oper_cost'],[base_fare, oper_cost]):
        for i in range(num):
            instances[key][i] = {}
            for type, val_ in val.items():
                instances[key][i][type] = { i_: np.random.normal(val[type][i_], COV*val[type][i_]) for i_ in val_.keys()}
    with open('%s/instances.txt'%folder_json, 'w') as json_file:
        json_file.write(ujson.dumps(str(instances)))
    print('-'*10, 'instances were generated and saved', '-'*10)
    return (instances)


def check_link_set(A_var_set):
    common_links = {}
    folls = list(A_var_set.keys())
    for pair in itertools.combinations(folls,2):
        com_links = A_var_set[pair[0]] & A_var_set[pair[1]]
        if com_links != set():
            common_links[pair] = com_links
    return (common_links)


def net_config(data, params):
    coef_G = params['coef_G']  ## g_cost of the reference mode: proportional to the mean g_cost; the smaller, more competitive
    coef_U = params['coef_U']  ## utility of the reference mode: proportional to the mean utility; the bigger, more competitive
    base_fare = params['base_fare'] ## base fare of followers (per unit time or distance)
    oper_cost = params['oper_cost'] ## operational cost of followers (per unit time or distance)
    
    ## -- settings of links of followers -- ##
    A_foll = deepcopy(params['A_var'])
    ## -- set links to followers
    A_foll_others =  data['links'] - set(link for link_set_ in A_foll.values() for link in link_set_)
    A_foll[0] = [link for link in A_foll_others]
    data['A_foll'] = A_foll
    ## -- mapping links to follower
    link_of_foll = {}
    for foll_, link_set_ in A_foll.items():
        for link in link_set_:
            link_of_foll[link] = foll_

    ## -- Calculate the basic demand proportion of each path -- ##
    ## -- base fare and operation cost of links: link-based or follower-based
    if params['oper_flag'] == 'link_based':
        F_a = {link: base_fare['link_based'][link] * data['link_dist'][link] for link in data['links']}
        oper_cost_a = {link: oper_cost['link_based'][link]  * data['link_dist'][link] for link in data['links']}
    else:
        F_a = {link: base_fare['foll_based'][ link_of_foll[link] ] * data['link_dist'][link] for link in data['links']}
        oper_cost_a = {link: oper_cost['foll_based'][ link_of_foll[link] ] * data['link_dist'][link] for link in data['links']}
    # print('-'*30,'\n','the base fare of each link F_a: \n',F_a, '\n','-'*30)
    
    ## -- g_cost: path-based
    G = {}
    for OD in data['ODs']:
        for path in data['path_idx'][OD]:
            G[(OD, path)] = sum(F_a[link] for link in data['path_data']['links_of_path'][OD][path]) + params['beta']*data['path_data'][OD][path]['travel_time']
    #print('-'*30,'\n','the generalized cost of each path G: \n',G, '\n','-'*30)
    
    ## -- base demand proporttion -- linear demand spliting
    P_rk = {}
    for OD in data['ODs']:
        G_list = [ G[(OD, path)] for path in data['path_idx'][OD] ]
        OD_utility = coef_U * max(G_list)
        G_refer = coef_G * np.mean(G_list)
        sum_net_utility = sum([ (OD_utility-G[(OD, path)]) for path in data['path_idx'][OD] ])
        for path in data['path_idx'][OD]:
            P_rk[(OD, path)] = (OD_utility - G[(OD, path)]) / (sum_net_utility + (OD_utility - G_refer))
    #print('-'*30,'\n','the demand proportion of each path P_rk: \n',P_rk, '\n','-'*30)
    B = {} # A_r^k
    for OD in data['ODs']:
        for path in data['path_idx'][OD]:
            B[OD, path] = P_rk[(OD, path)] + params['alpha'] * sum(F_a[link] for link in data['path_data']['links_of_path'][OD][path])

    ### --- setting bounds of decision vars
    lb_s, ub_s = {}, {}  ## path_based subsidy
    pt_paths = {OD:[] for OD in data['ODs']} ## consists of pt links
    for OD in data['ODs']:
        for path in data['path_idx'][OD]:
            lb_s[(OD, path)] = data['bounds']['subsidy'][0]
            ub_s[(OD, path)] = data['bounds']['subsidy'][1]
            ###################### setting of path subsidies  ##############################
            if len(set([31,21,61])&set(data['path_data'][OD][path]['path'])) != 0 or len(data['path_data'][OD][path]['path'])==2:
                pt_paths[OD].append(path)
            else: ## non-pt paths
                if params['s_pt']==True:
                    ub_s[(OD, path)] = 0
            ###################### setting of path subsidies  ##############################



    A_var_set = {a for a_set in params['A_var'].values() for a in a_set}
    lb_f, ub_f = {}, {}  ## link-based fare
    for link in A_var_set:
        ##################### setting of link fares  ###############################
        lb_f[link] = data['bounds']['fare'][0]
        ub_f[link] = data['bounds']['fare'][1]
        ### unit distance-based fare
        # lb_f[link] = data['bounds']['fare'][0]*F_a[link]
        # ub_f[link] = data['bounds']['fare'][1]*F_a[link]
        ###################### setting of link fares  ##############################
    for link in data['links']:
        if link not in A_var_set: ## non-dicision links
            lb_f[link] = F_a[link]
            ub_f[link] = F_a[link]+1e-6
        if len(params['not_foll']) != 0: 
            for not_foll in params['not_foll']: ## dicision links
                for link in A_foll[not_foll]:
                    lb_f[link] = F_a[link]   ## fix the fare bound closing to a constant Fa
                    ub_f[link] = F_a[link]+1e-6
    #########################################################################################
    data['A_foll'] = A_foll
    data['A_var'] = params['A_var']
    data['B'] = B
    data['ub_s'], data['lb_s'], data['ub_f'], data['lb_f'] = ub_s, lb_s, ub_f, lb_f
    data['followers'] = list(params['A_var'].keys())
    data['not_foll'] = params['not_foll']
    data['G'] = G
    data['link_of_foll'] = link_of_foll
    data['F_a'] = F_a
    data['gamma_a'] = oper_cost_a  ### gamma_i in the paper
    data['P_rk'] = P_rk
    data['pt_paths'] = pt_paths
    ##--- checking conditions of assumption 1 and theorem 1 ---###
    ### assumption 1
    # fea_con_1 = []
    # for a in data['links']:
    #     term2 = data['capacity'][a] - (sum(sum(data['delta'][a,r,k]*data['demand'][r]*data['P_rk'][r,k] for k in data['path_idx'][r]) for r in data['ODs']))
    #     if term2 >= 0:
    #         fea_con_1.append(1)
    #     else:
    #         fea_con_1.append(0)
    # print('feasible_condition of assumption 1: ',fea_con_1)
    # if sum(fea_con_1) != len(fea_con_1):
    #     print('the problem is in assumption 1 in net_config.py')

    # ### theorem 1
    fea_con_2 = []
    for a in data['links']:
        term1 = sum(sum(data['delta'][a,r,k]*data['demand'][r]*(params['alpha']*(sum(data['F_a'][b]*(1 + data['delta'][b,r,k]) for b in data['path_data']['links_of_path'][r][k]))) for k in data['path_idx'][r]) for r in data['ODs']) # fopt
        term2 = data['capacity'][a] - (sum(sum(data['delta'][a,r,k]*data['demand'][r]*data['P_rk'][r,k] for k in data['path_idx'][r]) for r in data['ODs']))
        if term1 <= term2:
            fea_con_2.append(1)
        else:
            fea_con_2.append(0)
    #print('feasible_condition of theorem 1: ',fea_con_2)
    #if sum(fea_con_2) < len(data['capacity']):
    #    print('the problem is in theorem 1 in net_config.py')

    return (data)





def process_net_data(instance_i, subsidy_ub, fare_ub, demand_r, params):
## define paths to save results ##
    folder_fig = 'res/%s/fig'%(params['net'])
    folder_json = 'res/%s/json'%(params['net'])
    for folder in [folder_fig, folder_json]:
        if not os.path.exists(folder):
            os.makedirs(folder)

    ## check link operators: no common links of different followers
    common_links =  check_link_set(params['A_var'])
    if common_links != {}:
        print('links are operated by multiple followers. followers: common links %s'%(common_links))
        return (None, None)
    ## get the base net data
    data = get_net_data(net=params['net'], path='net_data/', K=params['K'])
    for OD, demand_ in data['demand'].items():
        data['demand'][OD] = demand_ * demand_r

    ## load instances
    if params['regenerate_instances'] == False:
        try:
            #print('-'*10,'loading follower intances','-'*10)
            with open(r'%s/instances.txt'%folder_json,'r') as f:
                for line in f.readlines(): 
                    dic = line #string
            instances = eval(eval(dic))
        except:
            #print('-'*10,'no follower intance was found and generating instances','-'*10)
            instances = instance_generator(params['base_fare'], params['oper_cost'], COV=params['COV'], num=params['num_of_instances'], folder_json=folder_json)
    else:
        #print('-'*10,' regenerating instances','-'*10)
        instances = instance_generator(params['base_fare'], params['oper_cost'], COV=params['COV'], num=params['num_of_instances'], folder_json=folder_json)
    params['oper_cost'] = instances['oper_cost'][instance_i]
    params['base_fare'] = instances['base_fare'][instance_i]
    
    ## bound settings
    data['bounds'] = {'fare': [0, fare_ub], 'subsidy': [0, subsidy_ub] }

    ## network configuration
    data = net_config(data, params)
    return (data, params)



