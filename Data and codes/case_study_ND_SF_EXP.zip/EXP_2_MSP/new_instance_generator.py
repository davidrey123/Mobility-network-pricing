import ujson
import os
import numpy as np

#### specify net and instance you want to regenerate ####
net = 'ND'
ins_list = [2] ## please note that the index starts from 0, index 0 for instance 1


folder_fig = 'res/%s/fig'%net
folder_json = 'res/%s/json'%net
for folder in [folder_fig, folder_json]:
    if not os.path.exists(folder):
        os.makedirs(folder)
## specify net configurations ##
if net == 'SF':
    from params_SF import params
elif net == 'ND':
    from params_ND import params
else:
    print('the params_%s file is not found'%net)

### only regenerate the instances for the given range
def new_instance_generator(base_fare, oper_cost, COV, ins_list, folder_json):
    file = '%s/instances.txt'%folder_json
    with open(file,'r') as f:
        for line in f.readlines():
            dic = line #string
    instances = eval(eval(dic))
    np.random.seed(2022)
    # instances = {'base_fare':{},'oper_cost':{}}
    for key, val in zip(['base_fare','oper_cost'],[base_fare, oper_cost]):
        for i in ins_list:
            instances[key][i] = {}
            for type, val_ in val.items():
                instances[key][i][type] = { i_: np.random.normal(val[type][i_], COV*val[type][i_]) for i_ in val_.keys()}
    with open('%s/instances.txt'%folder_json, 'w') as json_file:
        json_file.write(ujson.dumps(str(instances)))
    print('-'*10, 'instances were generated and saved', '-'*10)
    return (instances)

new_instance_generator(params['base_fare'], params['oper_cost'], params['COV'], ins_list, folder_json)