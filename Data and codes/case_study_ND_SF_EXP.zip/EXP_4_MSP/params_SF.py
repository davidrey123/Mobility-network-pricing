##***********************************##
## change values in not_foll to set different inactive followers.
## not_foll = [3,4], [4], []; two MSPs, three MSPs and four MSPs
##***********************************##

##  basic settings  ##
params = {
    ##-- net related --##
    'net': 'SF',
    'A_var': {
        ## single direction
        1: { (1,2),(2,6),(6,8),(8,16),(16,17),(17,19),(19,20),},
        2: { (1,3),(3,12),(12,13),(13,24),(24,21),(21,20),},
        3: { (4,5),(5,9),(9,8),(8,7),(7,18),(18,16),(16,10),(10,11),(11,12),(12,3),(3,4),},
        4: { (20,21),(21,24),(24,13),(13,12),(12,11),(11,10),(10,16),(16,18),},
    },
    'not_foll':[], # followers that are without decisions #[3,4] #[4]
    ##-- how competitive of reference mode is to the mean cost of that of all paths of a OD pair
    'coef_G': 0.5, # 1/2  ## the smaller, the more competitive, 1/3 
    'coef_U': 1.5,  ## 1.5 the value of utility of path, OD-based, coef_U * max(path_gcost)
    'beta': 120/60, # value of time 
    'alpha': 0.002, # 0.008 0.0005，0.0001 works for the small SF witk K=5. time is around 1700S, 0.0005
    'epsilon': 0.0, #1e-5, ## penalty in leader's obj. sometimes needs to change
    ## assume followers: {0: bus, 1: auto, 2: ride-sourcing, 3: others}
    'oper_flag':'foll_based',
    'base_fare':{
        'link_based': {},
        'foll_based': { 0: 1.0, 1: 2.0, 2: 6.0, 3: 4.0, 4: 3.0 },
    },
    'oper_cost':{
        'link_based': {},
        'foll_based': { 0: 0.5, 1: 1.0, 2: 3.0, 3: 5.0, 4: 7.0 }, #, 0: 0.5, 1: 1.0, 2: 3.0, 3: 2.0, 4: 1.5
        },
    'K': 3, # number of K-shortest paths

    ##-- instance related --##
    'COV': 0.1, # the coefficiency of variation of operational cost 0.01
    'regenerate_instances': False, # if the oper_cost is changed, turn it to True
    'num_of_instances': 20,

    ### params in SP net ###
    's_pt': False, #subsidy only for path associated with public transport
    'obj_pt': False, # maximize riderships of PT


    ##***********************************##
    ## below are parameters needed to be tuned
    ## you might also need to change the alpha above
    ## note that using a tighter McCormick envelope in model.py also helps sometimes
    ##***********************************##

    ## early condition to stop DF: if the max(UB of new trees) < 1/2 * UB_of_all(active)_trees, stop DF 
    ##-- computation related --##
    'paral_len': 1, # num of nodes branching and updating simultaneously
    'GS': True,
    'GS_freeze': 30,
    'GS_tri_len': 0.1, # (min violated vars / total vars) < GS_trigger len
    'GS_tri_skew': 1, # skewness to trigger GS
    'GS_tri_kurt': 1, # kurtosis to trigger GS
    'depth_first': True, # DF for short
    'DF_depth': 5, # num of branching steps in depth, 15
    'DF_freeze': 0, # num of steps to freeze the DF search (avoid exploring too far)
    'timelimit':3600,

    ##-- partition numbers in McCormick envelopes --##
    ## loaction: solve_RNDP_MC in utils.py and maybe in model.py if using the tighter McCormick envelopes
    'num_par_prk': 5,
    'num_par_s':5,

    'budget': 5e5, # budget for subsidy, opt cost between 1e5 and 1e6

}



