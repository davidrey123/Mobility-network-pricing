import time
import copy
import numpy as np
from docplex.mp.model import Model
import pandas as pd
from collections import deque

#---check complementarity slackness conditions and determine branching variable
def check_CS(data,SP,CStype,tol,branching_rule):
    #A_var_set = {a for a_set in data['A_var'].values() for a in a_set}
    A = data['links']
    bilevelopt = True
    maxviolation = 0.0
    list_violated = {cs:[] for cs in CStype}
    for a in A:
        for cs in CStype:
            if SP['CS'][a][cs] > tol:
                list_violated[cs].append((a,SP['CS'][a][cs]))
                bilevelopt = False
            if SP['CS'][a][cs] > maxviolation:
                maxviolation = SP['CS'][a][cs]
                bvar = (a,cs) #bvar is a link and a type
    
    violated_len = [len(list_violated[cs]) for cs in CStype]
    if sum(violated_len)==0:
        bilevelopt = True
        print('found a solution without violating CS')
    # print('bilevelopt',bilevelopt)
    
    if bilevelopt == True:
        return bilevelopt,None,violated_len
    elif branching_rule == 'max_violation':
        return bilevelopt,bvar,violated_len

    elif branching_rule == 'fmax_fmin_gcap':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['fmin']) > 0:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')
        else:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        return bilevelopt,bvar,violated_len
    
    elif branching_rule == 'fmax_gcap_fmin':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')        
        return bilevelopt,bvar,violated_len

    elif branching_rule == 'gcap_fmax_fmin':        
        if len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')                
        elif len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')            
        return bilevelopt,bvar,violated_len
    
    else:
        print('no valid branching rule specified')
        return bilevelopt,None,None
    
     
#---node selection rule: best bound first search
def node_selection(candidates,tree):
    temp = []
    for i in candidates:
        #temp.append([i, tree[tree[i]['parent']]['UB']])
        temp.append([i, tree[tree[i]['parent']]['UB'], tree[i]['depth']])
    temp = sorted(temp, key=lambda x: (x[1], x[2]), reverse=True)
    out = []
    for item in temp:
        out.append([tree[item[0]], item[0]])
    return(out)

#---node selection rule: best bound first search
def node_selection_DF(candidates,tree):
    temp = []
    for i in candidates:
        #temp.append([i, tree[i]['depth']])
        temp.append([i, tree[i]['depth'], tree[tree[i]['parent']]['UB']])
    temp = sorted(temp, key=lambda x: (x[1], x[2]), reverse=True)
    out = []
    for item in temp:
        out.append([tree[item[0]], item[0]])
    return(out)

#---branching rule: branch on max violated CS constraint
def branch(SP,can,tree,bvar):
    
    cnt = len(tree)-1
    tree[can] = copy.deepcopy(SP)
    nd = SP['depth'] + 1
    if bvar[1] == 'gcap': ## type of CS
        #print('branch on gcap type')    
        tree[can]['children'].append(cnt+1)
        cap0 = copy.deepcopy(SP['cap0'])
        cap0.append(bvar[0])
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':cap0,'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        lbd0 = copy.deepcopy(SP['lbd0'])
        lbd0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':SP['cap0'],'lbd0':lbd0,'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmin':
        #print('branch on fmin type')        
        tree[can]['children'].append(cnt+1)
        fmin0 = copy.deepcopy(SP['fmin0'])
        fmin0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':fmin0,'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        nul0 = copy.deepcopy(SP['nul0'])
        nul0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':nul0,
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmax':
        #print('branch on fmax type')
        tree[can]['children'].append(cnt+1)
        fmax0 = copy.deepcopy(SP['fmax0'])
        fmax0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':fmax0,'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        nuu0 = copy.deepcopy(SP['nuu0'])
        nuu0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'depth':nd,'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':nuu0,'s':{},'f':{},'CS':{}}  
    return tree

#---relaxed single-level reformulation
def solve_RNDP(data,params,SP,CStype,tol):
    RNDP = Model(name='RNDP', log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    us = data['ub_s']
    ls = data['lb_s']
    uf = data['ub_f']
    lf = data['lb_f']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    beta = params['beta']
    al = params['alpha']
    budget = params['budget']

    folls  = list(data['A_var'].keys()) # only followers with decision links. foll 0 not included

    s = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    lbd = {a: RNDP.continuous_var() for a in A}
    f = {a: RNDP.continuous_var() for a in A}
    nul = {a: RNDP.continuous_var() for a in A}
    nuu = {a: RNDP.continuous_var() for a in A}
    
    # for foll in folls:
    #     for a in data['A_var'][foll]:
    #         print(foll,a,lf[a],uf[a])
    
    #print('no decision links', len(A_foll[0]), A_foll[0])
    for a in A_foll[0]:
        #print(a,data['F_a'][a])
        RNDP.add_constraint(f[a] == data['F_a'][a])

    for r in R:
        RNDP.add_constraint(sum(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(s[r,k] <= us[r,k])
            RNDP.add_constraint(s[r,k] >= ls[r,k])
            
    for foll in folls:
        for a in params['A_var'][foll]:
            temp = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a]
                                         - sum(f[b] for b in L[r][k] if b != a) - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in params['A_var'][foll])))
                                        for k in P[r]) for r in R)
            RNDP.add_constraint(temp - nuu[a] + nul[a] == 0)

    #################################################################################
    # ### Relaxation of z = s*prop in budget: McCormick evelope
    # z = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    # for r in R:
    #     for k in P[r]:
    #         prop_rk = B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k]))
    #         ub_prk = B[r,k] + al*us[r,k]
    #         lb_prk = max(0, B[r,k] - al*sum([uf[a] for a in L[r][k]]) )
    #         RNDP.add_constraint(z[r,k] >= 0 + s[r,k]*lb_prk - 0)
    #         RNDP.add_constraint(z[r,k] >= us[r,k]*prop_rk + s[r,k]*ub_prk - us[r,k]*ub_prk)
    #         RNDP.add_constraint(z[r,k] <= us[r,k]*prop_rk + s[r,k]*lb_prk - us[r,k]*lb_prk )
    #         RNDP.add_constraint(z[r,k] <= s[r,k]*ub_prk + 0 - 0)
    # RNDP.add_constraint(sum(z[r,k]*Q[r] for r in R for k in P[r]) <= budget)

    ##### using the quadratic constraint
    #RNDP.add_constraint(sum(Q[r]*s[r,k] * (B[r,k] + al*(s[r,k] - sum([uf[a] for a in L[r][k]]))) for r in R for k in P[r]) <= budget)

    #################################################################################
    ### GNEP has mutiple equilibria.
    ### Different partitions of McCormick envelope will lead to different equilibria
    #################################################################################
    ### Piecewise McCormick evelope: relaxation of z = s*prop in budget
    #### change the number of partitions can change the number of equilibria
    # num_par_prk, num_par_s = 3,3 ## (i,j)
    # num_par_prk, num_par_s = 6,6 ## (i,j)
    num_par_prk, num_par_s = 10,5 ## (i,j)
    pars = [(i,j) for i in range(num_par_prk) for j in range(num_par_s)]
    z = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    aux_s = {(r,k): RNDP.continuous_var_dict(pars) for r in R for k in P[r]}
    aux_prop = {(r,k): RNDP.continuous_var_dict(pars) for r in R for k in P[r]}
    bi_idx = {(r,k): RNDP.binary_var_dict(pars) for r in R for k in P[r]}

    for r in R:
        for k in P[r]:
            prk_l = [((B[r,k]+al*us[r,k])/num_par_prk)*i for i in range(num_par_prk)]
            prk_u = [((B[r,k]+al*us[r,k])/num_par_prk)*i for i in range(1,num_par_prk+1)]
            s_l = [(us[r,k]/num_par_s)*j for j in range(num_par_s)]
            s_u = [(us[r,k]/num_par_s)*j for j in range(1,num_par_s+1)]

            RNDP.add_constraint(z[r,k] >= sum([aux_prop[r,k][i,j]*s_l[j] + prk_l[i]*aux_s[r,k][i,j] - prk_l[i]*s_l[j]*bi_idx[r,k][i,j]  for i in range(num_par_prk) for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] >= sum([aux_prop[r,k][i,j]*s_u[j] + prk_u[i]*aux_s[r,k][i,j] - prk_u[i]*s_u[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] <= sum([aux_prop[r,k][i,j]*s_l[j] + prk_u[i]*aux_s[r,k][i,j] - prk_u[i]*s_l[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] <= sum ([aux_prop[r,k][i,j]*s_u[j] + prk_l[i]*aux_s[r,k][i,j] - prk_l[i]*s_u[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            prop_rk = B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(prop_rk  == sum(aux_prop[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)))
            RNDP.add_constraint(s[r,k] == sum(aux_s[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)))
            RNDP.add_constraint(sum([bi_idx[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)]) == 1)
            for i in range(num_par_prk):
                for j in range(num_par_s):
                    RNDP.add_constraint( prk_l[i]*bi_idx[r,k][i,j] <= aux_prop[r,k][i,j] )
                    RNDP.add_constraint( prk_u[i]*bi_idx[r,k][i,j] >= aux_prop[r,k][i,j] )
                    RNDP.add_constraint( s_l[j]*bi_idx[r,k][i,j] <= aux_s[r,k][i,j] )
                    RNDP.add_constraint( s_u[j]*bi_idx[r,k][i,j] >= aux_s[r,k][i,j] )
    
    RNDP.add_constraint(sum(z[r,k]*Q[r] for r in R for k in P[r]) <= budget)
    ################################################################################

    
    ############# flow conservation
    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a])
        RNDP.add_constraint(lbd[a] >= 0)
        RNDP.add_constraint(f[a] <= uf[a])
        RNDP.add_constraint(f[a] >= lf[a])
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        


        # #-----newly added constraints to ensure obj > 0   
        # RNDP.add_constraint(f[a] >= ga[a])





    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['cap0']:
        RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R) == C[a])
    for a in SP['lbd0']:
        RNDP.add_constraint(lbd[a] == 0)
    for a in SP['fmin0']:
        RNDP.add_constraint(f[a] == lf[a])
    for a in SP['nul0']:
        RNDP.add_constraint(nul[a] == 0)
    for a in SP['fmax0']:
        RNDP.add_constraint(f[a] == uf[a])
    for a in SP['nuu0']:
        RNDP.add_constraint(nuu[a] == 0)
        
    #print('fmax0',SP['fmax0'])
    #print('nuu0',SP['nuu0'])
    
    #print('fmin0',SP['fmin0'])
    #print('nul0',SP['nul0'])

    #print('cap0',SP['cap0'])
    #print('lbd0',SP['lbd0'])    
    
    ### --- objective function
    proportion = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R)
    ### --- obj 2: penalized obj
    # pen = 1e-4*sum(sum(s[r,k]*Q[r]*(B[r,k] + al*s[r,k] ) for k in P[r]) for r in R )
    # leader_obj = leader_obj - pen
    ### --- obj 3: maximize ridership consitsts pt paths
    ###################### setting of path subsidies  ##############################
    if params['RS'] == 'PT':
        leader_obj = sum(sum(Q[r]*proportion[r,k] for k in data['pt_paths'][r]) for r in R)
    ###################### setting of path subsidies  ##############################
    ### --- obj 4: penalized obj
    # pen = 1e-2*sum(sum(s[r,k]*Q[r]*(B[r,k] + al*s[r,k] ) for k in P[r]) for r in R )
    # leader_obj = leader_obj - pen
    # RNDP.add_constraint(sum(sum(Q[r]*proportion[r,k] for k in data['pt_paths'][r]) for r in R) >= 9.2e3)





    RNDP.maximize(leader_obj)

    # print(RNDP.parameters)
    RNDP.parameters.threads = 1
    RNDP.parameters.timelimit = 90

    RNDP.solve()
    
    #---changed status rule: 
    # feasible means a feasible solution has been found (possibly optimal)
    # infeasible means no feasible solution has been found
    
    feas = False
    if RNDP.get_cplex().solution.get_status() == 107:
        # time limit exceeded but integer sol exist
        feas = True
    elif RNDP.get_cplex().solution.get_status() == 6:
        # solution exists but not proved optimal due to numerical difficulties
        feas = True
    elif RNDP.get_cplex().solution.get_status() == 22:
        # dual problem
        print('dual problem 22')
        feas = False
        return
    elif 'optimal' in RNDP.solve_details.status:
        feas = True        
        
    #print('SP',RNDP.get_cplex().solution.get_status(),RNDP.solve_details.status,feas)        
        
    #if 'optimal' not in RNDP.solve_details.status:
    if feas == False:
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        SP['solve_status'] = 'infeasible' #RNDP.solve_details.status ## update solve status
        return SP
    
    objopt = RNDP.solution.get_value(leader_obj)
    #print('obj   \t%s' %objopt)
  
    # grab the results
    sopt = {(r,k):RNDP.solution.get_value(s[r,k]) for r in R for k in P[r]}
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt = {a:RNDP.solution.get_value(f[a]) for a in A}
    for a in A_foll[0]:
        fopt[a] = data['F_a'][a] # set constant to no-decision links
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A}

    # grab CS status
    gcap, CS = {}, {}
    GNEP = {'cap0':[], 'lbd0':[], 'fmin0':[], 'fmax0':[], 'nul0':[], 'nuu0':[]}
    for a in A:
        gcap[a] = np.abs(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R) - C[a])
        CStemp = {}     
        for cs in CStype:
            if cs == 'gcap':
                CStemp[cs] = gcap[a]*lbdopt[a]
                if CStemp[cs] <= tol:
                    if gcap[a] < lbdopt[a]:
                        GNEP['cap0'].append(a)
                    else:
                        GNEP['lbd0'].append(a)
                #else:
                #    print('x',a,cs)
                    
            elif cs == 'fmin':
                CStemp[cs] = np.abs(fopt[a] - lf[a])*nulopt[a]
                if CStemp[cs] <= tol:
                    if np.abs(fopt[a] - lf[a]) < nulopt[a]:
                        GNEP['fmin0'].append(a)
                    else:
                        GNEP['nul0'].append(a)    
                #else:
                #    print('x',a,cs)                        
                        
            elif cs == 'fmax':
                CStemp[cs] = np.abs(fopt[a] - uf[a])*nuuopt[a]
                if CStemp[cs] <= tol:
                    if np.abs(fopt[a] - uf[a]) < nuuopt[a]:
                        GNEP['fmax0'].append(a)
                    else:
                        GNEP['nuu0'].append(a)  
                #else:
                #    print('x',a,cs)
                        
        CS[a] = CStemp
    
    
    l1 = len(GNEP['cap0']) + len(GNEP['lbd0'])
    l2 = len(GNEP['fmax0']) + len(GNEP['nuu0'])
    l3 = len(GNEP['fmin0']) + len(GNEP['nul0'])
    CSpct = 100.0*(l1+l2+l3)/(3*len(A))
    #print('xxx',l1,l2,l3,CSpct)     
    
    SP['UB'] = objopt
    SP['s'] = sopt
    SP['f'] = fopt
    SP['CS'] = CS
    SP['GNEP'] = GNEP
    SP['solve_status'] = 'feasible' 
    SP['multiplier'] = {'lbd':lbdopt,'nul':nulopt,'nuu':nuuopt}
    link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
    path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(proportion[r,k]) for r in R for k in P[r]}
    SP['link_flow'] = link_flow_opt ## flow on links
    SP['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * link_flow_opt[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers



    SP['path_flow'] = path_flow_opt ## flow on paths
    SP['path_gcost'] = {} ## generalized cost of path
    SP['z']= {(r,k): RNDP.solution.get_value(z[r,k]) for r in R for k in P[r]}
    for r in R:
        for k in P[r]:
            SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]

    return SP

def single_task(data,params, SP, can, CStype,tol):
    if SP['solved'] == False:
        SP = solve_RNDP(data,params,SP,CStype,tol)
        SP['solved'] = True
        #print('solved RNDP')
        #SP['solve_status'] = 'X' #'feasible'
    else:
        print('-----------------------------------not solved?')
        #SP['solve_status'] = 'infeasible'
    return (SP, can)

import multiprocessing
def paral_slove_RNDP(data,params,SP_can_list,CStype,paral_len,tol):
    if paral_len >= 2:
        num_cpu = multiprocessing.cpu_count() # number of cpu
        pool = multiprocessing.Pool(num_cpu)
        # pool = multiprocessing.Pool(8)
        ## inputs for paraller task function
        paral_input = []
        for i in range(min(paral_len,len(SP_can_list))): # if the num of cans is less than paral len
            paral_input.append([data,params,SP_can_list[i][0],SP_can_list[i][1],CStype])
        output = pool.starmap(single_task, paral_input)
        pool.close()
        pool.join()
    else:
        SP, can = single_task(data,params,SP_can_list[0][0],SP_can_list[0][1], CStype,tol) # the one with maximum UB
        output = [[SP, can]]
    return(output)

def projection(data,params,SP):
    ## check the status of roots
    L = data['path_data']['links_of_path']
    proj_status = True
    for r in data['ODs']:
        for k in data['path_idx'][r]:
            croot = (data['B'][r,k]-params['alpha']*sum(SP['f'][a] for a in L[r][k]))**2 + 4*params['alpha']*SP['z'][r,k]
            if croot >=0:
                SP['s'][r,k] = (-data['B'][r,k] + np.sqrt(croot))/(2*params['alpha']) 
                # s2 = (-data['B'][r,k] - np.sqrt(croot))/(2*params['alpha'])
                if SP['s'][r,k] < 0:
                    proj_status = False
            else:
                proj_status = False
                print('Projection error')
    return SP, proj_status

from GS import gauss_seidel
from utils import solve_RNDP_f_parameterized, solve_RNDP_s_parameterized, solve_RNDP_MC

def algo_MNPP(data, params, mode):
# def algo_MNPP2(data, params, mode):
    converged = False
    nit = 0
    gap = 1e4 # 1.0*float('inf')
    tol = 1e-4 #1e-4
    LB, UB = 0, 1e8
    sopt, fopt = {}, {}
    CStype = ['gcap','fmin','fmax']
    tree = {0:{'parent':0,'children':[],'solved':False,'active':True,'LB':None,'UB':1e8,'depth':0,
               'cap0':[],'lbd0':[],'fmin0':[],'nul0':[],'fmax0':[],'nuu0':[],'s':{},'f':{},'CS':{}}}
    candidates = [0]
    t0 = time.time()
    timelimit = params['timelimit']
    obj_bounds = {'lb':[],'ub':[]}
    A = data['links']
    
    branching_rule = data['branching_rule']
    GS = params['GS'] # True, False
    GS_activate = True
    DF_activate = False
    GS_freeze = params['GS_freeze'] 
    n_GS = GS_freeze + 1
    LB_GS = 0
    paral_len = params['paral_len'] # num of nodes to be solved in parallel

    ##### ------------------------------------------------- parameters MC
    # pwMC = {'pw':30, 'tl':30}  # pwMC = {'pw':10, 'tl':30} 
    pwMC = {'pw':11, 'tl':43}  
    
    print('\n---MNPP 2---------------------------------')
    bilevelfeas = False
    depth_flag = 0
    DF_freeze = 0
    new_tree = {}

    ## placeholder
    skew, kurt = deque(np.zeros(5)), deque(np.zeros(5))
    while converged == False: 
        ##---node selection
        if depth_flag < params['DF_depth'] and DF_freeze >= params['DF_freeze'] and DF_activate == True and params['depth_first'] == True:
            SP_can_list = node_selection(new_tree,tree)
            depth_flag += 1
            #print('\n>>>>>> activate depth first search for %s time(s)\n'%(depth_flag))
        else:
            #---select subproblems to explore
            SP_can_list = node_selection(candidates,tree)
            depth_flag = 0
            DF_activate = False
            DF_freeze += 1

        ### trigger conditions for Depth first search
        if len(candidates)>0 and len(new_tree)>0:
            UB_list = [tree[i]['UB'] for i in candidates]
            UB = max(UB_list)
            if len(UB_list) >= 3:
                skew.append(round(pd.Series(UB_list).skew(),2))
                skew.popleft()
                kurt.append(round(pd.Series(UB_list).kurt(),2))
                kurt.popleft()
            if params['depth_first'] == True:
                if abs(skew[-1]) > params['GS_tri_skew'] and abs(kurt[-1]) > params['GS_tri_kurt']:
                    DF_activate = True
                    # Early stop DF
                    if depth_flag >= params['DF_depth'] or max([tree[i]['UB'] for i in new_tree ]) <= np.mean(UB_list):
                        DF_freeze = 0
                        DF_activate = False
                        GS_activate = True
                        #info = 'reaching maximum depth search iters' if depth_flag >= params['DF_depth'] else 'UBs of new trees are low'
                        #print('\n>>>>>> stop depth first search. Reason: %s; freeze depth first search for %s time(s)\n'%(info,params['DF_freeze']))

        SP_can_res = paral_slove_RNDP(data,params, SP_can_list, CStype, paral_len,tol)
        cur_trees = set(tree.keys())
        for SP, can in SP_can_res:
            
            ##---check if all CS conditions are verified
            tree[can] = copy.deepcopy(SP)
            if SP['solve_status'] != 'infeasible':
                ## update tree with new SP
                bilevelfeas,bvar,violated_len = check_CS(data,SP,CStype,tol,branching_rule)
                
                ############################################################
                ## deal with relaxed budget, where CS cons are all satisfied
                ############################################################
                if bilevelfeas == True:
                    
                    #---fix GNEP point and try to find budget feasible LB
                    conv_MC = False
                    conv_f = False
                    SP['LB'] = 0.0
                    
                    R = data['ODs']
                    P = data['path_idx']
                    A = data['links']
                    L = data['path_data']['links_of_path']
                    B = data['B']
                    al = params['alpha']
                    Q = data['demand']
                    prop = {}
                    for r in R:
                        for k in P[r]:
                            prop[r,k] = B[r,k] + al*(SP['s'][r,k] - sum(SP['f'][a] for a in L[r][k]))
                    cost = sum([prop[r,k]*SP['s'][r,k]*Q[r] for r in R for k in P[r]])
                    
                    if cost > params['budget']:
                        print('--> CS satisfied but budget violated',cost)
                        SP['solve_status'] = 'infeasible'
                        
                        #---try tightening relaxation using pwMC
                        if mode == 'GS_MC' or mode == 'GS_MC_f': 
                                              
                            SPMC = copy.deepcopy(SP)
                            SPMC = solve_RNDP_MC(data,params,SPMC,CStype,pwMC,True)
                            
                            if SPMC['solve_status'] == 'feasible' and SPMC['UB'] > SP['LB']:
                                SP = copy.deepcopy(SPMC)
                                # SP['LB'] = SPMC['UB']   #### debugging  not right #### 
                                conv_MC = True
                                print('*** MC: local LB',SPMC['UB'])    
                                          
                        #---try finding LB using f-param
                        if mode == 'GS_f' or mode == 'GS_MC_f':
                            
                            SPf = copy.deepcopy(SP)
                            SPf = solve_RNDP_f_parameterized(data,params,SPf,CStype,True) 
                            
                            if SPf['solve_status'] == 'feasible': # and SPf['UB'] > SP['LB']:    #### debugging  not right ####                              
                                SP = copy.deepcopy(SPf)
                                SP['LB'] = SPf['UB']
                                conv_f = True
                                print('*** f: local LB',SPf['UB']) 
                                print()
                         
                        if conv_MC == False and conv_f == False:
                            conv_GS,LB_GS,f_GS = gauss_seidel(data,params,SP,tol)                            
                            if conv_GS == True:
                                print('==> GS converged')
                                if LB_GS > SP['LB']:
                                    SP['LB'] = LB_GS
                                    SP['f'] = f_GS
                                    print('*** GS: local LB',LB_GS) 
                                # SPopt = copy.deepcopy(SP)   ######################### update  #########################                 
                                                     
                        if SP['LB'] > LB:
                            print('*** update LB',mode,'***')
                            SPopt = copy.deepcopy(SP)                                
                            LB = SP['LB']
                            sopt = SP['s']
                            fopt = SP['f']
                        
                            #---prune tree with new LB
                            cnt_pruned = 0
                            for i in tree:
                                if tree[i]['active'] == True and tree[i]['UB'] < LB:
                                    tree[i]['active'] = False
                                    cnt_pruned += 1
                            if cnt_pruned > 0:
                                print('pruned nodes',cnt_pruned)

                    else:
                        #---CS satisfied and cost budget-feasible 
                        SP['LB'] = SP['UB']
                        
                        #---if new LB is better than incumbent, update LB and solution
                        if SP['LB'] > LB:
                            print('*** update LB ***')
                            SPopt = copy.deepcopy(SP)
                            LB = SP['LB']
                            sopt = copy.deepcopy(SP['s'])
                            fopt = copy.deepcopy(SP['f'])
                            
                            #---prune tree with new LB
                            cnt_pruned = 0
                            for i in tree:
                                if tree[i]['active'] == True and tree[i]['UB'] < LB:
                                    tree[i]['active'] = False  
                                    cnt_pruned += 1
                            if cnt_pruned > 0:
                                print('pruned nodes',cnt_pruned)                                    
                                    
                #---if local UB > best bilevelfeas solution, branch on bvar else prune tree
                elif SP['active'] != False:
                    if SP['UB'] > LB:
                        tree = branch(SP,can,tree,bvar)
                        #print('branching',bvar)
                        
            SP['active'] = False
            tree[can]['active'] = False
            
        candidates = [i for i in tree if tree[i]['active']==True]

        new_tree = list(set(tree.keys()) - cur_trees)  ## candidates that are newly added
        new_tree = [i for i in new_tree if tree[i]['active']==True]
        if len(new_tree) == 0:
            DF_activate, GS_activate = False, False    
            #print('all new trees are pruned in depth first search. Returned to normal search')

        ### trigger conditions for Gauss-Seidel heuristic
        ## condition one is triggered after DF
        ## condition two is triggered when reachning the minimum No. of vialtated constraints
        if bilevelfeas == False:
            list_violated_len = []
            for SP,_ in SP_can_res:
                if SP['UB'] != 'infeasible' and len(SP['CS']) != 0:
                    _,_,violated_len = check_CS(data,SP,CStype,tol,branching_rule)
                    list_violated_len.append(sum(violated_len))
                else:
                    list_violated_len.append(10**4)
            sp_idx = list_violated_len.index(min(list_violated_len))
            SP = SP_can_res[sp_idx][0] ## pick the node with minimum violated len

            #print('the min vialated len: %s; the num of total vars (not cons): %s'%(min(list_violated_len),len(A)))
            if min(list_violated_len) <= 3*len(A)*params['GS_tri_len'] and GS == True:
                GS_activate = True
                #print('activate GS. Reason: reaching min violated len: %s'%(min(list_violated_len)))  
                
        #---start heuristics------------------      
        if bilevelfeas == False and SP['solve_status'] != 'infeasible':
            if GS_activate == True and n_GS > GS_freeze:
                
                GS_activate = False
                n_GS = 0   
                conv_MC = False
                conv_f = False
                SP['LB'] = 0.0
               
                R = data['ODs']
                P = data['path_idx']
                A = data['links']
                L = data['path_data']['links_of_path']
                B = data['B']
                al = params['alpha']
                Q = data['demand']                
                prop = {}
                for r in R:
                    for k in P[r]:
                        prop[r,k] = B[r,k] + al*(SP['s'][r,k] - sum(SP['f'][a] for a in L[r][k]))
                cost = sum([prop[r,k]*SP['s'][r,k]*Q[r] for r in R for k in P[r]])
                
                if cost > params['budget']:
                    print('--> Budget violated',cost)
                    
                    #---try tightening relaxation using pwMC
                    if mode == 'GS_MC' or mode == 'GS_MC_f': 
                                          
                        SPMC = copy.deepcopy(SP)
                        SPMC = solve_RNDP_MC(data,params,SPMC,CStype,pwMC,False)                        
                        
                        if SPMC['solve_status'] == 'feasible' and SPMC['UB'] + tol < SP['UB']:
                            SP = copy.deepcopy(SPMC)
                            print('*** MC ***')
                            
                            conv_GSMC,LB_GSMC,f_GSMC = gauss_seidel(data,params,SP,tol)  
                            if conv_GSMC == True: 
                                print('==> GS converged')
                                if LB_GSMC > SP['LB']:
                                    SP['LB'] = LB_GSMC
                                    SP['f'] = f_GSMC
                                    conv_MC = True
                                    print('*** MC+GS: local LB',LB_GSMC)                            
                            
                    #---try finding LB using f-param
                    if mode == 'GS_f' or mode == 'GS_MC_f':
                        
                        SPf = copy.deepcopy(SP)
                        SPf = solve_RNDP_f_parameterized(data,params,SPf,CStype,False) 
                        
                        if SPf['solve_status'] == 'feasible':
                           
                            conv_GSf,LB_GSf,f_GSf = gauss_seidel(data,params,SPf,tol)                         
                            if conv_GSf == True: 
                                print('==> GS converged')
                                if LB_GSf > SP['LB']:
                                    SP = copy.deepcopy(SPf)
                                    SP['LB'] = LB_GSf
                                    SP['f'] = f_GSf
                                    conv_f = True
                                    print('*** f+GS: local LB',LB_GSf)
                            
                if conv_MC == False and conv_f == False:
                    conv_GS,LB_GS,f_GS = gauss_seidel(data,params,SP,tol)                            
                    if conv_GS == True:
                        print('==> GS converged')
                        if LB_GS > SP['LB']:
                            SP['LB'] = LB_GS
                            SP['f'] = f_GS
                            print('*** GS: local LB',LB_GS)
                                            
                if SP['LB'] > LB:
                    print('*** update LB',mode,'***')
                    SPopt = copy.deepcopy(SP)                                
                    LB = SP['LB']
                    sopt = copy.deepcopy(SP['s'])
                    fopt = copy.deepcopy(SP['f'])

                    #---prune tree with new LB
                    cnt_pruned = 0
                    for i in tree:
                        if tree[i]['active'] == True and tree[i]['UB'] < LB:
                            tree[i]['active'] = False
                            cnt_pruned += 1
                    if cnt_pruned > 0:
                        print('pruned nodes',cnt_pruned)


                    prk = {}
                    for r in R:
                        for k in P[r]:
                            prk[r,k] = B[r,k] + al*(SPopt['s'][r,k] - sum(SPopt['f'][a] for a in L[r][k]))
                    cost = sum([prk[r,k]*SPopt['s'][r,k]*Q[r] for r in R for k in P[r]])
                    print('cost SPopt',cost)    
                    print()

                if len(candidates) == 0:
                    #### debugging ####
                    SPopt = copy.deepcopy(SP)
                    SPopt['f'] = f_GS
                    converged = True
                    print('\n>>convergence by inspection in GS')

            else:
                n_GS += 1

        #---update candidate list        
        candidates = [i for i in tree if tree[i]['active']==True]
        if len(candidates) == 0 or converged == True:
            #-- convergence by inspection
            converged = True
            UB = LB
            gap = 0
            print('\n>>convergence by inspection')
        else:
            ub_UB = max([tree[i]['UB'] for i in candidates])
            gap = (ub_UB - LB)/ub_UB

        print('>>> %d >>> %d >>> %.1f >>> %.1f >>> %.3f >>> %.1f' % (nit,len(candidates),ub_UB,LB,gap,time.time()-t0))

        obj_bounds['lb'].append(LB)
        obj_bounds['ub'].append(UB)
        
        if gap<=tol:
            #--convergence by optimality gap
            print('\n>>convergence by optimality gap', gap)
            break    
        if (time.time() - t0) >= timelimit:
            print('\n>> time limit')
            break
        nit += 1


    runtime = min(time.time() - t0,timelimit)
    print('*'*30)
    print('time\t%.2f' % (runtime))
    print('OPT\t%.3f' % (LB))
    print('GAP\t%.3f' % (gap))
    print('nit\t%d' % (nit))
    print('*'*30)
    
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    B = data['B']
    al = params['alpha']
    Q = data['demand']   

    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    beta = params['beta']
    al = params['alpha']
    budget = params['budget']
    de = data['delta']
    # SP_can_list = [[SPopt,0]]
    # SP_can_res = paral_slove_RNDP(data,params, SP_can_list, CStype, paral_len,tol)
    # SPopt = SP_can_res[0][0]
    folls  = list(data['A_var'].keys())



    # flows = {}
    # for a in A: # for all links in the network
    #     flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R)

    # SPopt['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * flows[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers
    # print('current objective of followers are: ', SPopt['foll_obj'])

    try:                     
        prk = {}
        for r in R:
            for k in P[r]:
                prk[r,k] = B[r,k] + al*(SPopt['s'][r,k] - sum(SPopt['f'][a] for a in L[r][k]))
        cost = sum([prk[r,k]*SPopt['s'][r,k]*Q[r] for r in R for k in P[r]])
        print('cost SPopt',cost)    
        # prk = {}
        # for r in R:
        #     for k in P[r]:
        #         prk[r,k] = B[r,k] + al*(sopt[r,k] - sum(fopt[a] for a in L[r][k]))
        # # cost = sum([prk[r,k]*sopt[r,k]*Q[r] for r in R for k in P[r]])
        # cost = sum(sum(prk[r,k]*sopt[r,k]*Q[r] for k in P[r]) for r in R)
        # print('cost SPopt',cost)    


        # flows = {}
        # for a in A: # for all links in the network
        #     flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(SPopt['s'][r,k] - sum(SPopt['f'][b] for b in L[r][k]))) for k in P[r]) for r in R)

        # SPopt['foll_obj'] = { foll: sum( (SPopt['f'][a]-ga[a]) * flows[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers


        flows = {}
        for a in A: # for all links in the network
            flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R)

        SPopt['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * flows[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers



    # try:
        print('current objective of followers are: ', SPopt['foll_obj'])
        return LB, gap, runtime, nit, SPopt['f'], SPopt['s'], SPopt['foll_obj'], SPopt['link_flow'], SPopt['path_flow'], SPopt['path_gcost'], tree, SPopt['solve_status'], obj_bounds, None,None
    except:
        return LB, gap, runtime, nit, fopt, sopt, None, None, None, None, tree, SP['solve_status'], obj_bounds, None,None






####### begugging ########
## current problems in the code:
## SPopt is not updated correctly
## followers' objective is not updated correctly, less than zero


####### begugging ########







