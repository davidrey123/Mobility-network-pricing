
##  basic settings  ##
params = {
    ##-- net related --##
    'net': 'SP',
    'A_var': {
        ## single direction
        1: { (1,9),},
        2: { (31,21),(21,61),(61,9),},
        # 3: { (1,2),(2,6),(6,9),(1,5),(5,8),(8,9),(2,3),(3,4),(4,5),(5,4),(4,3),(3,2),(6,7),(7,8),(8,7),(7,6),},
        3: { (1,2),(2,6),(6,9),(2,3),(4,3),(3,2),(6,7),(7,6),},
        4: { (1,5),(5,8),(8,9),(4,5),(5,4),(3,4),(7,8),(8,7),},
    },
    'not_foll':[  ], # followers that are without decisions
    ##-- how competitive of reference mode is to the mean cost of that of all paths of a OD pair
    'coef_G': 1/2, # 1/2  ## the smaller, the more competitive, 1/3 
    'coef_U': 1.5,  ## 1.5 the value of utility of path, OD-based, coef_U * max(path_gcost)
    'beta': 19/60, # value of time 6.4/60
    'alpha': 0.008, # 0.0005，0.0001 works for the small SF witk K=5. time is around 1700S, 0.0005
    'epsilon': 0.00000, ## penalty in leader's obj. sometimes needs to change
    ## assume followers: {0: outside, 1: railway, 2: bus, 3: ride-sorucing, 4: taxi}
    'oper_flag':'foll_based',
    'base_fare':{
        'link_based': {},
        # 'foll_based': { 0: 0, 1: 3.75, 2: 2.75, 3: 1, },
        'foll_based': { 0: 0, 1: 3.75/4.5, 2: 0.95, 3: 2.0, 4: 3.5 },
    },
    'oper_cost':{
        'link_based': {},
        'foll_based': { 0: 0, 1: 0.25, 2: 0.3, 3: 0.40, 4: 0.60 }, ## original used
        # 'foll_based': { 0: 0, 1: 0.4, 2: 0.45, 3: 0.30, 4: 0.30 },
        },
    'K': 3, # number of K-shortest paths

    ##-- instance related --##
    'COV': 0.1, # the coefficiency of variation of operational cost 0.01
    'regenerate_instances': False, # if the oper_cost is changed, turn it to True
    'num_of_instances': 20,

    ### params in SP net ###
    's': 'all', # ['PT', 'all'], 'PT': subsidy only for path associated with public transport
    'RS': 'all', # ['PT', 'all'], 'PT': maximize riderships of PT
    
    ##***********************************##
    ## below are parameters needed to be tuned
    ## you might also need to change the alpha above
    ## note that using a tighter McCormick envelope in model.py also helps sometimes
    ##***********************************##


    ## early condition to stop DF: if the max(UB of new trees) < 1/2 * UB_of_all(active)_trees, stop DF 
    ##-- computation related --##
    'paral_len': 1, # num of nodes branching and updating simultaneously
    'GS': True,
    'GS_freeze': 50,
    'GS_tri_len': 0.1, # (min violated vars / total vars) < GS_trigger len
    'GS_tri_skew': 3, # skewness to trigger GS
    'GS_tri_kurt': 3, # kurtosis to trigger GS
    'depth_first': True, # DF for short
    'DF_depth': 10, # num of branching steps in depth, 15
    'DF_freeze': 0, # num of steps to freeze the DF search (avoid exploring too far)
    'timelimit':22800,

    ##-- partition numbers in McCormick envelopes --##
    ## loaction: solve_RNDP_MC in utils.py and maybe in model.py if using the tighter McCormick envelopes
    'num_par_prk': 5,
    'num_par_s':5,

    'budget':5e4, # budget for subsidy

}

