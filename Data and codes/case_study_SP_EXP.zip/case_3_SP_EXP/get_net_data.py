import copy

import json
import os
import numpy as np
import matplotlib.pyplot as plt
import random



###---read network and instance data---###
#---nodes and links are sets; links is a set of tuples
#---cap, fftt, alpha, beta and cost are dictionaries where the keys are links
def read_network_data(net, path):
    network_data = open(path+net+'_net.txt','r')
    lines_net = network_data.readlines()
    network_data.close()
    nb_nodes = int(lines_net[1].split("\t")[0].split(" ")[3])
    nb_links = int(lines_net[3].split("\t")[0].split(" ")[3])        
    cap, fftt, dist, alpha, beta = {}, {}, {}, {}, {}
    nodes = set();links = set()
    Fa = {}
    
    #---offset is network-specific
    offset = 8
    for i in range(offset,offset+nb_links):
        a = int(lines_net[i].split("\t")[1])
        b = int(lines_net[i].split("\t")[2])
        cap[(a,b)] = float(lines_net[i].split("\t")[3])
        dist[(a,b)] = float(lines_net[i].split("\t")[4])
        fftt[(a,b)] = float(lines_net[i].split("\t")[5])
        alpha[(a,b)] = float(lines_net[i].split("\t")[6])
        beta[(a,b)] = float(lines_net[i].split("\t")[7])
        try:
            Fa[(a,b)] = float(lines_net[i].split("\t")[11])
        except:
            pass

        nodes.add(a)
        nodes.add(b)
        links.add((a,b))       
    return nodes,links,cap,dist,fftt,alpha,beta


###---read trip data---###
def read_trip_data(net, path):
    trip_data = open(path+net+'_trips.txt','r')
    trip_lines = trip_data.readlines()
    trip_data.close()
    # nb_zones = int(trip_lines[0].split("\t")[0].split(" ")[3])
    # total_flow = float(trip_lines[1].split("\t")[0].split(" ")[3])
    dest = 0
    line_nb = 0    
    OD_demand = {} 
    O = set()
    D = set()
    for line in trip_lines:
        if line_nb>=5:
            if line.split(" ")[0]=="Origin":                
                orig = int(line.split(" ")[1])
                orig_flow = 0
            elif len(line.split())>0:
                k=0
                bouh = int(len(line.split())/3)            
                for i in range(bouh):                
                    dest = int(line.split()[k])
                    demand = float(line.split()[k+2].split(";")[0])
                    orig_flow += demand
                    k += 3
                    OD_demand[(orig,dest)] = demand
                    O.add(orig)
                    D.add(dest)
        line_nb += 1
    return OD_demand,O,D



import networkx as nx
from utils import k_shortest_paths
# def path_generation(OD_pairs,links,link_fftt,K):
# #     ################
# #     ## inputs: OD pairs:(o,d), links: {(a,b)}, link free flow travel time: {(a,b):fftt}, K: max number of paths
# #     ## outputs: path_data{path:{path sets}, path:{path travel time}}
# #     ################
#     path_data = {}
#     ##-- build network graph
#     G = nx.DiGraph()
#     for link in links:
#         G.add_edge(link[0], link[1], length = link_fftt[link], weight=1)
#     ##-- find all paths
#     for OD in OD_pairs:
#         o, d = OD[0], OD[1]
#         ##-- find the maximum number of paths. simply brute force
#         possible_K = [i for i in range(1,K+1)]
#         possible_K = sorted(possible_K,reverse=True) ## from the max to the feasible number of K
#         for K_ in possible_K:
#             try:
#                 path_set, path_len = k_shortest_paths(G, o, d, K_, weight = 'length')
#                 break
#             except:
#                 pass
#         if len(path_len) == K:
#             print('Paths might be incomplete (not all paths were found.). \
#                 You might need to increase K to a larger number to OD pair (%d, %d).' %(OD[0],OD[1]))
#         path_data[OD] = {}
#         for k in range(0, len(path_len)):
#             path_data[OD][k] = {'path': path_set[k], 'travel_time': path_len[k]}
#             print(path_data[OD][k]['path'],path_data[OD][k]['travel_time'])
#     return(path_data)

def path_generation(OD_pairs,links,link_fftt,K):
    ################
    ## inputs: OD pairs:(o,d), links: {(a,b)}, link free flow travel time: {(a,b):fftt}, K: max number of paths
    ## outputs: path_data{path:{path sets}, path:{path travel time}}
    ################
    path_data = {}
    path_data = {
        (1,9): {
        1: {'path': [1, 9], 'travel_time': 40.00},
        2: {'path': [1, 2, 6, 9], 'travel_time': 15.00},
        3: {'path': [1, 2, 21, 61, 9], 'travel_time': 16.29},
        4: {'path': [1, 2, 6, 61, 9], 'travel_time': 15.32},
        5: {'path': [1, 5, 8, 9], 'travel_time': 11.08},
        6: {'path': [1, 5, 4, 3, 31, 21, 61, 9], 'travel_time': 24.14},
        7: {'path': [1, 5, 8, 7, 6, 9], 'travel_time': 13.94},
        8: {'path': [1, 5, 8, 7, 6, 61, 9], 'travel_time': 14.27},
        },
        (3,9): {
        1: {'path': [3, 2, 6, 9], 'travel_time': 12.00},
        2: {'path': [3, 31, 21, 61, 9], 'travel_time': 13.99},
        3: {'path': [3, 31, 21, 61, 6, 9], 'travel_time': 13.56},
        4: {'path': [3, 2, 6, 61, 9], 'travel_time': 12.32},
        5: {'path': [3, 4, 5, 8, 9], 'travel_time': 13.02},
        6: {'path': [3, 31, 21, 2, 6, 9], 'travel_time': 12.60},
        },
        (4,9): {
        1: {'path': [4, 5, 8, 9], 'travel_time': 11.92},
        2: {'path': [4, 3, 2, 6, 9], 'travel_time': 13.10},
        3: {'path': [4, 3, 31, 21, 2, 6, 9], 'travel_time': 13.70},
        4: {'path': [4, 3, 31, 21, 61, 6, 9], 'travel_time': 14.66},
        5: {'path': [4, 3, 2, 21, 61, 9], 'travel_time': 14.39},
        6: {'path': [3, 31, 21, 2, 6, 9], 'travel_time': 12.60},
        },
        (7,9): {
        1: {'path': [7, 8, 9], 'travel_time': 2.39},
        2: {'path': [7, 6, 9], 'travel_time': 3.25},
        3: {'path': [7, 6, 61, 9], 'travel_time': 3.57},
        },
    }
    return(path_data)


def build_delta(links, path_data, ODs):
    delta = {(link, OD, k): 0 for link in links for OD in ODs for k in list(path_data[OD].keys())}
    links_of_path = dict()
    for OD in ODs:
        links_of_path[OD] = dict()
        for path in list(path_data[OD].keys()):
            link_node = path_data[OD][path]['path'] # format: string
            link_chain = [(int(link_node[i]), int(link_node[i+1])) for i in range(len(link_node)-1)]
            links_of_path[OD][path] = link_chain
            for link in link_chain:
                delta[(link, OD, path)] = 1
    return(delta, links_of_path)


def get_net_data(net, path, K):
    ###--- initilization ---###
    ## 1. initialize network structure ##
    #---read network and instance data in TNTP format
    nodes, links, capa, dist, fftt, _, _ = read_network_data(net, path)
    #---read trip data in TNTP format
    OD_demand, orig, dest = read_trip_data(net, path)   

    ## 2. initialize data set ##
    delta = {}
    ODs = list(OD_demand.keys()) ## set of OD pairs
    ### remove OD: origin=destination
    for rem_item in [(orig_, orig_) for orig_ in orig]:
        try:
            ODs.remove(rem_item)
        except:
            continue
    path_data = path_generation(ODs, links, fftt, K)
    ###--- build incidence matrix (links and paths) ---###
    delta, links_of_path = build_delta(links, path_data, ODs)
    path_data['links_of_path'] = links_of_path
    path_idx = {}
    for OD in ODs:
        path_idx[OD] =  list(path_data[OD].keys())
    
    data = {
    'ODs': ODs,
    'path_idx': path_idx,
    'links': links,
    'link_dist': dist,
    'link_fftt': fftt,
    'demand': OD_demand,
    'delta': delta,
    'capacity': capa,
    'path_data': path_data,
    }

    return (data)





























