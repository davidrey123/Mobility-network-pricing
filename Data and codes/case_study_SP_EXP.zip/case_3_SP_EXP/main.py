import time
import numpy as np
import os
import copy

from model import algo_MNPP #algo_NDP
from utils import stat
from configuration import process_net_data
from utils import save_json, load_json



####################################
# in SP, the fare is set to be fare_range*Fa, where Fa is the base fare
####################################



if __name__ == '__main__':
    #########################################################################################
    ## specify inputs ##
    net = 'SP' #"ND" #"SF"
    ins_range  = list(np.arange(0,1,1)) #
    subsidy_range = [20] # upper bound of subsidy [200]
    fare_range = [3] #list( np.arange(10, 100, 30) ) # upper bound of fare [50]
    demand_ratios = list(np.arange(1.0, 1.1, 0.2))
    # budget_range = np.arange(0e4, 28e4, 4e4)
    budget_range = [24e4]

    ## define paths to save results ##
    folder_fig = 'res/%s/fig'%net
    folder_json = 'res/%s/json'%net
    for folder in [folder_fig, folder_json]:
        if not os.path.exists(folder):
            os.makedirs(folder)
    ## specify net configurations ##
    if net == 'SF':
        from params_SF import params
    elif net == 'ND':
        from params_ND import params
    elif net == 'SP':
        from params_SP import params
    else:
        print('the params_%s file is not found'%net)
    params_origin = copy.deepcopy(params)  ## to change the operation cost of operators


    # br = 'fmax_gcap_fmin'
    br = 'max_violation'
    mode = 'GS_MC_f' ## ['GS', 'GS_MC', 'GS_f', 'GS_MC_f']:

    for RS_type in ['PT', 'all']:
        for s_type in ['PT','all']:
            out = {}
            
            #########################################################################################
            params['GS'], params['depth_first'] = True, True #case, case
            ## result information
            info = '%s_K%s_al%s_%s_DF_%s_GS_%s_%s_f%s_s%s_RS-%s_s-%s'%(net,params['K'],params['alpha'],br,params['depth_first'],params['GS'],mode,fare_range[-1],subsidy_range[-1],RS_type,s_type)
            #########################################################################################
            try:
                ## reload data
                out = load_json('res/%s/json/%s.txt'%(net,info))
                print('reloading data from history')
            except:
                out = {}
                # out = { 'setting':{}, 'res':{} }                         
            
            infeasible_set = {}
            t_start = time.time()
            for budget in budget_range:
                res = { 'setting':{}, 'res':{} }   
                for instance_i in ins_range:
                    print('>>>',br,mode,instance_i)
                    for subsidy_ub in subsidy_range:
                        for fare_ub in fare_range:
                        
                            result = {'link_res':{}, 'path_res':{}, 'obj_res':{}, 'convergence':{}, 'running_time':{}, 'iter':{}, 'gap':{}}
                            infeasible_set[instance_i, subsidy_ub, fare_ub] = []
                            for demand_r in demand_ratios:
                                t_start_each = time.time()
                                print('(instance, subsidy upper bound, fare upper bound, demand ratio) = (%d, %.1f, %.1f, %.1f)'%(instance_i, subsidy_ub, fare_ub, demand_r))
                                params['s'], params['RS'] = s_type, RS_type ### update the parameters
                                params['budget'] = budget
                                data, params = process_net_data(instance_i, subsidy_ub, fare_ub, demand_r, params)

                                ## --- solve the model --- ##
                                data['branching_rule'] = br
                                #LB, gap, runtime, nit, fopt, sopt, objs, link_flow, path_flow, path_gcost, tree, status, obj_bounds, skew, kurt = algo_NDP(data, params)
                                LB, gap, runtime, nit, fopt, sopt, objs, link_flow, path_flow, path_gcost, tree, status, obj_bounds, skew, kurt = algo_MNPP(data, params,mode)
                                ## --- process results --- ##
                                try:
                                    if status != 'infeasible':
                                        fopt_var = [fopt[a] for a_set in params['A_var'].values() for a in a_set]
                                        print('fares:\n',stat(fopt_var), '\n subsidy:\n', stat(list(sopt.values())))
                                        print('fares: %s \n subsidies: %s'%(fopt,sopt))
                                        result['link_res'][demand_r] = {'fare_old':data['F_a'], 'fare':fopt, 'link_flow':link_flow}
                                        result['path_res'][demand_r] = {'subsidy':sopt, 'path_flow':path_flow}
                                        path_fare = {}
                                        for OD in data['ODs']:
                                            for path in data['path_idx'][OD]:
                                                path_fare[(OD, path)] = sum(fopt[link] for link in data['path_data']['links_of_path'][OD][path])
                                        result['path_res'][demand_r]['path_fare'] = path_fare
                                except:
                                    infeasible_set[instance_i, subsidy_ub, fare_ub].append(demand_r)
                                    print('results are not available. Please check the format of res or the problem is infeasible. %.2f'%demand_r)
                                ## --- obj results --- ##
                                result['obj_res'][demand_r] = {}
                                result['obj_res'][demand_r]['leader'] = LB
                                if objs != None:
                                    for foll, val_ in objs.items():
                                        result['obj_res'][demand_r][foll] = val_
                                else:
                                    for foll in data['followers']:
                                        result['obj_res'][demand_r][foll] = -1
                                ## --- obj bound results for convergence plot --- ##
                                result['convergence'][demand_r] = obj_bounds
                                ## --- running time --- ##
                                t_end_each = time.time()
                                result['running_time'][demand_r] = t_end_each - t_start_each
                                result['iter'][demand_r] = nit
                                result['gap'][demand_r] = gap


                            res['res'][instance_i, subsidy_ub, fare_ub] = result
                            res['setting'][instance_i, subsidy_ub, fare_ub] = {'params':params, 'data':data, 'skew':skew, 'kurt':kurt}
                            print('current results: ',result['obj_res'])
                

                            ### save res after each instance ###
                            t_end  = time.time()
                            print('total time used: %.2f s'%(t_end-t_start))
                            res['setting']['total_time_used'] =  round(t_end-t_start,2)
                            res['setting']['subsidy_range'] = subsidy_range
                            res['setting']['fare_range'] = fare_range
                            res['setting']['demand_ratios'] = demand_ratios
                            res['setting']['instance_range'] = ins_range
                        
                print('-'*10,'\n infeasible demand ratio cases are: ', infeasible_set)

                out[budget] = res

                save_json(out, '%s/%s.txt'%(folder_json, info))


    # import parse_res_computation
    from parse_res_computation_budget import parse_res_computation
    parse_res_computation(ins_range, net, subsidy_range[0], fare_range[0], br, mode, budget_range)
    print(' ---- obj results saved ---- ')







