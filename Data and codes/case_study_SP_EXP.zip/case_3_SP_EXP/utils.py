from docplex.mp.model import Model
import numpy as np

def stat(list_):
    print('average = %.2f, median = %.2f, min = %.2f, max = %.2f, 25-th_percentile = %.2f, 50-th_percentile = %.2f, 75-th_percentile = %.2f'%(np.mean(list_), np.median(list_), np.min(list_), np.max(list_), np.percentile(list_, 25, 0), np.percentile(list_, 50, 0), np.percentile(list_, 75, 0)))

def save_json(res, file):
    import ujson
    with open(file, 'w') as json_file:
        json_file.write(ujson.dumps(str(res)))
    print(' ---- results saved ---- ')

def load_json(file):
    with open(file,'r') as f:
        for line in f.readlines():
            dic = line #string
    data = eval(eval(dic))
    return(data)

import networkx as nx
import copy as cp
def k_shortest_paths(G, source, target, k, weight = 'length'):
    # G is a networkx graph. G[o][d]['length']: link travel time, G[o][d]['weight']: calculate the number of links in a path, weight=1
    # source and target are the labels for the source and target of the path.
    # k is the amount of desired paths.
    # weight = 'weight' assumes a weighed graph. If this is undesired, use weight = None.
    
    # A = [nx.dijkstra_path(G, source, target, weight = 'weight')]
    A = [nx.dijkstra_path(G, source, target, weight = 'length')]
    A_len = [sum([G[A[0][l]][A[0][l + 1]]['length'] for l in range(len(A[0]) - 1)])]
    B = []

    for i in range(1, k):
        for j in range(0, len(A[-1]) - 1):
            Gcopy = cp.deepcopy(G)
            spurnode = A[-1][j]
            rootpath = A[-1][:j + 1]
            for path in A:
                if rootpath == path[0:j + 1]: #and len(path) > j?
                    if Gcopy.has_edge(path[j], path[j + 1]):
                        Gcopy.remove_edge(path[j], path[j + 1])
                    if Gcopy.has_edge(path[j + 1], path[j]):
                        Gcopy.remove_edge(path[j + 1], path[j])
            for n in rootpath:
                if n != spurnode:
                    Gcopy.remove_node(n)
            try:
                spurpath = nx.dijkstra_path(Gcopy, spurnode, target, weight = 'length')
                totalpath = rootpath + spurpath[1:]
                if totalpath not in B:
                    B += [totalpath]
            except nx.NetworkXNoPath:
                continue
        if len(B) == 0:
            break
        lenB = [sum([G[path[l]][path[l + 1]]['length'] for l in range(len(path) - 1)]) for path in B]
        B = [p for _,p in sorted(zip(lenB, B), key = lambda x: x[0])] # sort the list by path length
        A.append(B[0])
        A_len.append(sorted(lenB)[0])
        B.remove(B[0])
        
    return A, A_len



def solve_RNDP_s_parameterized(data,params,SP,CStype):
    RNDP = Model(name='RNDP',log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    uf = data['ub_f']
    lf = data['lb_f']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    ######## params
    beta = params['beta']
    al = params['alpha']
    budget = params['budget']

    folls  = list(params['A_var'].keys()) # only followers with decision links. foll 0 not included

    s = SP['s']
    f = {a: RNDP.continuous_var() for a in A}  # only for decision links
    for a in A_foll[0]:
        RNDP.add_constraint(f[a] == data['F_a'][a])
        
    lbd = {a: RNDP.continuous_var() for a in A}
    nul = {a: RNDP.continuous_var() for a in A}
    nuu = {a: RNDP.continuous_var() for a in A}


    for r in R:
        RNDP.add_constraint(sum(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
    for foll in folls:
        for a in data['A_var'][foll]:
            temp = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a]
                                         - sum(f[b] for b in L[r][k] if b != a) - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in data['A_var'][foll])))
                                        for k in P[r]) for r in R)
            RNDP.add_constraint(temp - nuu[a] + nul[a] == 0)

    #################################################################################
    prk = {(r,k):B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    RNDP.add_constraint(sum(s[r,k]*Q[r]*prk[r,k] for r in R for k in P[r]) <= budget )
    #################################################################################

    ############# flow conservation
    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a])
        RNDP.add_constraint(lbd[a] >= 0)
        RNDP.add_constraint(f[a] <= uf[a])
        RNDP.add_constraint(f[a] >= lf[a])
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        
    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['CSpd']['cap0']:
        RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R) == C[a])
    for a in SP['CSpd']['lbd0']:
        RNDP.add_constraint(lbd[a] == 0)
    for a in SP['CSpd']['fmin0']:
        RNDP.add_constraint(f[a] == lf[a])
    for a in SP['CSpd']['nul0']:
        RNDP.add_constraint(nul[a] == 0)
    for a in SP['CSpd']['fmax0']:
        RNDP.add_constraint(f[a] == uf[a])
    for a in SP['CSpd']['nuu0']:
        RNDP.add_constraint(nuu[a] == 0)    
    
    # for a in SP['cap0']:
    #     RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R) == C[a])
    # for a in SP['lbd0']:
    #     RNDP.add_constraint(lbd[a] == 0)
    # for a in SP['fmin0']:
    #     RNDP.add_constraint(f[a] == lf[a])
    # for a in SP['nul0']:
    #     RNDP.add_constraint(nul[a] == 0)
    # for a in SP['fmax0']:
    #     RNDP.add_constraint(f[a] == uf[a])
    # for a in SP['nuu0']:
    #     RNDP.add_constraint(nuu[a] == 0)
    
    ### --- objective function
    prk = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    leader_obj = sum(sum(Q[r]*prk[r,k] for k in P[r]) for r in R)
    ### --- obj 3: maximize ridership consitsts pt paths
    ###################### setting of path subsidies  ##############################
    if params['RS'] == 'PT':
        leader_obj = sum(sum(Q[r]*prk[r,k] for k in data['pt_paths'][r]) for r in R)
    ###################### setting of path subsidies  ##############################

    RNDP.maximize(leader_obj)

    # print(RNDP.parameters)
    RNDP.parameters.threads = 1
    RNDP.parameters.timelimit = 60
    
    RNDP.solve()

    feas = False
    if RNDP.get_cplex().solution.get_status() == 107:
        # time limit exceeded but integer sol exist
        feas = True
    elif 'optimal' in RNDP.solve_details.status:
        feas = True
        
    if feas == False:
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        SP['solve_status'] = 'infeasible' #RNDP.solve_details.status ## update solve status
        print('s-RNDP: %d\t%s\t%d\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time))
        return SP
    objopt = RNDP.solution.get_value(leader_obj)
    print('s-RNDP: %d\t%s\t%d\t%.1f\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time, objopt))
  
    # grab the results
    sopt = SP['s']
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt = {a:RNDP.solution.get_value(f[a]) for a in A}
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A}

    # grab CS status
    gcap, CS = {}, {}
    for a in A:
        gcap[a] = np.abs(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R) - C[a])
        CStemp = {}    
        for cs in CStype:
            if cs == 'gcap':
                CStemp[cs] = gcap[a]*lbdopt[a]
            elif cs == 'fmin':
                CStemp[cs] = np.abs(fopt[a] - lf[a])*nulopt[a]
            elif cs == 'fmax':
                CStemp[cs] = np.abs(fopt[a] - uf[a])*nuuopt[a]
                #print(a,cs,np.abs(fopt[a] - uf[a]),nuuopt[a])
        CS[a] = CStemp
    
    SP['UB'] = objopt
    SP['s'] = sopt
    SP['f'] = fopt
    SP['CS'] = CS
    SP['solve_status'] = 'feasible' #RNDP.solve_details.status
    SP['multiplier'] = {'lbd':lbdopt,'nul':nulopt,'nuu':nuuopt}
    link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
    path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(prk[r,k]) for r in R for k in P[r]}
    SP['link_flow'] = link_flow_opt ## flow on links
    SP['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * link_flow_opt[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers
    SP['path_flow'] = path_flow_opt ## flow on paths
    SP['path_gcost'] = {} ## generalized cost of path
    # SP['z']= {(r,k): RNDP.solution.get_value(z[r,k]) for r in R for k in P[r]}
    for r in R:
        for k in P[r]:
            SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]
    print('------------------------------------------')
    print('total budget in f-paramterized %s'%(RNDP.solution.get_value(sum(s[r,k]*Q[r]*prk[r,k] for r in R for k in P[r]))))
    return SP

def solve_RNDP_f_parameterized(data,params,SP,CStype,GNEP):
    RNDP = Model(name='RNDP',log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    us = data['ub_s']
    ls = data['lb_s']
    #uf = data['ub_f']
    #lf = data['lb_f']    
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    beta = params['beta']
    al = params['alpha'] 
    budget = params['budget']

    folls  = list(params['A_var'].keys()) # only followers with decision links. foll 0 not included
    
    s = {(r,k): RNDP.continuous_var() for r in R for k in P[r]} 
    f = SP['f']
    lbd = {a: RNDP.continuous_var() for a in A}
    nul = {a: RNDP.continuous_var() for a in A}
    nuu = {a: RNDP.continuous_var() for a in A}
    
    prk = {(r,k):B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    
    for r in R:
        RNDP.add_constraint(sum(prk[r,k] for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(prk[r,k] >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(s[r,k] <= us[r,k])
            RNDP.add_constraint(s[r,k] >= ls[r,k])
            
    temp = {}
    for foll in folls:
        for a in data['A_var'][foll]:
            temp[(foll,a)] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a] 
                                                        - sum(f[b] for b in L[r][k] if b != a) 
                                                        - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in data['A_var'][foll]))) 
                           for k in P[r]) for r in R)
            RNDP.add_constraint(temp[(foll,a)] - nuu[a] + nul[a] == 0)

    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a])
        RNDP.add_constraint(lbd[a] >= 0)
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        
    RNDP.add_constraint(sum(s[r,k]*Q[r]*prk[r,k] for r in R for k in P[r]) <= budget)    
        
    #---complementarity slackness conditions at SP #branch and bound
    if GNEP == False:
        
        for a in SP['cap0']:
            RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R) == C[a])
        for a in SP['lbd0']:
            RNDP.add_constraint(lbd[a] == 0)
        #for a in SP['fmin0']:
        #    RNDP.add_constraint(f[a] == lf[a])
        for a in SP['nul0']:
            RNDP.add_constraint(nul[a] == 0)
        #for a in SP['fmax0']:
        #    RNDP.add_constraint(f[a] == uf[a])
        for a in SP['nuu0']:
            RNDP.add_constraint(nuu[a] == 0) 
    
    #---force GNEP point
    else:
   
        for a in SP['GNEP']['cap0']:
            RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R) == C[a])
        for a in SP['GNEP']['lbd0']:
            RNDP.add_constraint(lbd[a] == 0)
        #for a in SP['GNEP']['fmin0']:
        #    RNDP.add_constraint(f[a] == lf[a])
        for a in SP['GNEP']['nul0']:
            RNDP.add_constraint(nul[a] == 0)
        #for a in SP['GNEP']['fmax0']:
        #    RNDP.add_constraint(f[a] == uf[a])
        for a in SP['GNEP']['nuu0']:
            RNDP.add_constraint(nuu[a] == 0) 
                      
    ### --- objective function
    leader_obj = sum(sum(Q[r]*prk[r,k] for k in P[r]) for r in R)
    ### --- obj 3: maximize ridership consists pt paths
    ###################### setting of path subsidies  ##############################
    if params['RS'] == 'PT':
        leader_obj = sum(sum(Q[r]*prk[r,k] for k in data['pt_paths'][r]) for r in R)
    ###################### setting of path subsidies  ##############################

    RNDP.maximize(leader_obj)

    # print(RNDP.parameters)
    RNDP.parameters.threads = 1
    RNDP.parameters.timelimit = 60
    
    RNDP.solve()

    feas = False
    if RNDP.get_cplex().solution.get_status() == 107:
        # time limit exceeded but integer sol exist
        feas = True
    elif 'optimal' in RNDP.solve_details.status:
        feas = True
        
    if feas == False:
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        SP['solve_status'] = 'infeasible' #RNDP.solve_details.status ## update solve status
        print('f-RNDP: %d\t%s\t%d\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time))
        return SP
    objopt = RNDP.solution.get_value(leader_obj)
    print('f-RNDP: %d\t%s\t%d\t%.1f\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time, objopt))
  
    # grab the results
    sopt = {(r,k):RNDP.solution.get_value(s[r,k]) for r in R for k in P[r]}
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt =  SP['f']
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A}
  
    SP['UB'] = objopt
    SP['s'] = sopt
    SP['f'] = fopt
    SP['solve_status'] = 'feasible' #RNDP.solve_details.status
    SP['multiplier'] = {'lbd':lbdopt,'nul':nulopt,'nuu':nuuopt}
    link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
    path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(prk[r,k]) for r in R for k in P[r]}
    SP['link_flow'] = link_flow_opt ## flow on links
    SP['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * link_flow_opt[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers
    SP['path_flow'] = path_flow_opt ## flow on paths
    SP['path_gcost'] = {} ## generalized cost of path
    for r in R:
        for k in P[r]:
            SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]

    print('------------------------------------------')
    cost = RNDP.solution.get_value(sum(s[r,k]*Q[r]*prk[r,k] for r in R for k in P[r]))
    print('total budget in s-paramterized %s'%(cost))
    if cost > params['budget']:
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        SP['solve_status'] = 'infeasible' #RNDP.solve_details.status ## update solve status
        return SP

    return SP


def solve_RNDP_MC(data,params,SP,CStype,pwMC,GNEP):
    RNDP = Model(name='RNDP',log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    us = data['ub_s']
    ls = data['lb_s']
    uf = data['ub_f']
    lf = data['lb_f']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    beta = params['beta']
    al = params['alpha'] 
    budget = params['budget']

    folls  = list(data['A_var'].keys()) # only followers with decision links. foll 0 not included

    s = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    lbd = {a: RNDP.continuous_var() for a in A}
    f = {a: RNDP.continuous_var() for a in A}
    nul = {a: RNDP.continuous_var() for a in A}
    nuu = {a: RNDP.continuous_var() for a in A}
    
    prk = {(r,k):B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    
    for a in A_foll[0]:
        RNDP.add_constraint(f[a] == data['F_a'][a])

    for r in R:
        RNDP.add_constraint(sum(prk[r,k] for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(prk[r,k] >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(s[r,k] <= us[r,k])
            RNDP.add_constraint(s[r,k] >= ls[r,k])
            
    for foll in folls:
        for a in data['A_var'][foll]:
            temp = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a] 
                                                        - sum(f[b] for b in L[r][k] if b != a) 
                                                        - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in data['A_var'][foll]))) 
                           for k in P[r]) for r in R)
            RNDP.add_constraint(temp - nuu[a] + nul[a] == 0)

    #################################################################################
    ### Relaxation of z = s*prk in budget: McCormick envelope    
    # num_par_prk, num_par_s = params['num_par_prk'], params['num_par_s'] ## (i,j)
    num_par_prk, num_par_s = pwMC['pw'], pwMC['pw']
    
    pars = [(i,j) for i in range(num_par_prk) for j in range(num_par_s)]
    z = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    aux_s = {(r,k): RNDP.continuous_var_dict(pars) for r in R for k in P[r]}
    aux_prop = {(r,k): RNDP.continuous_var_dict(pars) for r in R for k in P[r]}
    bi_idx = {(r,k): RNDP.binary_var_dict(pars) for r in R for k in P[r]}
    # #### xi = prk; xj=s
    for r in R:
        for k in P[r]:
            prk_l = [((B[r,k]+al*us[r,k])/num_par_prk)*i for i in range(num_par_prk)]
            prk_u = [((B[r,k]+al*us[r,k])/num_par_prk)*i for i in range(1,num_par_prk+1)]
            s_l = [(us[r,k]/num_par_s)*j for j in range(num_par_s)]
            s_u = [(us[r,k]/num_par_s)*j for j in range(1,num_par_s+1)]

            RNDP.add_constraint(z[r,k] >= sum([aux_prop[r,k][i,j]*s_l[j] + prk_l[i]*aux_s[r,k][i,j] - prk_l[i]*s_l[j]*bi_idx[r,k][i,j]  for i in range(num_par_prk) for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] >= sum([aux_prop[r,k][i,j]*s_u[j] + prk_u[i]*aux_s[r,k][i,j] - prk_u[i]*s_u[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] <= sum([aux_prop[r,k][i,j]*s_l[j] + prk_u[i]*aux_s[r,k][i,j] - prk_u[i]*s_l[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            RNDP.add_constraint(z[r,k] <= sum ([aux_prop[r,k][i,j]*s_u[j] + prk_l[i]*aux_s[r,k][i,j] - prk_l[i]*s_u[j]*bi_idx[r,k][i,j] for i in range(num_par_prk)  for j in range(num_par_s)]))
            RNDP.add_constraint(prk[r,k] == sum(aux_prop[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)))
            RNDP.add_constraint(s[r,k] == sum(aux_s[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)))
            RNDP.add_constraint(sum([bi_idx[r,k][i,j] for i in range(num_par_prk) for j in range(num_par_s)]) == 1)
            for i in range(num_par_prk):
                for j in range(num_par_s):
                    RNDP.add_constraint( prk_l[i]*bi_idx[r,k][i,j] <= aux_prop[r,k][i,j] )
                    RNDP.add_constraint( prk_u[i]*bi_idx[r,k][i,j] >= aux_prop[r,k][i,j] )
                    RNDP.add_constraint( s_l[j]*bi_idx[r,k][i,j] <= aux_s[r,k][i,j] )
                    RNDP.add_constraint( s_u[j]*bi_idx[r,k][i,j] >= aux_s[r,k][i,j] )
    RNDP.add_constraint(sum(z[r,k]*Q[r] for r in R for k in P[r]) <= budget)
    ################################################################################
    
    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a])
        RNDP.add_constraint(lbd[a] >= 0)
        RNDP.add_constraint(f[a] <= uf[a])
        RNDP.add_constraint(f[a] >= lf[a])
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        
    #---complementarity slackness conditions at SP #branch and bound
    if GNEP == False:
        
        for a in SP['cap0']:
            RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R) == C[a])
        for a in SP['lbd0']:
            RNDP.add_constraint(lbd[a] == 0)
        for a in SP['fmin0']:
            RNDP.add_constraint(f[a] == lf[a])
        for a in SP['nul0']:
            RNDP.add_constraint(nul[a] == 0)
        for a in SP['fmax0']:
            RNDP.add_constraint(f[a] == uf[a])
        for a in SP['nuu0']:
            RNDP.add_constraint(nuu[a] == 0) 
    
    #---force GNEP point
    else:
   
        for a in SP['GNEP']['cap0']:
            RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*prk[r,k] for k in P[r]) for r in R) == C[a])
        for a in SP['GNEP']['lbd0']:
            RNDP.add_constraint(lbd[a] == 0)
        for a in SP['GNEP']['fmin0']:
            RNDP.add_constraint(f[a] == lf[a])
        for a in SP['GNEP']['nul0']:
            RNDP.add_constraint(nul[a] == 0)
        for a in SP['GNEP']['fmax0']:
            RNDP.add_constraint(f[a] == uf[a])
        for a in SP['GNEP']['nuu0']:
            RNDP.add_constraint(nuu[a] == 0) 
    
    ### --- objective function    
    leader_obj = sum(sum(Q[r]*prk[r,k] for k in P[r]) for r in R)
    ### --- obj 3: maximize ridership consitsts pt paths
    ###################### setting of path subsidies  ##############################
    if params['RS'] == 'PT':
        leader_obj = sum(sum(Q[r]*prk[r,k] for k in data['pt_paths'][r]) for r in R)
    ###################### setting of path subsidies  ##############################

    RNDP.maximize(leader_obj)

    # print(RNDP.parameters)
    RNDP.parameters.threads = 4
    RNDP.parameters.timelimit = pwMC['tl']

    RNDP.solve()
    
    feas = False
    if RNDP.get_cplex().solution.get_status() == 108:
        # time limit exceeded but no integer sol exist
        feas = False
    if RNDP.get_cplex().solution.get_status() == 107:
        # time limit exceeded but integer sol exist
        feas = True
    elif 'optimal' in RNDP.solve_details.status:
        feas = True
        
    if feas == False:
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        SP['solve_status'] = 'infeasible'
        print('RNDP-MC: %d\t%s\t%d\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time))
        return SP
    
    #objopt = RNDP.solution.get_value(leader_obj)
    objopt = RNDP.solution.solve_details.best_bound #---best bound
    print('RNDP-MC: %d\t%s\t%d\t%.1f\t%.1f' % (feas, RNDP.solve_details.status, RNDP.get_cplex().solution.get_status(), RNDP.solve_details.time, objopt))
  
    # grab the results
    sopt = {(r,k):RNDP.solution.get_value(s[r,k]) for r in R for k in P[r]}
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt = {a:RNDP.solution.get_value(f[a]) for a in A}
    for a in A_foll[0]:
        fopt[a] = data['F_a'][a] # set constant to no-decision links
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A}
    
    SP['UB'] = objopt
    SP['s'] = sopt
    SP['f'] = fopt
    SP['solve_status'] = 'feasible' #RNDP.solve_details.status
    SP['multiplier'] = {'lbd':lbdopt,'nul':nulopt,'nuu':nuuopt}
    link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
    path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(prk[r,k]) for r in R for k in P[r]}
    SP['link_flow'] = link_flow_opt ## flow on links
    SP['foll_obj'] = { foll: sum( (fopt[a]-ga[a]) * link_flow_opt[a] for a in A_foll[foll] ) for foll in folls} ## obj of followers
    SP['path_flow'] = path_flow_opt ## flow on paths
    SP['path_gcost'] = {} ## generalized cost of path
    SP['z']= {(r,k): RNDP.solution.get_value(z[r,k]) for r in R for k in P[r]}
    for r in R:
        for k in P[r]:
            SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]

    print('------------------------------------------')
    print('total budget in MC  %s'%(RNDP.solution.get_value(sum(s[r,k]*Q[r]*prk[r,k] for r in R for k in P[r]))))

    return SP
