#from asyncio import constants
from docplex.mp.model import Model
import numpy as np

def gauss_seidel(data,params,SP,tol): 
    #---initialization of Gauss-Seidel        
    s = SP['s']   
    f = SP['f']
    followers = list(data['A_var'].keys())
       
    nit = 0
    maxit = 10
    obj_TSP_it = [] 
    conv_GS = False
    
    while nit < maxit:
        obj_TSP = []
        OK = True
        for foll in followers:
            obj,f = solve_TSP(data,params,SP,f,s,foll)
            if obj == None:
                OK = False
                break
            else:
                obj_TSP.append(obj)
         
        if OK == False:
            break
        else:
            #---check convergence between last two iterations
            obj_TSP_it.append(obj_TSP)
            if nit >= 1:
                if np.allclose(obj_TSP_it[-2], obj_TSP_it[-1], rtol=1e-4):
                    conv_GS = True
                    break                
        nit += 1
             
    if OK == False:
        #print('--> Gauss-Seidel failed',nit)
        return False,None,None
    elif conv_GS == True:
        #print('--> Gauss-Seidel converged',nit)
        R = data['ODs']
        P = data['path_idx']
        L = data['path_data']['links_of_path']
        B = data['B'] 
        A = data['links']
        C = data['capacity']    
        uf = data['ub_f']
        lf = data['lb_f']        
        Q = data['demand']
        al = params['alpha']
        de = data['delta']
        
        #---calculate corresponding LB 
        prop = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
        LB_GS = sum(sum(Q[r]*prop[r,k] for k in P[r]) for r in R) 

        ###################### setting of path subsidies  ######################
        if params['RS'] == 'PT':
             LB_GS = sum(sum(Q[r]*prop[r,k] for k in data['pt_paths'][r]) for r in R)
        ###################### setting of path subsidies  ##############################

        # if sum([prop[r,k]*s[r,k]*Q[r] for r in R for k in P[r]]) > params['budget']:
        #     print('--> GS log: total subsidy is greater than availble budget')
        #     return False,None,None
        
        #---get CS conditions for current GNEP
        flows = {}
        for a in A:
            flows[a] = sum(sum(de[a,r,k]*Q[r]*prop[r,k] for k in P[r]) for r in R)      
               
        return True,LB_GS,f
    
    else:
        print('--> Gauss-Seidel did not converge',nit)
        return False,None,None


def solve_TSP(data,params,SP,f,s,foll):
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    uf = data['ub_f']
    lf = data['lb_f']
    A_foll = data['A_foll']
    ga = data['gamma_a']
    al = params['alpha'] 
    not_solved = False
    
    TSP = Model(name='TSP',log_output=False)
    ff = {a: TSP.continuous_var() for a in A_foll[foll]}
    
    # prop = {(r,k): B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll])) for r in R for k in P[r]}
    prop = {}
    for r in R:
        for k in P[r]:        
            prop[r,k] = B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]))
    
    flows = {}
    for a in A:
        flows[a] = sum(sum(de[a,r,k]*Q[r]*prop[r,k] for k in P[r]) for r in R)
        TSP.add_constraint(flows[a] <= C[a])
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] <= uf[a])
            TSP.add_constraint(ff[a] >= lf[a])                
            
    #---upper-level feasibility conditions
    for r in R:
        if len([ff[b] for k in P[r] for b in L[r][k] if b in A_foll[foll]]) != 0: ## not adding constraints for constant variables
            TSP.add_constraint(sum(prop[r,k] for k in P[r]) <= 1)
            for k in P[r]:
                if len([ff[b] for b in L[r][k] if b in A_foll[foll]]) != 0: ## not adding constraints for constant variables
                    TSP.add_constraint(prop[r,k] >= 0)
                    TSP.add_constraint(s[r,k] <= sum(f[b] for b in L[r][k] if b not in A_foll[foll]) + sum(ff[b] for b in L[r][k] if b in A_foll[foll]))

    ### budget constraint
    TSP.add_constraint(sum(prop[r,k]*Q[r]*s[r,k] for r in R for k in P[r]) <= params['budget'])

    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['cap0']:
        TSP.add_constraint(sum(sum(de[a,r,k]*Q[r]*prop[r,k] for k in P[r]) for r in R) == C[a])
    for a in SP['fmin0']:
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] == lf[a])
    for a in SP['fmax0']:
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] == uf[a])

    #---objective function
    foll_obj = sum((ff[a] - ga[a])*sum(sum(de[a,r,k]*Q[r]*prop[r,k] for k in P[r]) for r in R) for a in A_foll[foll])
    TSP.maximize(foll_obj)
    
    TSP.parameters.threads = 1
    TSP.parameters.timelimit = 600
    TSP.solve()
    
    #print('solver status',TSP.solve_details.status)
    if TSP.solve_details.status == 'infeasible' or TSP.solve_details.status == 'dual objective limit exceeded' or not_solved == True:
        print('infeasible TSP',foll)
        return None,f
    else:
        #---update the fare vector
        for a in A_foll[foll]:
            f[a] = TSP.solution.get_value(ff[a]) 
                            
        return TSP.objective_value,f
    
