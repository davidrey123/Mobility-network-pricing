
import time
# from matplotlib import artist
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
# from copy import deepcopy
import json, ujson
import os
import copy
from utils import load_json, save_json
import math




#############################


def parse_res (res_name,b, ins_range):
    out = load_json(res_name)
    # with open(res_name,'r') as f:
    #     for line in f.readlines():
    #         dic = line #string
    # out = eval(eval(dic))
    res = out[b]


    instance_range = ins_range #np.arange(0,20,1)
    # instance_range = res['setting']['instance_range']
    subsidy_range = res['setting']['subsidy_range']
    fare_range = res['setting']['fare_range']
    demand_ratios = res['setting']['demand_ratios']
    params = res['setting'][0,subsidy_range[0],fare_range[0]]['params']
    data = res['setting'][0,subsidy_range[0],fare_range[0]]['data']
    followers = list(params['A_var'].keys())
    players = ['leader'] + followers

    A_var_set = {a for a_set in params['A_var'].values() for a in a_set}  # decision links
    link_fare, link_flow = {a:{} for a in A_var_set}, {a:{} for a in A_var_set}
    running_time, iter, gap = {}, {}, {}
    path_sub = {(r,k):{} for r in data['ODs'] for k in data['path_idx'][r]}


    for ins_i in instance_range:
        for s in subsidy_range:
            for fare in fare_range:
                for a in A_var_set:
                    link_fare[a][ins_i, s, fare] = {}
                    link_flow[a][ins_i, s, fare] = {}
                    for dr in demand_ratios:
                        try:
                            link_fare[a][ins_i, s, fare][dr] = res['res'][ins_i,s,fare]['link_res'][dr]['fare'][a]
                            link_flow[a][ins_i, s, fare][dr] = res['res'][ins_i,s,fare]['link_res'][dr]['link_flow'][a]
                            running_time[ins_i, s, fare] = res['res'][ins_i, s, fare]['running_time'][dr]
                            iter[ins_i, s, fare] = res['res'][ins_i, s, fare]['iter'][dr]
                            gap[ins_i, s, fare] = res['res'][ins_i, s, fare]['gap'][dr]
                        except Exception as e:
                            # print('Error when trying to load data from instance %d, subsidy %d, fare %d, demand ratio %d, a (%d, %d)' % (ins_i, s, fare, dr, a[0],a[1]))
                            pass

                # for r in data['ODs']:
                #     for k in data['path_idx'][r]:
                #         path_s[r,k][ins_i, s, fare] = {}
                #         for dr in demand_ratios:
                #             try:
                #                 path_s[r,k][ins_i, s, fare] = res['res'][ins_i,s,fare]['path_res'][dr]['subsidy'][r,k]
                #             except:
                #                 pass
    ErrorList = []
    out = {}
    for ins_i in instance_range:
        for s in subsidy_range:
            for fare in fare_range:
                path_res = res['res'][ins_i,s,fare]['path_res']
                data = res['setting'][ins_i,s,fare]['data']
                ###################### setting of path subsidies  ##############################
                for dr in demand_ratios:


                    try:
                        total_rs = sum([path_res[dr]['path_flow'][r,k] for r in data['ODs'] for k in data['path_idx'][r]])
                        pt_rs = sum([path_res[dr]['path_flow'][r,k]  for r in data['ODs'] for k in data['pt_paths'][r]])
                        total_s = sum(path_res[dr]['path_flow'][r,k] * path_res[dr]['subsidy'][r,k] for r in data['ODs'] for k in data['path_idx'][r])
                        out[dr] = [total_rs, pt_rs, total_s]
                        
                        prk = {}
                        for r in data['ODs']:
                            for k in data['path_idx'][r]:
                                path_sub[r,k][ins_i, s, fare] = path_res[dr]['subsidy'][r,k]
                    except:
                        print('bad instance: %s, budget: %s'%(res_name,b))
                        ErrorList.append([res_name,b])
                        # print('Error when trying to load data from instance %d, subsidy %d, fare %d, demand ratio %d, a (%d, %d)' % (ins_i, s, fare, dr, a[0],a[1]))
                        pass
                    
    
    
    obj = {player:{} for player in players}
    for player in players:
        for ins_i in instance_range:
            for s in subsidy_range:
                for fare in fare_range:
                    obj[player][ins_i, s, fare] = {}
                    for dr in demand_ratios:
                        obj[player][ins_i, s, fare] = res['res'][ins_i,s,fare]['obj_res'][dr][player]
    try:
        out[dr][0] = obj['leader'][ins_i, s, fare] ## total ridership
    except:
        print('bad instance: %s, budget: %s'%(res_name,b))
        # ErrorList.append([res_name,b])
        pass
    
    # rt = [running_time[i,subsidy_range[0],fare_range[0]] for i in instance_range]
    # ave_running_time = np.mean(rt)
    if len(ErrorList) != 0:
        print('ErrorList:',ErrorList)
        return (0,0,0,0,0,0,0)
    else:
        return link_fare, link_flow, path_sub, obj, iter,gap, out[demand_ratios[0]]



def parse_res_computation(ins_range, net, s, f, br, mode, bs):
    ## specify net configurations ##
    if net == 'SP':
        from params_SP import params
        from configuration import process_net_data
    else:
        print('the config_net file of %s is not found'%net)
    sub_types = ['RS-%s_s-%s'%(RS_type,s_type) for RS_type in ['PT','all'] for s_type in ['PT','all'] ]
    # sub_types = ['RS-%s_s-%s'%(RS_type,s_type) for RS_type in ['all'] for s_type in ['all'] ]


    ## define paths to save results ##
    folder_fig = 'res/%s/fig'%net
    folder_json = 'res/%s/json'%net
    folder_link = 'res/%s/fig/link'%net
    folder_path = 'res/%s/fig/path'%net
    for folder in [folder_fig, folder_json,folder_link,folder_path]:
        if not os.path.exists(folder):
            os.makedirs(folder)


    df_out = pd.DataFrame()
    df_obj = pd.DataFrame()
    df_link = pd.DataFrame()
    df_path = pd.DataFrame()
    df_path2 = pd.DataFrame()

    for sub_type in sub_types:
        temp = []
        out = []
        out_obj = []
        out_link = []
        out_path = []
        for b in bs:
            info = '%s_K%s_al%s_%s_DF_%s_GS_%s_%s_f%s_s%s_%s'%(net,params['K'],params['alpha'],br,params['depth_first'],params['GS'],mode,f,s,sub_type)
            res_name = r'res/%s/json/%s.txt'%(net,info)
            link_fare, link_flow, path_sub, obj, iter,gap, RS = parse_res(res_name,b, ins_range)
            # info = '%s_K%s_al%s_fmax_fmin_gcap_DF_%s_GS_%s_f%s_s%s_%s'%(net,params['K'],params['alpha'],params['depth_first'],params['GS'],2,10,sub_type)
            # res = r'res/%s/json/%s.txt'%(net,info)
            # link_fare, link_flow, path_sub, obj, iter,gap, RS = parse_res(res,b)

            keys = list(obj['leader'].keys())
            _, s, f = keys[0]
            dr = 1.0
            for i in ins_range: #np.arange(0,20,1):
                out.append(RS)
                try:
                    out_obj.append([obj[foll][i,s,f] for foll in obj.keys()])
                except:
                    s = 0.0001
                    out_obj.append([obj[foll][i,s,f] for foll in obj.keys()])
            
            out_link.append( [link_fare[a][i,s,f][dr] for a in link_fare.keys()] )
            out_path.append( [path_sub[key][i,s,f] for key in path_sub.keys()] )

        col_names = [(sub_type, (a[0],a[1])) for a in link_fare.keys()]
        df_link = pd.concat([df_link,pd.DataFrame(np.array(out_link),columns=col_names)],axis=1)
        
        col_names = [(sub_type, key) for key in path_sub.keys()]
        df_path = pd.concat([df_path,pd.DataFrame(np.array(out_path),columns=col_names)],axis=1)
        ### second format of path res
        col_names = [(sub_type, b) for b in bs]
        df_path2 = pd.concat([df_path2,pd.DataFrame(np.array(out_path).T,columns=col_names)],axis=1)

        col_names = [(sub_type,col) for col in ['total RS','total PT RS','total subsidy']]
        df_out = pd.concat([df_out,pd.DataFrame(np.array(out),columns=col_names)],axis=1)
        
        col_names = [(sub_type,foll) for foll in obj.keys() ]
        df_obj = pd.concat([df_obj,pd.DataFrame(np.array(out_obj),columns=col_names)],axis=1)


    df_out.index = [int(b) for b in bs]
    df_out.columns = pd.MultiIndex.from_tuples(df_out.columns, names=['Objectives','Subsidy types'])
    df_out.to_csv('res/%s/json/results_%s.csv'%(net,net))

    df_obj.index = [int(b) for b in bs]
    df_obj.columns = pd.MultiIndex.from_tuples(df_obj.columns, names=['Objectives','Subsidy types'])
    df_obj.to_csv('res/%s/json/results_%s_obj.csv'%(net,net))

    df_link.index = [int(b) for b in bs]
    df_link.columns = pd.MultiIndex.from_tuples(df_link.columns, names=['Types','Links'])
    df_link.to_csv('res/%s/json/results_%s_link res.csv'%(net,net))

    df_path.index = [int(b) for b in bs]
    df_path.columns = pd.MultiIndex.from_tuples(df_path.columns, names=['Types','Paths'])
    df_path.to_csv('res/%s/json/results_%s_path res.csv'%(net,net))

    ### second format of path res
    data, params = process_net_data(i, s, f, ins_range[0], params)
    temp =[data['path_data'][r][k]['path'] for r in data['ODs'] for k in data['path_idx'][r] ]
    df_path2.index = [ str(data['path_data'][r][k]['path']) for r in data['ODs'] for k in data['path_idx'][r] ]
    df_path2.columns = pd.MultiIndex.from_tuples(df_path2.columns, names=['Objectives','Subsidy types'])
    df_path2.to_csv('res/%s/json/results_%s_path subsidy_format2.csv'%(net,net))

    # print(df_obj[sub_type,'leader'])







    ######### visualization #########
    # sub_types = ['spt_%s_objpt_%s'%(spt,objpt) for spt in [True,False] for objpt in [True, False]]
    # legend_set = ['RS-PT,s-PT','RS-PT,s-all','RS-all,s-PT','RS-all,s-all']
    sub_types = ['RS-%s_s-%s'%(RS_type,s_type) for RS_type in ['PT','all'] for s_type in ['PT','all'] ]
    legend_set = ['RS-%s_s-%s'%(RS_type,s_type) for RS_type in ['PT','all'] for s_type in ['PT','all'] ]

    colors = ['royalblue', 'coral', 'grey','lightgreen', 'lightblue']
    markers = ['o','s','*','D','^']



    #######################################################  Summary of RS results  #######################################################
    plt.figure(figsize=(4,3))
    for i in range(len(sub_types)):
        sub_type = sub_types[i]
        x = df_out[sub_type,'total RS'].index.to_list()
        y = df_out[sub_type,'total RS'].values
        plt.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
    plt.legend()
    plt.xlabel('Regulator\'s budget (\$)')
    plt.ylabel('Total ridership (trip)')
    plt.ticklabel_format(axis="both", style="sci", scilimits=(0,0))
    plt.tight_layout()
    # plt.show()
    plt.savefig('res/%s/fig/Total ridership.png'%net)

    plt.figure(figsize=(4,3))
    for i in range(len(sub_types)):
        sub_type = sub_types[i]
        x = df_out[sub_type,'total PT RS'].index.to_list()
        y = df_out[sub_type,'total PT RS'].values
        plt.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
    plt.legend()
    plt.xlabel('Regulator\'s budget (\$)')
    plt.ylabel('Total PT ridership (trip)')
    plt.ticklabel_format(axis="both", style="sci", scilimits=(0,0))
    plt.tight_layout()
    # plt.show()
    plt.savefig('res/%s/fig/Total PT ridership.png'%net)


    # ['total RS','total PT RS','total subsidy']
    plt.figure(figsize=(4,3))
    for i in range(len(sub_types)):
        sub_type = sub_types[i]
        x = df_out[sub_type,'total PT RS'].index.to_list()
        y = df_out[sub_type,'total subsidy'].values / df_out[sub_type,'total RS'].values
        plt.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
    plt.legend()
    plt.xlabel('Regulator\'s budget (\$)')
    plt.ylabel('Average subsidy (\$/trip)')
    plt.ticklabel_format(axis="both", style="sci", scilimits=(0,0))
    plt.tight_layout()
    # plt.show()
    plt.savefig('res/%s/fig/Ave subsidy per trip.png'%net)



    #######################################################  Summary of operators profits  #######################################
    foll_types = ['Railway','Bus','Carpooling','Express shuttle']
    ########## one follower with results of four strategies ##########
    followers = list(params['A_var'].keys())
    # foll_types = ['Metro','Bus','Local road','Freeway']
    fig, axs = plt.subplots(2, 2, figsize=(8,6))
    for foll in followers:
        ax = axs[math.floor((foll-1)/2), np.mod(foll-1,2) ]
        for i in range(len(sub_types)):
            sub_type = sub_types[i]
            x = df_obj[sub_type,foll].index.to_list()
            y = df_obj[sub_type,foll].values
            ax.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
        ax.legend()
        ax.set_xlabel('Regulator\'s budget  (\$)')
        ax.set_ylabel('Proft of follower %s (\$)\n %s'%(foll,foll_types[foll-1]))
        ax.ticklabel_format(axis="both", style="sci", scilimits=(0,0))
        plt.tight_layout()
        # plt.show()
    plt.savefig('res/%s/fig/Profits of followers.png'%net)



    ##########  one strategy comparing results of four MSPs ##########
    followers = list(params['A_var'].keys())
    # foll_types = ['Railway','Bus','Local road','Freeway'] ## must one to one
    fig, axs = plt.subplots(2, 2, figsize=(8,6))
    for i in range(len(sub_types)):
        sub_type = sub_types[i]
        ax = axs[math.floor((i-1)/2), np.mod(i-1,2) ]
        for foll in followers:
            x = df_obj[sub_type,foll].index.to_list()
            y = df_obj[sub_type,foll].values
            y2 = [(yy-y[0])/y[0]*100 for yy in y]
            ax.plot(x,y2,linestyle='-',color=colors[foll-1], marker=markers[foll-1],markersize=5,label=foll_types[foll-1])
        ax.legend()
        ax.set_xlabel('Regulator\'s budget  (\$)')
        # ax.set_ylabel('Proft of follower %s (\$)\n %s'%(foll,foll_types[foll-1]))
        ax.set_ylabel('%s\nMSP\'s profit changes (%%)'%(sub_type))
        ax.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
        plt.tight_layout()
        # plt.show()
    plt.savefig('res/%s/fig/Profits of followers2.png'%net)

    ##########  separate figures:  one strategy comparing results of four MSPs ##########
    followers = list(params['A_var'].keys())
    # foll_types = ['Railway','Bus','Local road','Freeway'] ## must one to one
    for i in range(len(sub_types)):
        fig, ax = plt.subplots(figsize=(4,3))
        sub_type = sub_types[i]
        for foll in followers:
            x = df_obj[sub_type,foll].index.to_list()
            y = df_obj[sub_type,foll].values
            y2 = [(yy-y[0])/y[0]*100 for yy in y]
            plt.plot(x,y2,linestyle='--',color=colors[foll-1], marker=markers[foll-1],markersize=5,label=foll_types[foll-1])
        ax.legend()
        ax.set_xlabel('Regulator\'s budget  (\$)')
        # ax.set_ylabel('Proft of follower %s (\$)\n %s'%(foll,foll_types[foll-1]))
        ax.set_ylabel('%s\nMSP\'s profit changes (%%)'%(sub_type))
        ax.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
        plt.tight_layout()
        # plt.show()
        plt.savefig('res/%s/fig/Profits of folls_%s.png'%(net,sub_type))





    #######################################################  Link results  #######################################################

    # link = (5,8)
    # print(link_flow.keys())
    for link in link_flow.keys():
        plt.figure(figsize=(4,3))
        x = df_link.index.to_list()
        for i in range(len(sub_types)):
            sub_type = sub_types[i]
            y = df_link[sub_type,link].values
            plt.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
        plt.legend()
        plt.xlabel('Regulator\'s budget (\$)')
        plt.ylabel('Link fare (\$)')
        plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
        plt.tight_layout()
        # plt.show()
        plt.savefig('res/%s/fig/link/link fare_%s_%s.png'%(net,link[0],link[1]))
        plt.close()


    #######################################################  Path results  #######################################################

    for path in path_sub.keys():
        plt.figure(figsize=(4,3))
        x = df_path.index.to_list()
        for i in range(len(sub_types)):
            sub_type = sub_types[i]
            y = df_path[sub_type,path].values
            plt.plot(x,y,linestyle='-',color=colors[i], marker=markers[i],markersize=5,label=legend_set[i])
        plt.legend()
        plt.xlabel('Regulator\'s budget  (\$)')
        plt.ylabel('Path subsidy (\$)')
        plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
        plt.tight_layout()
        # plt.show()
        plt.savefig('res/%s/fig/path/path sub_%s.png'%(net,path))
        plt.close()



