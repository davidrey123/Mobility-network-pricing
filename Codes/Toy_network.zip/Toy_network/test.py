
cases = ['seq','seq_base']

cases[0] in cases[1]







