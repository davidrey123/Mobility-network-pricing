
import time
import numpy as np
import pandas as pd
from copy import deepcopy
import json, ujson
import os


net='Sf'
instance_i = 0

# from main import instance_range

def parse_res (res_name):
    with open(res_name,'r') as f:
        for line in f.readlines():
            dic = line #string
    res = eval(eval(dic))

    instance_range  = [int(i) for i in range(0,10)]
    subsidy_range = res['setting']['subsidy_range']
    fare_range = res['setting']['fare_range']
    demand_scales = res['setting']['demand_scales']
    params = res['setting'][0,subsidy_range[0],fare_range[0]]['params']
    data = res['setting'][0,subsidy_range[0],fare_range[0]]['data']
    followers = list(params['A_var'].keys())
    players = ['leader'] + followers

    A_var_set = {a for a_set in params['A_var'].values() for a in a_set}  # decision links
    link_fare, link_flow = {a:{} for a in A_var_set}, {a:{} for a in A_var_set}
    running_time = {}
    for instance_i in instance_range:
        for a in A_var_set:
            for s in subsidy_range:
                for fare in fare_range:
                    link_fare[a][instance_i, s, fare] = {}
                    link_flow[a][instance_i, s, fare] = {}
                    for dr in demand_scales:
                        try:
                            link_fare[a][instance_i, s, fare] = res['res'][instance_i,s,fare]['link_res'][dr]['fare'][a]
                            link_flow[a][instance_i, s, fare] = res['res'][instance_i,s,fare]['link_res'][dr]['link_flow'][a]
                            running_time[instance_i, s, fare] = res['res'][instance_i, s, fare]['running_time'][dr]
                        except:
                            pass
    obj = {player:{} for player in players}
    for player in players:
        for instance_i in instance_range:
            for s in subsidy_range:
                for fare in fare_range:
                    # print(instance_i, s, fare)
                    obj[player][instance_i, s, fare] = {}
                    for dr in demand_scales:
                        obj[player][instance_i, s, fare] = res['res'][instance_i,s,fare]['obj_res'][dr][player]
                        try:
                            obj[player][instance_i, s, fare] = res['res'][instance_i,s,fare]['obj_res'][dr][player]
                        except:
                            pass
    rt = [running_time[i,subsidy_range[0],fare_range[0]] for i in instance_range]
    ave_running_time = np.mean(rt)
    return link_fare, link_flow, obj,  running_time, ave_running_time



#############################
##-- specify inputs --##
net = 'SF'
instance_i = 0
plot_path = False
#############################

## specify net configurations ##
if net == 'SF':
    from config_SF import process_net_data, params
elif net == 'Toy':
    from config_Toy import process_net_data, params
elif net == 'ND':
    from config_ND import process_net_data, params
else:
    print('the config_net file of %s is not found'%net)

branch_rules = ['max_violation','fmax_fmin_gcap','fmax_gcap_fmin','gcap_fmax_fmin']
br = branch_rules[1]
info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)


# for br in branching_rules:
for br in ['fmax_fmin_gcap']:
    # res = r'res/%s/json/old_model/results_SF_mid_trips_K5_alpha_0005_%s.txt'%(net, br)
    res = r'res/%s/json/results_%s.txt'%(net,info)
    link_fare, link_flow, obj, running_t, ave_running_time = parse_res(res)
    
    ## print res of one instance, one subsidy, one fare
    total_t = sum(running_t.values())
    print('branching rule: %s; total time used (10 instances): %s; average time of each instance %s'%(br,total_t,ave_running_time))
    keys = list(obj['leader'].keys())
    i, s, f = keys[0]
    print('results of (instance, subsidy, fare): (%s, %s, %s)'%(i, s, f))
    print('obj: %s'%({player:obj[player][i,s,f] for player in ['leader'] + [1,2,3]}))
    print('the optimized link fare are: %s'%{a:link_fare[a][i,s,f] for a in link_fare.keys()})
    print('\n')


with open(r'res/%s/json/results_%s.txt'%(net,info),'r') as f:
    for line in f.readlines():
        dic = line #string
res = eval(eval(dic))



