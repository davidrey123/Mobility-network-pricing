import time
import numpy as np
import pandas as pd
from copy import deepcopy
import json, ujson
import os
import sys

from model import algo_NDP
from utils import stat

#########
## investigate the impact of gcost of the reference mode 
#########

sep_fig = True
if __name__ == '__main__':
    #########################################################################################
    ## specify inputs ##
    instance_range  = np.arange(0,1,1)#[0]  # integer
    # subsidy_range = [30, 40, 50] # upper bound of subsidy
    subsidy_range = [40]
    # fare_range = [20, 30, 40, 50]#list( np.arange(10, 55, 30) ) # upper bound of fare [50]
    # fare_range = [40, 50]
    fare_range = [30, 40, 50]
    grs = [0.2, 0.4, 0.6, 0.8, 1, 1.2, 1.4] 
    # grs = [round(ds,1) for ds in grs]
    net = 'Toy'
    # branch_rules = ['max_violation','fmax_fmin_gcap','fmax_gcap_fmin','fmin_gcap_fmax','gcap_fmax_fmin']
    br = 'fmax_fmin_gcap'
    cases = ['seq','seq_base'] ## do not change the order. Because case order affects the res (differences) in the price of com 

    for case in cases: 
        #########################################################################################
        ## define paths to save results ##
        f_path = 'gr_analysis'
        folder_fig = 'res/%s/%s_%s/fig'%(f_path,net,case)
        folder_json = 'res/%s/%s_%s/json'%(f_path,net,case)
        for folder in [folder_fig, folder_json]:
            if not os.path.exists(folder):
                os.makedirs(folder)


        #########################################################################################
        ## specify outputs ##
        res = { 'setting':{}, 'res':{} }
        infeasible_set = {}
        t_start = time.time()

        for instance_i in instance_range:
            for subsidy_ub in subsidy_range:
                for fare_ub in fare_range:
                    result = {'link_res':{}, 'path_res':{}, 'obj_res':{}, 'convergence':{}, 'running_time':{}}
                    infeasible_set[instance_i, subsidy_ub, fare_ub] = []
                    for gr in grs:

                        ## specify net configurations ##
                        if net == 'Toy':
                            from config_Toy import process_net_data, params
                        else:
                            print('the config_net file of %s is not found'%net)
                        
                        ### seq case
                        if case == 'seq_base':
                            params['A_var'] =  {1:{(1,31),}, 2: {(1,32),}, 4: {(3,4),},}
                            params['not_foll'] = [2]
                        elif case == 'seq':
                            params['A_var'] =  {1:{(1,31),(3,4),}, 2: {(1,32),},}
                            params['not_foll'] = [2]
                        else:
                            print('please specify the case')
                        ### paral case
                        # if case == 'seq_base':
                        #     params['A_var'] =  {1:{(1,31),}, 2: {(1,32),}, 4: {(3,4),},}
                            # params['not_foll'] = [4]
                        # elif case == 'seq':
                        #     params['A_var'] =  {1:{(1,31),(1,32),}, 4: {(3,4),},}
                            # params['not_foll'] = [4]
                        # else:
                        #     print('please specify the case')
                        ## result information
                        info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
                        
                        params['coef_G'] = gr
                        

                        t_start_each = time.time()
                        print('(instance, subsidy upper bound, fare upper bound, gcost_scale) = (%d, %.1f, %.1f, %.1f)'%(instance_i, subsidy_ub, fare_ub, gr))
                        data, params = process_net_data(instance_i, subsidy_ub, fare_ub, 2.0) # demand scale = 2.0
                        print(params)
                        ## --- solve the model --- ##
                        data['branching_rule'] = br
                        data['coef_G'] = gr  #  for minor modification
                        LB, gap, runtime, fopt, sopt, objs, link_flow, path_flow, path_gcost, tree, status, obj_bounds = algo_NDP(data)
                        # print('link-based fare',fopt)
                        # print('path-based subsidy',sopt)
                        ## --- process results --- ##
                        try:
                            if status != 'infeasible':
                                fopt_var = [fopt[a] for a_set in params['A_var'].values() for a in a_set]
                                print('fares: %s \nsubsidies: %s'%(stat(fopt_var), stat(list(sopt.values()))))
                                print('fares: %s \n subsidies: %s'%(fopt,sopt))
                                result['link_res'][gr] = {'fare_old':data['F_a'], 'fare':fopt, 'link_flow':link_flow}
                                result['path_res'][gr] = {'subsidy':sopt, 'path_flow':path_flow}
                                path_fare = {}
                                for OD in data['ODs']:
                                    for path in data['path_idx'][OD]:
                                        path_fare[(OD, path)] = sum(fopt[link] for link in data['path_data']['links_of_path'][OD][path])
                                result['path_res'][gr]['path_fare'] = path_fare
                        except:
                            infeasible_set[instance_i, subsidy_ub, fare_ub].append(gr)
                            print('results are not available. Please check the format of res or the problem is infeasible. %.2f'%gr)
                        ## --- obj results --- ##
                        result['obj_res'][gr] = {}
                        result['obj_res'][gr]['leader'] = LB
                        if objs != None:
                            for foll, val_ in objs.items():
                                result['obj_res'][gr][foll] = val_
                        else:
                            for foll in data['followers']:
                                result['obj_res'][gr][foll] = -1
                        ## --- obj bound results for convergence plot --- ##
                        result['convergence'][gr] = obj_bounds
                        ## --- running time --- ##
                        t_end_each = time.time()
                        result['running_time'][gr] = t_end_each - t_start_each

                    res['res'][instance_i, subsidy_ub, fare_ub] = result
                    res['setting'][instance_i, subsidy_ub, fare_ub] = {'params':params, 'data':data}
                    print('current results: ',result['obj_res'])
        print('-'*10,'\n infeasible gcost scales are: ', infeasible_set)

        t_end  = time.time()
        print('total time used: %.2f s'%(t_end-t_start))
        res['setting']['total_time_used'] =  round(t_end-t_start,2)
        res['setting']['subsidy_range'] = subsidy_range
        res['setting']['fare_range'] = fare_range
        res['setting']['grs'] = grs

        with open('%s/results_%s.txt'%(folder_json, info), 'w') as json_file:
            json_file.write(ujson.dumps(str(res)))
        print(' ---- obj results saved ---- ')


    sys.path.append('.../visual/visual_gr_analysis')
    ### visualization ###
    fig_info = {'net':net, 'ins':instance_i,'cases':cases,'br':br,'plot_path':True,'plot_convergence':False}
    from visual.visual_gr_analysis import visual_all_link, visual_the_price_of_competition
    visual_all_link.visual_all_link(fig_info)
    visual_the_price_of_competition.visual_the_price_of_competition(fig_info)
    if sep_fig == True: ## whether to save figures separately
        from visual.visual_gr_analysis import visual_all_link_separate, visual_the_price_of_competition_separate
        visual_all_link_separate.visual_all_link_separate(fig_info)
        visual_the_price_of_competition_separate.visual_the_price_of_competition_separate(fig_info)

