
import copy
from turtle import color
import numpy as np
import pandas as pd
import csv
import json
import os
import matplotlib.pyplot as plt

def process_zip_list(zip_list):
    x,y = [],[]
    for item in zip_list:
        x.append(item[0])
        y.append(item[1])
    return(x,y)

def visual_all_link(fig_info):

    #############################
    ##-- specify inputs --##
    net = fig_info['net']
    instance_i = fig_info['ins']
    cases = fig_info['cases']
    br = fig_info['br']
    ## visualization
    plot_path = fig_info['plot_path'] #False
    plot_convergence = fig_info['plot_convergence'] #False
    fig_size_ = (3.2, 2.4)
    #############################

    ## specify net configurations ##
    if net == 'Toy':
        from config_Toy import process_net_data, params
    else:
        print('the config_net file of %s is not found'%net)



    info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
    net0 = copy.deepcopy(net)
    # for case in ['seq_base','seq']:
    for case in cases:
        net = net0 + '_' + case
        with open(r'res/%s/json/results_%s.txt'%(net,info),'r') as f:
        # with open('res/%s/json/old_model/results_SF_mid_trips_K5_alpha_0005_%s.txt'%(net, br)) as f:
            for line in f.readlines():
                dic = line #string
        res = eval(eval(dic))

        subsidy_range = res['setting']['subsidy_range']
        fare_range = res['setting']['fare_range']
        demand_scales = res['setting']['demand_scales']
        params = res['setting'][instance_i,subsidy_range[0],fare_range[0]]['params']
        data = res['setting'][instance_i,subsidy_range[0],fare_range[0]]['data']
        followers = list(params['A_var'].keys())

        if len(params['not_foll']) != 0:
            followers = list(set(followers) - set(params['not_foll']))


        players = ['leader'] + followers

        folder_fig = 'res/%s/fig'%net
        folder_json = 'res/%s/json'%net
        folder_fig_path = 'res/%s/fig/path'%net
        folders = [folder_fig, folder_json, folder_fig_path] if plot_path==True else [folder_fig, folder_json]
        for folder in folders:
            if not os.path.exists(folder):
                os.makedirs(folder)

        #########################################################################################
        ###--- obj  ---###
        obj = {player:{} for player in players}
        for player in players:
            for s in subsidy_range:
                for fare in fare_range:
                    obj[player][instance_i, s, fare] = []
                    for dr in demand_scales:
                        try:
                            obj[player][instance_i, s, fare].append([dr, res['res'][instance_i,s,fare]['obj_res'][dr][player]])
                        except:
                            pass
        #-- obj of followers --#
        for s in subsidy_range:
            fig = plt.figure(figsize=(6,14))
            j = 1
            # s = subsidy_range[0]

            for foll in followers:
                ax = fig.add_subplot(len(followers)+2,1,j)
                for fare in fare_range:
                    x, y = process_zip_list(obj[foll][instance_i,s,fare])
                    idx = y.index(-1) if -1 in y else len(y)  ## delete value = -1 (abnomal values)
                    x, y = x[0:idx], y[0:idx]
                    plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.' )
                plt.ylabel('Profit of follower %s (HKD)'%foll)
                plt.xlabel('Demand scale')
                plt.legend()
                j+=1


            #-- total profit of all followers --#
            try:
                ax = fig.add_subplot(len(followers)+2,1,j)
                for fare in fare_range:
                    y_sum = np.zeros(100)
                    for foll in followers:
                        x, y = process_zip_list(obj[foll][instance_i,s,fare])
                        idx = y.index(-1) if -1 in y else len(y)  ## delete value = -1 (abnomal values)
                        x, y = x[0:idx], y[0:idx]
                        y_sum[0:idx] += np.array(y)
                    plt.plot(x, y_sum[0:idx], label='$\overline{f}=%s$'%fare, linestyle='-.' )
                plt.ylabel('Total profits of followers (HKD)')
                plt.xlabel('Demand scale')
                plt.legend()
                j+=1
            except:
                pass

            #-- obj of the leader --#
            ax = fig.add_subplot(len(followers)+2,1,j)
            for fare in fare_range:
                x, y = process_zip_list(obj['leader'][instance_i,s,fare])
                idx = y.index(0) if  0 in y else len(y)  ## delete value = -1 (abnomal values)
                x, y = x[0:idx], y[0:idx]
                plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.' )
            plt.ylabel('Total riderships (trip)')
            plt.xlabel('Demand scale')
            plt.legend()
            j+=1

            # plt.show()
            plt.tight_layout()
            plt.savefig('%s/res_obj_instance_%s_subsidy_%s.png'%(folder_fig, instance_i, s))
            plt.close()

        print('*'*10,'Obj results are plotted','*'*10)

        #########################################################################################
        ###--- link res ---###
        A_var_set = {a for a_set in params['A_var'].values() for a in a_set}  # decision links
        A = data['links'] # all links

        link_fare, link_flow = {a:{} for a in A}, {a:{} for a in A}
        for a in A:
            for s in subsidy_range:
                for fare in fare_range:
                    link_fare[a][instance_i, s, fare] = []
                    link_flow[a][instance_i, s, fare] = []
                    for dr in demand_scales:
                        try:
                            link_fare[a][instance_i, s, fare].append([dr, res['res'][instance_i,s,fare]['link_res'][dr]['fare'][a]])
                            link_flow[a][instance_i, s, fare].append([dr, res['res'][instance_i,s,fare]['link_res'][dr]['link_flow'][a]])
                        except:
                            pass
        if net == 'Toy':
            A.remove((31,3)) ## hpyer links
            A.remove((32,3))
        check_list = A # or A_var_set
        for s in subsidy_range:
            fig = plt.figure(figsize=(4*len(check_list),12))
            i=1
            for a in check_list:
                ax = fig.add_subplot(3,len(check_list),i)
                for fare in fare_range:
                    x,y = process_zip_list(link_fare[a][instance_i,s,fare])
                    plt.plot(x, y, label='$\overline{f}=$ %s'%fare, linestyle='-.' )
                plt.ylabel('Link fare (HKD)')
                plt.xlabel('Demand scale \n\n link: %s'%str(a))
                plt.legend()
                i+=1

            for a in check_list:
                ax = fig.add_subplot(3,len(check_list),i)
                for fare in fare_range:
                    x,y = process_zip_list(link_flow[a][instance_i,s,fare])
                    plt.plot(x, y, label='$\overline{f}=$ %s'%fare, linestyle='-.' )
                plt.ylabel('Link flow (trip)')
                plt.xlabel('Demand scale \n\n link: %s'%str(a))
                plt.legend()
                i+=1

            for a in check_list:
                ax = fig.add_subplot(3,len(check_list),i)
                for fare in fare_range:
                    x,y = process_zip_list(link_flow[a][instance_i,s,fare])
                    y = np.array(y)/data['capacity'][a]
                    plt.plot(x, y, label='fare upper bound %s'%fare, linestyle='-.' )
                plt.ylabel('V/C (volume-capacity ratio)')
                plt.xlabel('Demand scale \n\n link: %s'%str(a))
                plt.legend()
                i+=1

            # plt.show()
            plt.tight_layout()
            plt.savefig('%s/res_link_instance_%s_subsidy_%s.png'%(folder_fig, instance_i, s))
            plt.close()

        print('*'*10,'Link results are plotted','*'*10)


        #########################################################################################
        ### convergence plots ###
        if plot_convergence == True:
            for s in subsidy_range:
                fig = plt.figure(figsize=(60,35))
                i = 1
                for fare in fare_range:
                    for dr in demand_scales:
                        ax = fig.add_subplot(len(fare_range), len(demand_scales), i)
                        obj_lb = res['res'][instance_i,s,fare]['convergence'][dr]['lb']
                        obj_ub = res['res'][instance_i,s,fare]['convergence'][dr]['ub']
                        plt.plot(range(1,len(obj_lb)+1), obj_lb, label='lower bound', linestyle='-',color='royalblue')
                        plt.scatter(range(1,len(obj_lb)+1), obj_lb, marker='o')
                        plt.plot(range(1,len(obj_ub)+1), obj_ub, label='upper bound', linestyle='--',color='coral')
                        plt.scatter(range(1,len(obj_ub)+1), obj_ub, marker='o')
                        plt.ylabel('Objective value of the leader')
                        plt.xlabel('Iteration')
                        plt.legend()
                        plt.title('(fare, Demand scale): (%.2f, %.2f)'%(fare,dr))
                        i += 1
                # plt.show()
                plt.tight_layout()
                plt.savefig('%s/res_convergence_instance_%s_subsidy_%s.png'%(folder_fig, instance_i, s))
                plt.close()



        #########################################################################################
        ###--- path res ---###
        if plot_path == True:
            R = data['ODs'] # instance specific OD set
            P = data['path_idx'] # instance specific path set
            path_subsidy = {(r,k): {} for r in R for k in P[r]}
            path_flow = copy.deepcopy(path_subsidy)
            path_total_subsidy = copy.deepcopy(path_subsidy)
            path_fare = copy.deepcopy(path_subsidy)
            for r in R:
                for k in P[r]:
                    for s in subsidy_range:
                        for fare in fare_range:
                            path_subsidy[r,k][instance_i,s,fare] = []
                            path_flow[r,k][instance_i,s,fare] = []
                            path_total_subsidy[r,k][instance_i,s,fare] = []
                            path_fare[r,k][instance_i,s,fare] = []
                            for dr in demand_scales:
                                # path_s = res['res'][instance_i,s,fare]['path_res'][dr]['subsidy'][r,k]
                                # path_f = res['res'][instance_i,s,fare]['path_res'][dr]['path_flow'][r,k]
                                # path_fare_ = res['res'][instance_i,s,fare]['path_res'][dr]['path_fare'][r,k]
                                # path_subsidy[r,k][instance_i,s,fare].append([dr, path_s])
                                # path_flow[r,k][instance_i,s,fare].append([dr, path_f])
                                # path_total_subsidy[r,k][instance_i,s,fare].append([dr, path_s*path_f])
                                # path_fare[r,k][instance_i,s,fare].append([dr, path_fare_])
                                try:
                                    path_s = res['res'][instance_i,s,fare]['path_res'][dr]['subsidy'][r,k]
                                    path_f = res['res'][instance_i,s,fare]['path_res'][dr]['path_flow'][r,k]
                                    path_fare_ = res['res'][instance_i,s,fare]['path_res'][dr]['path_fare'][r,k]
                                    path_subsidy[r,k][instance_i,s,fare].append([dr, path_s])
                                    path_flow[r,k][instance_i,s,fare].append([dr, path_f])
                                    path_total_subsidy[r,k][instance_i,s,fare].append([dr, path_s*path_f])
                                    path_fare[r,k][instance_i,s,fare].append([dr, path_fare_])
                                except:
                                    pass
            
            for s in subsidy_range:
                for r in R:
                    fig = plt.figure(figsize=(10,10))
                    i=1
                    for k in P[r]:
                        ax = fig.add_subplot(4,2,i)
                        for fare in fare_range:
                            x, y = process_zip_list(path_subsidy[r,k][instance_i,s,fare])
                            plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.')
                        plt.ylabel('Path subsidy (HKD)')
                        plt.xlabel('Demand scale \n\n path: %s'%str(data['path_data'][r][k]))
                        plt.legend()
                        i+=1
                    for k in P[r]:
                        ax = fig.add_subplot(4,2,i)
                        for fare in fare_range:
                            x, y = process_zip_list(path_flow[r,k][instance_i,s,fare])
                            plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.')
                        plt.ylabel('Path flow (Veh/hour)')
                        plt.xlabel('Demand scale \n\n path: %s'%str(data['path_data'][r][k]))
                        plt.legend()
                        i+=1
                    for k in P[r]:
                        ax = fig.add_subplot(4,2,i)
                        for fare in fare_range:
                            x, y = process_zip_list(path_total_subsidy[r,k][instance_i,s,fare])
                            plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.')
                        plt.ylabel('Total subsidy paid on path (HKD)')
                        plt.xlabel('Demand scale \n\n path: %s'%str(data['path_data'][r][k]))
                        plt.legend()
                        i+=1
                    for k in P[r]:
                        ax = fig.add_subplot(4,2,i)
                        for fare in fare_range:
                            x, y = process_zip_list(path_fare[r,k][instance_i,s,fare])
                            plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.')
                        plt.ylabel('Path fare (HKD)')
                        plt.xlabel('Demand scale \n\n path: %s'%str(data['path_data'][r][k]))
                        plt.legend()
                        i+=1
                    # plt.show()
                    plt.tight_layout()
                    plt.savefig('%s/res_path_O%d_D%d_path_%s_%s.png'%(folder_fig_path, r[0], r[1], instance_i, s))
                    plt.close()

            print('*'*10,'path results are plotted','*'*10)


    # print('*'*20, '\nAll plots are done. Figs were saved in %s\n'%(folder_fig), '*'*20)
    print('*'*20, '\nAll plots are done.', '*'*20)






















