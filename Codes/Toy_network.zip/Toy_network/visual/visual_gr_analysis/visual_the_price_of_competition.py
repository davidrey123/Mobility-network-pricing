
import copy
import numpy as np
import pandas as pd
import csv

import json
import os
import matplotlib.pyplot as plt

def process_zip_list(zip_list):
    x,y = [],[]
    for item in zip_list:
        x.append(item[0])
        y.append(item[1])
    return(x,y)

    ## results that can be discussed - with and without the competition
    ## 1. the differences between total ridership
    ## 2. the differences between total subsidy
    ## 3. the differences between the sum of the total profits of active followers
    ## 4. the differences between the average subsidy on demand

def visual_the_price_of_competition(fig_case):
    #############################
    ##-- specify inputs --##
    net = fig_case['net']
    instance_i = fig_case['ins']
    cases = fig_case['cases']
    br = fig_case['br']
    ## visualization
    plot_path = fig_case['plot_path'] #False
    plot_convergence = fig_case['plot_convergence'] #False
    #############################


    # if net == 'Toy':
    #     from config_Toy import params

    # res = {case:{} for case in cases}
    # info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
    # for case in cases:
    #     f_path = 'gr_analysis/'+ net + '_' + case
    #     with open(r'res/%s/json/results_%s.txt'%(f_path,info),'r') as f:
    #         for line in f.readlines():
    #             dic = line #string
    #     res[case] = eval(eval(dic)) # this is orignal dict with instance dict

    if net == 'Toy':
        from config_Toy import params
    res = {case:{} for case in cases}
    info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
    f_path = 'gr_analysis'
    for case in cases:
        with open(r'res/%s/%s_%s/json/results_%s.txt'%(f_path,net,case,info),'r') as f:
            for line in f.readlines():
                dic = line #string
        res[case] = eval(eval(dic)) # this is orignal dict with instance dict


    ### parse  results
    subsidy_range = res[cases[0]]['setting']['subsidy_range']
    # subsidy_range = [30,40,50]

    fare_range = res[cases[0]]['setting']['fare_range']
    grs = res[cases[0]]['setting']['grs']
    params = res[cases[0]]['setting'][instance_i,subsidy_range[0],fare_range[0]]['params']
    data = res[cases[0]]['setting'][instance_i,subsidy_range[0],fare_range[0]]['data']  ## carefully check the data. The data is different in the two settings
    followers = list(params['A_var'].keys())

    ##  setup folders
    extra_info = ''
    if 'sep' in cases[0] or 'sep' in cases[1]:
        extra_info = 'sep'
    else:
        extra_info = 'paral'
    if len(extra_info) != 0:
        folder_fig = 'res/%s/%s_price_of_com_%s/fig'%(f_path,net,extra_info)
        folder_json = 'res/%s/%s_price_of_com_%s/json'%(f_path,net,extra_info)
        folder_fig_path = 'res/%s/%s_price_of_com_%s/fig_sep/path'%(f_path,net,extra_info)
    else:
        folder_fig = 'res/%s/%s_price_of_com/fig'%(f_path,net)
        folder_json = 'res/%s/%s_price_of_com/json'%(f_path,net)
        folder_fig_path = 'res/%s/%s_price_of_com/fig_sep/path'%(f_path,net)
        print('results might be overwritten')
    folders = [folder_fig, folder_json, folder_fig_path] if plot_path==True else [folder_fig, folder_json]
    for folder in folders:
        if not os.path.exists(folder):
            os.makedirs(folder)


    ## get total ridership
    obj = {case: {'leader':{}} for case in cases}
    for case in cases:
        for s in subsidy_range:
            for fare in fare_range:
                obj[case]['leader'][instance_i, s, fare] = []
                for dr in grs:
                    try:
                        obj[case]['leader'][instance_i, s, fare].append([dr, res[case]['res'][instance_i,s,fare]['obj_res'][dr]['leader']])
                    except:
                        pass


    R = data['ODs'] # instance specific OD set
    P = data['path_idx'] # instance specific path set
    path_subsidy = {}

    for case in cases:
        path_subsidy[case] = {(r,k): {} for r in R for k in P[r]}
    path_flow = copy.deepcopy(path_subsidy)
    path_total_subsidy = copy.deepcopy(path_subsidy)
    sum_path_total_subsidy = {case:{} for case in cases}
    sum_path_total_ridership = {case:{} for case in cases}
    for case in cases:
        for s in subsidy_range:
            for fare in fare_range:
                sum_path_total_subsidy[case][instance_i,s,fare] = np.zeros(len(grs))
                sum_path_total_ridership[case][instance_i,s,fare] = np.zeros(len(grs))
                for r in R:
                    for k in P[r]:
                        path_subsidy[case][r,k][instance_i,s,fare] = []
                        path_flow[case][r,k][instance_i,s,fare] = []
                        path_total_subsidy[case][r,k][instance_i,s,fare] = []
                        for dr in grs:
                            try:
                                path_s = res[case]['res'][instance_i,s,fare]['path_res'][dr]['subsidy'][r,k]
                                path_f = res[case]['res'][instance_i,s,fare]['path_res'][dr]['path_flow'][r,k]
                                path_subsidy[case][r,k][instance_i,s,fare].append([dr, path_s])
                                path_flow[case][r,k][instance_i,s,fare].append([dr, path_f])
                                path_total_subsidy[case][r,k][instance_i,s,fare].append([dr, path_s*path_f])
                            except:
                                pass
                        _, path_total_subsidy_ = process_zip_list(path_total_subsidy[case][r,k][instance_i,s,fare])
                        min_len = min(len(path_total_subsidy_), len(sum_path_total_subsidy[case][instance_i,s,fare]))
                        # print('-'*20, s,fare) if min_len < 5 else None
                        sum_path_total_subsidy[case][instance_i,s,fare][:min_len] += np.array(path_total_subsidy_[:min_len])
                    
                        _, path_flow_ = process_zip_list(path_flow[case][r,k][instance_i,s,fare])
                        min_len = min(len(path_flow_), len(sum_path_total_ridership[case][instance_i,s,fare]))
                        sum_path_total_ridership[case][instance_i,s,fare][:min_len] += np.array(path_flow_[:min_len])




    ### The differences in total ridership
    fig = plt.figure(figsize=(10,3.5))
    j = 1
    for s in subsidy_range:
        ax = fig.add_subplot(1,len(subsidy_range),j)
        for fare in fare_range:
            y0 = sum_path_total_ridership[cases[0]][instance_i,s,fare]
            y1 = sum_path_total_ridership[cases[1]][instance_i,s,fare]
            min_len = min(len(y0),len(y1))
            x, y = grs[:min_len], np.array(y1[:min_len])-np.array(y0[:min_len])
            plt.plot(x, y, label='$\overline{f}=%s$'%fare, linestyle='-.' )
        plt.ylabel('Diff in total ridership (trip)')
        plt.xlabel('$E_g$')
        plt.legend()
        j+=1

    plt.tight_layout()
    plt.savefig('%s/diff_in_total_ridership.png'%(folder_fig))
    # plt.savefig('%s/The differences in total ridership_instance_%s_subsidy_%s.png'%(folder_fig, instance_i, s))
    plt.close()


    ### average subsidy paid on per trip
    # fig_size_ = (5.2, 3.5)
    # fig = plt.figure(figsize=fig_size_)
    ave_subsidy_per_trip = copy.deepcopy(sum_path_total_subsidy)
    for case in cases:
        fig = plt.figure(figsize=(10,3.5))
        i=1
        for s in subsidy_range: 
            ax = fig.add_subplot(1,len(subsidy_range),i)
            for fare in fare_range:
                total_ridership = list(sum_path_total_ridership[case][instance_i,s,fare])
                idx = total_ridership.index(0) if 0 in total_ridership else len(total_ridership)  ## delete value = -1 (abnomal values)
                ave_subsidy_per_trip[case][instance_i,s,fare] = sum_path_total_subsidy[case][instance_i,s,fare][:idx] / np.array(total_ridership[:idx])
                plt.plot(grs[:idx], ave_subsidy_per_trip[case][instance_i,s,fare][:idx], label= '$\overline{f}=%s$'%fare, linestyle='-.')
            plt.ylabel('Ave subsidy per trip ($/trip)')
            plt.xlabel('$E_g$')
            plt.legend()
            i+=1
        plt.tight_layout()
        plt.savefig('%s/ave_subsidy_per_trip_%s.png'%(folder_fig, case))
        plt.close()


    ### total subsidy
    # fig_size_ = (5.2, 3.5)
    # fig = plt.figure(figsize=fig_size_)
    fig = plt.figure(figsize=(13,10.5))
    j = 1
    for case in cases:
        i=1
        for s in subsidy_range: 
            ax = fig.add_subplot(3,len(subsidy_range),i+(j-1)*len(subsidy_range))
            for fare in fare_range:
                total_ridership = list(sum_path_total_ridership[case][instance_i,s,fare])
                idx = total_ridership.index(0) if 0 in total_ridership else len(total_ridership)  ## delete value = -1 (abnomal values)
                plt.plot(grs[:idx],sum_path_total_subsidy[case][instance_i,s,fare][:idx], label= '$\overline{f}=%s$'%fare, linestyle='-.')
            plt.ylabel('%s \n Total subsidy (S)'%case)
            plt.xlabel('$E_g$')
            plt.legend()
            i+=1
        j+=1
    i=1
    for s in subsidy_range: 
        ax = fig.add_subplot(3,len(subsidy_range),i+(j-1)*len(subsidy_range))
        for fare in fare_range:
            total_ridership = list(sum_path_total_ridership[case][instance_i,s,fare])
            idx = total_ridership.index(0) if 0 in total_ridership else len(total_ridership)  ## delete value = -1 (abnomal values)
            ### two operators minus one operator
            delta_s = sum_path_total_subsidy[cases[1]][instance_i,s,fare][:idx] - sum_path_total_subsidy[cases[0]][instance_i,s,fare][:idx]
            plt.plot(grs[:idx],delta_s, label= '$\overline{f}=%s$'%fare, linestyle='-.')
        plt.ylabel('%s-%s \n Diff in total subsidy ($)'%(cases[1],cases[0]))
        plt.xlabel('$E_g$')
        plt.legend()
        i += 1

    plt.tight_layout()
    plt.savefig('%s/total_subsidy.png'%(folder_fig))
    plt.close()



    ### the difference between the average subsidy paid on per trip
    ### with and without subsidy
    ave_subsidy_per_trip = copy.deepcopy(sum_path_total_subsidy)
    fig = plt.figure(figsize=(10,3.5))
    i=1
    for s in subsidy_range: 
        ax = fig.add_subplot(1,len(subsidy_range),i)
        for fare in fare_range:
                total_ridership = list(sum_path_total_ridership[cases[0]][instance_i,s,fare])
                idx0 = total_ridership.index(0) if 0 in total_ridership else len(total_ridership) 
                # ave_subsidy_per_trip[cases[0]][instance_i,s,fare] = np.array(sum_path_total_subsidy[cases[0]][instance_i,s,fare][:idx0]) / np.array(total_ridership[:idx0])
                y0 = np.array(sum_path_total_subsidy[cases[0]][instance_i,s,fare][:idx0]) / np.array(total_ridership[:idx0])

                total_ridership = list(sum_path_total_ridership[cases[1]][instance_i,s,fare])
                idx1 = total_ridership.index(0) if 0 in total_ridership else len(total_ridership)
                # ave_subsidy_per_trip[cases[1]][instance_i,s,fare] = np.array(sum_path_total_subsidy[cases[1]][instance_i,s,fare][:idx1]) / np.array(total_ridership[:idx1])
                y1 = np.array(sum_path_total_subsidy[cases[1]][instance_i,s,fare][:idx1]) / np.array(total_ridership[:idx1])

                min_len = min(idx0, idx1)
                delta = np.array(y1[:min_len]) - np.array(y0[:min_len])

                plt.plot(grs[:min_len],delta, label='$\overline{f}=%s$'%fare, linestyle='-.')
        plt.ylabel('Diff in ave subsidy per trip\n($/trip)')
        plt.xlabel('$E_g$')
        plt.legend()
        i+=1

    plt.tight_layout()
    plt.savefig('%s/differences_in_average_subsidy_per_trip.png'%(folder_fig))
    plt.close()

    print('All plots are done!')


















