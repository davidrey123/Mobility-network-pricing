
import numpy as np
import ujson
from get_net_data import get_net_data
from net_config import net_config
import os

##  basic settings  ##

params = {
    'net': 'Toy',
    'A_var': {
        # 1: { (1,31),},
        3: { (1,31), (3,4),},
        4: { (1,32), },
    },
    'not_foll':[ ], # followers that are without decisions
    ##-- how competitive of reference mode is to the mean cost of that of all paths of a OD pair
    'coef_G': 1/2, # 1.1  ## the smaller, the more competitive, 1/3
    'coef_U': 1.5,  ## 1.5 the value of utility of path, OD-based, coef_U * max(path_gcost)
    'beta': 120/60, # value of time 
    'alpha': 0.008, # 0.008,0.00
    'epsilon': 0.000005, ## penalty in leader's obj. sometimes needs to change
    ## assume followers: {0: bus, 1: auto, 2: ride-sourcing, 3: others}
    'oper_flag':'link_based', # or 'foll_based'
    'base_fare':{
        'link_based': {(1,31):4.0, (1,32):3.0, (2,3):6.0, (3,4):2.0, (31,3):1.0, (32,3):1.0},
        'foll_based': {0: 1.0, 1: 2.0, 2: 6.0, 3: 4.0, 4: 3.0 },
    },
    'mean_oper_cost':{
        'link_based': {(1,31):2.0, (1,32):1.5, (2,3):3, (3,4):1.0, (31,3):0.5, (32,3):0.5},
        'foll_based': {0: 0.5, 1: 1.0, 2: 3, 3: 2, 4: 1.5 },
        },
    'COV': 0.00001, # the coefficiency of variation of operational cost
    'regenerate_instances': False, # if the mean_oper_cost is changed, turn it to True
    'num_of_instances': 10,
    'K': 30, # number of K-shortest paths
}


## define paths to save results ##
folder_fig = 'res/%s/fig'%(params['net'])
folder_json = 'res/%s/json'%(params['net'])
for folder in [folder_fig, folder_json]:
    if not os.path.exists(folder):
        os.makedirs(folder)


def instance_generator(oper_cost, COV, num):
    np.random.seed(2022)
    instances = {}
    for i in range(num):
        instances[i] = {}
        for key, val in oper_cost.items():
            instances[i][key] = { key_: np.random.normal(val[key_], COV*val[key_]) for key_ in val.keys()}
    with open('%s/instances.txt'%folder_json, 'w') as json_file:
        json_file.write(ujson.dumps(str(instances)))
    print('-'*10, 'instances were generated and saved', '-'*10)
    return (instances)


import itertools
def check_link_set(A_var_set):
    common_links = {}
    folls = list(A_var_set.keys())
    for pair in itertools.combinations(folls,2):
        com_links = A_var_set[pair[0]] & A_var_set[pair[1]]
        if com_links != set():
            common_links[pair] = com_links
    # if len(common_links.keys()) == 0:
    #     print('links are operated by multiple followers. followers: common links %s'%(common_links))
    return (common_links)


def process_net_data(instance_i, subsidy_ub, fare_ub, demand_r):
    ## check link operators: no common links of different followers
    common_links =  check_link_set(params['A_var'])
    if common_links != {}:
        print('links are operated by multiple followers. followers: common links %s'%(common_links))
        return (None, None)
    ## get the base net data
    data = get_net_data(net=params['net'], path='net_data/', K=params['K'])
    data['beta'], data['alpha'], data['epsilon'] = params['beta'], params['alpha'], params['epsilon']
    for OD, demand_ in data['demand'].items():
        data['demand'][OD] = demand_ * demand_r

    ## load instances
    if params['regenerate_instances'] == False:
        try:
            print('-'*10,'loading follower intances','-'*10)
            with open(r'%s/instances.txt'%folder_json,'r') as f:
                for line in f.readlines():
                    dic = line #string
            instances = eval(eval(dic))
        except:
            print('-'*10,'no follower intance was found and generating instances','-'*10)
            instances = instance_generator(params['mean_oper_cost'], COV=params['COV'], num=params['num_of_instances'])
    else:
        print('-'*10,' regenerating instances','-'*10)
        instances = instance_generator(params['mean_oper_cost'], COV=params['COV'], num=params['num_of_instances'])
    params['oper_cost'] = instances[instance_i]
    
    ## bound settings
    data['bounds'] = {'fare': [0, fare_ub], 'subsidy': [0, subsidy_ub] }

    ## network configuration
    data = net_config(data, params)
    return (data, params)






