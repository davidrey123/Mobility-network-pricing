import time
import copy
import numpy as np
from docplex.mp.model import Model
from utils import stat
from GS import gauss_seidel

#---check complementarity slackness conditions and determine branching variable
def check_CS(data,SP,CStype,tol,branching_rule):
    A_var_set = {a for a_set in data['A_var'].values() for a in a_set}
    bilevelopt = True
    maxviolation = 0.0
    list_violated = {cs:[] for cs in CStype}
    for a in A_var_set:
        for cs in CStype:
            if SP['CS'][a][cs] > tol:
                list_violated[cs].append((a,SP['CS'][a][cs]))
                bilevelopt = False
            if SP['CS'][a][cs] > maxviolation:
                maxviolation = SP['CS'][a][cs]
                bvar = (a,cs) #bvar is a link and a type
                
    print('bilevelopt',bilevelopt)
    
    if bilevelopt == True:
        return bilevelopt,None
            
    elif branching_rule == 'max_violation':
        return bilevelopt,bvar
        
    elif branching_rule == 'fmax_fmin_gcap':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['fmin']) > 0:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')
        else:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        return bilevelopt,bvar
    
    elif branching_rule == 'fmax_gcap_fmin':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')        
        return bilevelopt,bvar    

    ### newly added
    elif branching_rule == 'fmin_gcap_fmax':
        if len(list_violated['fmin']) > 0:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=False)
            bvar = (list_violated['fmin'][0][0],'fmin')  
        elif len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        else:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')  
        return bilevelopt,bvar

    elif branching_rule == 'gcap_fmax_fmin':        
        if len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')                
        elif len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')            
        return bilevelopt,bvar
    
    else:
        print('no valid branching rule specified')
        return          
    
     
#---node selection rule: best bound first search
def node_selection(candidates,tree):
    temp = []
    for i in candidates:
        # temp.append([i, tree[tree[i]['parent']]['UB']])
        temp.append([i, tree[i]['UB']])
    temp = sorted(temp, key=lambda x: x[1], reverse=True)
    # print('temp-\n\n:', temp)
    out = []
    for item in temp:
        out.append([tree[item[0]], item[0]])
    return(out)

#---branching rule: branch on max violated CS constraint
# only happen if it is feasible but not bilevel optimal and upper bound is greater than lower bound. 
def branch(SP,can,tree,bvar):
    
    cnt = len(tree)-1

    if bvar[1] == 'gcap': ## type of CS
        SP['children'].append(cnt+1)
        cap0 = copy.deepcopy(SP['cap0'])
        cap0.append(bvar[0])
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':cap0,'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        SP['children'].append(cnt+2)
        lbd0 = copy.deepcopy(SP['lbd0'])
        lbd0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':lbd0,'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmin':
        SP['children'].append(cnt+1)
        fmin0 = copy.deepcopy(SP['fmin0'])
        fmin0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':fmin0,'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        SP['children'].append(cnt+2)
        nul0 = copy.deepcopy(SP['nul0'])
        nul0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':nul0,
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmax':
        SP['children'].append(cnt+1)
        fmax0 = copy.deepcopy(SP['fmax0'])
        fmax0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':fmax0,'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        SP['children'].append(cnt+2)
        nuu0 = copy.deepcopy(SP['nuu0'])
        nuu0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':nuu0,'s':{},'f':{},'CS':{}}  
   
    return tree


#---relaxed single-level reformulation
def solve_RNDP(data,SP,CStype):
    RNDP = Model(name='RNDP',log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    al = data['alpha'] 
    us = data['ub_s']
    ls = data['lb_s']
    uf = data['ub_f']
    lf = data['lb_f']
    beta = data['beta']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']
    epsilon = data['epsilon']

    A_var_set = {a for a_set in data['A_var'].values() for a in a_set} # decision links

    s = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    lbd = {a: RNDP.continuous_var() for a in A}
    f = {a: RNDP.continuous_var() for a in A_var_set}  # only for decision links
    nul = {a: RNDP.continuous_var() for a in A_var_set}
    nuu = {a: RNDP.continuous_var() for a in A_var_set}
    for a in A_foll[0]:
        f[a] = data['F_a'][a] # set constant to non-decision links

    ### no-decision links
    # if len(data['not_foll']) != 0:
    #     for not_foll in data['not_foll']:
    #         for a in A_foll[not_foll]:
    #             RNDP.add_constraint(f[a] <= data['F_a'][a] )
    #             RNDP.add_constraint(f[a] >= data['F_a'][a] - 0.1**6)

    for r in R:
        RNDP.add_constraint(sum(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(s[r,k] <= us[r,k])
            RNDP.add_constraint(s[r,k] >= ls[r,k])

    followers  = list(data['A_var'].keys()) # only followers with decision links. foll 0 not included
    for foll in followers:
        for a in data['A_var'][foll]:
            temp = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a]
                                         - sum(f[b] for b in L[r][k] if b != a) - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in data['A_var'][foll])))
                                        for k in P[r]) for r in R)
            RNDP.add_constraint(temp - nuu[a] + nul[a] == 0)
            # RNDP.add_constraint(temp - nuu[a] + nul[a] <= 0 + 0.1**5)

    ############# flow conservation
    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a]) ## capacity constraint
        RNDP.add_constraint(lbd[a] >= 0)
    for a in A_var_set:
        RNDP.add_constraint(f[a] <= uf[a])
        RNDP.add_constraint(f[a] >= lf[a])
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        
    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['cap0']:
        RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R) == C[a])
    for a in SP['lbd0']:
        RNDP.add_constraint(lbd[a] == 0)
    for a in SP['fmin0']:
        RNDP.add_constraint(f[a] == lf[a])
    for a in SP['nul0']:
        RNDP.add_constraint(nul[a] == 0)
    for a in SP['fmax0']:
        RNDP.add_constraint(f[a] == uf[a])
    for a in SP['nuu0']:
        RNDP.add_constraint(nuu[a] == 0)
    
    ### --- objective function
    proportion = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    ### --- obj 1: original obj
    # leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R)

    # ### seq penalty good
    pen = epsilon
    # pen = 0.00005
    # if Q[(1,4)] >= 2.7*3000 and Q[(1,4)] <= 2.9*3000 or Q[(1,4)] >= 4.2*3000 and Q[(1,4)] <= 4.4*3000:
    #     if data['ub_f'][(1,31)]==40 and data['ub_s'][(1,4),0]==30:# or data['ub_f'][(1,31)]==40:
    #         pen = 0.005
    # if Q[(1,4)] >= 4.2*3000 and Q[(1,4)] <= 4.4*3000:
    #     if data['ub_f'][(1,31)]==40 and data['ub_s'][(1,4),0]==40 or data['ub_f'][(1,31)]==40 and data['ub_s'][(1,4),0]==50:
    #         pen = 0.005
    # if Q[(1,4)] >= 2.7*3000 and Q[(1,4)] <= 3.0*3000:
    #     if data['ub_f'][(1,31)]==40 and data['ub_s'][(1,4),0]==30:# or data['ub_f'][(1,31)]==40:
    #         pen = 0.2
    leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R) - pen*sum(Q[r]*s[r,k]**2 for k in [1] for r in [(1,4)] )
    # leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R) - pen*sum(s[r,k]**2 for k in P[r] for r in R )

    RNDP.maximize(leader_obj )

    RNDP.parameters.threads = 1
    # RNDP.parameters.simplex.display = 2
    # RNDP.parameters.barrier.display = 2
    # RNDP.parameters.output = 2
    # RNDP.parameters.simplex.tolerances.optimality = 1e-4
    RNDP.parameters.lpmethod = 0
    # RNDP.parameters.BarDisplay = 1
    # print(RNDP.parameters)
    RNDP.parameters.timelimit = 3600
    sol = RNDP.solve()
    print('status\t%s' % RNDP.solve_details.status)
    print('time  \t%s' % RNDP.solve_details.time)
    # if RNDP.solve_details.status == 'infeasible':
    if RNDP.solve_details.status != 'optimal':
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        # if RNDP.solve_details.status == 'dual objective limit exceeded':
        #     SP['active'] = False
        return SP    
    print('obj   \t%s' % RNDP.objective_value)
  
    # grab the results
    sopt = {(r,k):RNDP.solution.get_value(s[r,k]) for r in R for k in P[r]}
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt = {a:RNDP.solution.get_value(f[a]) for a in A_var_set}
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A_var_set}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A_var_set}
    link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
    path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(proportion[r,k]) for r in R for k in P[r]}
    for a in A_foll[0]:
        fopt[a] = data['F_a'][a] # set constant to no-decision links

    gcap, CS = {}, {}
    for a in A_var_set:
        gcap[a] = np.abs(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R) - C[a])
        #capacity constraint
        CStemp = {}    
        for cs in CStype:
            if cs == 'gcap':
                CStemp[cs] = gcap[a]*lbdopt[a]
                #print(a,cs,gcap[a],lbdopt[a])
            elif cs == 'fmin':
                CStemp[cs] = np.abs(fopt[a] - lf[a])*nulopt[a]
                #print(a,cs,np.abs(fopt[a] - lf[a]),nulopt[a])
            elif cs == 'fmax':
                CStemp[cs] = np.abs(fopt[a] - uf[a])*nuuopt[a]
                #print(a,cs,np.abs(fopt[a] - uf[a]),nuuopt[a])
        CS[a] = CStemp
    
    SP['UB'] = RNDP.objective_value
    SP['s'] = sopt
    SP['f'] = fopt
    SP['CS'] = CS
    SP['link_flow'] = link_flow_opt ## flow on links
    SP['foll_obj'] = { foll: sum( fopt[a] * link_flow_opt[a] for a in A_foll[foll] ) for foll in followers} ## obj of followers
    SP['path_flow'] = path_flow_opt ## flow on paths
    SP['path_gcost'] = {} ## generalized cost of path
    for r in R:
        for k in P[r]:
            SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]
    SP['solve_status'] = RNDP.solve_details.status
    return SP


def single_task(data, SP, can, CStype):
    if SP['solved'] == False:
        SP = solve_RNDP(data,SP,CStype)
        SP['solved'] = True
        print('solved RNDP')
        SP['solve_status'] = 'feasible'
    else:
        print('not solved?')
        SP['solve_status'] = 'infeasible'
    return (SP, can)

import multiprocessing
def paral_slove_RNDP(data,SP_can_list,CStype,num_can):
    if len(SP_can_list) >= 2:
        num_cpu = multiprocessing.cpu_count() # number of cpu
        pool = multiprocessing.Pool(num_cpu)
        paral_input = []
        for i in range(min(num_can,len(SP_can_list))):
            paral_input.append([data,SP_can_list[i][0],SP_can_list[i][1],CStype])
        output = pool.starmap(single_task, paral_input)
        pool.close()
        pool.join()
    else:
        SP, can = single_task(data,SP_can_list[0][0],SP_can_list[0][1], CStype) # the one with maximum UB
        output = [[SP, can]]
    return(output)


# from GS import gauss_seidel, solve_TSP
#---solve NDP with Branch and Bound
def algo_NDP(data):
    converged = False
    nit = 0
    node = 0
    gap = 1.0*float('inf')
    UB = 1e9
    LB = 0
    tol = 1e-4
    CStype = ['gcap','fmin','fmax']
    sopt = {}
    fopt = {}
    tree = {0:{'parent':0,'children':[],'solved':False,'active':True,'LB':None,'UB':1e8,
               'cap0':[],'lbd0':[],'fmin0':[],'nul0':[],'fmax0':[],'nuu0':[],'s':{},'f':{},'CS':{}}}
    candidates = [0]
    t0 = time.time()
    timelimit = 3600

    obj_bounds = {'lb':[],'ub':[]}
    
    #---specify the branching rule
    # max_violation: branches on most violated CS constraint
    # fmax_fmin_gcap: branches on most violated CS constraint of fmax type, then fmin, then gcap
    # fmax_gcap_fmin: branches on most violated CS constraint of fmax type, then gcap, then fmin
    # gcap_fmax_fmin: branches on most violated CS constraint of gcap type, then fmax, then fmin
    
    branching_rule = data['branching_rule']

    #---on/off swith and counter for triggering the Gauss-Seidel heuristic
    GS = False # False
    trigger_GS = 30 
    n_GS = trigger_GS
    
    print('branching_rule:',branching_rule)
    print('\n---NDP---------------------------------')
    bilevelopt = False
    while converged == False:  
        n_GS += 1
    
        #---select subproblem SP to explore
        SP_can_list = node_selection(candidates,tree)
        # print('-'*20,'\n',SP_can_list)
        paral_len = 1 #6 # num of nodes to be solved in parallel
        len_ = -1 if len (SP_can_list) < paral_len else paral_len
        print('selected nodes and UB are:%s'%([{item[1]: item[0]['UB']} for item in SP_can_list[0:len_] ]))
        # print([item[0]['UB'] for item in SP_can_list])
        SP_can_res = paral_slove_RNDP(data,SP_can_list,CStype,paral_len)
        # print('selected nodes and UB are:%s'%([{item[1]: tree[item[1]]['UB']} for item in SP_can_res ]))
        #---if SP is not solved, solve SP
        for SP, can in SP_can_res:
            #---check if all CS conditions are verified
            if SP['UB'] != 'infeasible':
                bilevelopt,bvar = check_CS(data,SP,CStype,tol,branching_rule)            
                if bilevelopt == True:
                    SP['LB'] = SP['UB']
                    ##*********save the optimal SP
                    SPopt = copy.deepcopy(SP)

                    #---if new LB is better than incumbent, update LB and solution
                    if SP['LB'] > LB:
                        print('update LB')
                        LB = SP['LB']
                        sopt = SP['s']
                        fopt = SP['f']
                        #---prune tree with new LB
                        for i in tree:
                            if tree[i]['active'] == True and tree[i]['UB'] <= LB:
                                tree[i]['active'] = False         
                #---if local UB > best bilevelopt solution, branch on bvar else prune tree
                elif SP['UB'] > LB:
                    tree = branch(SP,can,tree,bvar)
            SP['active'] = False
            tree[can]['active'] = False

        
        #---start Gauss-Seidel (GS) heuristic------------------
        # try to find LB using GS method on GNEP(s)
        # tuning of the parameters is needed
        if GS == True and bilevelopt == False and n_GS >= trigger_GS and SP['UB'] != 'infeasible':
            for SP,_ in SP_can_res:
                n_GS = 0
                conv_GS,LB_GS,f_GS = gauss_seidel(data,SP)
                if conv_GS == True:
                    print('==> Gauss-Seidel LB',LB_GS)
                    SP['LB'] = LB_GS

                    #---if new LB is better than incumbent, update LB and solution
                    if SP['LB'] > LB:
                        print('*** update LB (GS) ***')
                        LB = SP['LB']
                        sopt = SP['s']
                        fopt = f_GS
                        #---prune tree with new LB
                        cnt_pruned = 0
                        for i in tree:
                            if tree[i]['active'] == True and tree[i]['UB'] <= LB:
                                tree[i]['active'] = False
                                cnt_pruned += 1
                        if cnt_pruned > 0:
                            print('pruned nodes',cnt_pruned)
                # break           
            #---end heuristic------------------------------------

        #---update candidate list
        print('>>> %d >>> %d >>> %d >>> %d' % (nit,len(tree),len(candidates),can))
        candidates = [i for i in tree if tree[i]['active']==True]
        if len(candidates) == 0:
            #-- convergence by inspection
            converged = True
            UB = LB
            gap = 0
            print('\n>>convergence by inspection')
        else:
            UB = max([tree[i]['UB'] for i in candidates])
            lb_UB = min([tree[i]['UB'] for i in candidates])
            # print([tree[i]['UB'] for i in candidates])
            print('the num of active trees: %d; the LB: %.2f; the range of current UBs: [%.2f, %.2f]' %(len(candidates),LB,lb_UB,UB))
            if len(list(fopt.values())) != 0:
                # print(list(fopt.values()))
                print('fopt: %s \nsopt: %s'%(stat(list(fopt.values())), stat(list(sopt.values()))))
            if (UB - LB)/UB < gap:
                gap = (UB - LB)/UB

        obj_bounds['lb'].append(LB)
        obj_bounds['ub'].append(UB)

        if gap<=tol:
            #--convergence by optimality gap
            print('\n>>convergence by optimality gap', gap)
            break
                    
        if (time.time() - t0) >= timelimit:
            print('\n>> time limit')
            break
        nit += 1


    runtime = min(time.time() - t0,timelimit)
    print('*'*30)
    print('time\t%.2f' % (runtime))
    print('OPT\t%.3f' % (LB))
    print('GAP\t%.3f' % (gap))
    print('nit\t%d' % (nit))
    print('*'*30)
    

    try:
        print('current objective of followers are: ', SPopt['foll_obj'])
        return LB, gap, runtime, SPopt['f'], SPopt['s'], SPopt['foll_obj'], SPopt['link_flow'], SPopt['path_flow'], SPopt['path_gcost'], tree, SPopt['solve_status'], obj_bounds
    except:
        return LB, gap, runtime, fopt, sopt, None, None, None, None, tree, SP['solve_status'], obj_bounds











