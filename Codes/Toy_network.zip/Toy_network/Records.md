Issues of the "dual objective limit exceeded"
-   when increasing alpha or K (the num of k-shortest paths) to a larger value, this issue will occur more frequently
One possible reason is that it pushes constraints (31c) to be binding for some links.
$A^_k - \alpha (s-sum(fa))=0$
-   when 'dual objective limit exceeded' occurs,  you can check the details by setting the output flag in 'cplex.model()' to be ture
-   The model.parameter.lpmethod specifies the mathmatical method used. Details can be referred to http://www-eio.upc.edu/lceio/manuals/cplex-11/html/usrcplex/solveLP2.html 
-   For Barrier lpmethod used, the 'dual objective limit exceeded' might be recovered to 'Barrier dual objective limit exceeded'. Since the dual objective is unbounded, the primal problem is infeasible. This means when this error occurs, the problem of this ndoe is 'infeasible'. But we can catch this status by 'infeasible' instead 'dual objective limit exceeded'.
-   



Parameter tunning record
-   Increasing alpha, the running time becomes longer --> optimized fares are pushed far away from the initial bounds --> fares become more sensitive.
-   Increasing K (K shortest paths), numbers of links of followers, numbers of followers --> the dimensions of the problem increase.



Parameter in the penalty-based objective function
Gamma has (sometimes significant) impacts on the penalty-based objctive function. if results fluctuate, adjusting gamma in the penalty-based function in model.py can alleviate this problem.


Using the parallel algorithm might lead to different solutions. But the solution (obj) of the leader is unique?



Result Record
1. when demand keeps increasing, the subsidy will decrease and further link fare will also decrease (to fully utilize the link capacity). However, this will lead a reduction in followers' profit while the obj of the leader is unchanged.

2. penalty function does not work in branching rule 0 (max vialtion).

3. paralell computing has an inclination to get the solutions close to the fare (or) subsidy upper bound. This is because it can get an optimal solution quickly.



