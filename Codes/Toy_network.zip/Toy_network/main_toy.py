import time
import numpy as np
import pandas as pd
from copy import deepcopy
import json, ujson
import os

from model import algo_NDP
from utils import stat


cases = ['seq']
if __name__ == '__main__':
    #########################################################################################
    ## specify inputs ##
    instance_range  = np.arange(0,1,1)#[0]  # integer
    # subsidy_range = [20,30,40] # upper bound of subsidy
    subsidy_range = [30, 40, 50] # upper bound of subsidy
    # subsidy_range = [30]
    # fare_range = [20, 30, 40, 50]#list( np.arange(10, 55, 30) ) # upper bound of fare [50]
    # fare_range = [40, 50]
    fare_range = [30, 40, 50]
    # fare_range = [ 20, 30, 40 ]
    # fare_range = [50]
    # demand_scales = [3.1]
    demand_scales = list( np.arange(0.1, 5.1, 0.3) )
    net = 'Toy' # 'Toy', 'ND', 'SF'
    branch_rules = ['max_violation','fmax_fmin_gcap','fmax_gcap_fmin','fmin_gcap_fmax','gcap_fmax_fmin']
    br = branch_rules[1] # 1,0,3,----


    #########################################################################################
    ## define paths to save results ##
    folder_fig = 'res/%s/fig'%net
    folder_json = 'res/%s/json'%net

    for folder in [folder_fig, folder_json]:
        if not os.path.exists(folder):
            os.makedirs(folder)
    ## specify net configurations ##
    if net == 'Toy':
        from config_Toy import process_net_data, params
    else:
        print('the config_net file of %s is not found'%net)

    ## result information
    info = '%s_mid_trips_K%s_alpha_%s_%s'%(net,params['K'],params['alpha'],br)
    #########################################################################################
    ## specify outputs ##
    res = { 'setting':{}, 'res':{} }
    infeasible_set = {}
    t_start = time.time()



    for instance_i in instance_range:
        for subsidy_ub in subsidy_range:
            for fare_ub in fare_range:
                result = {'link_res':{}, 'path_res':{}, 'obj_res':{}, 'convergence':{}, 'running_time':{}}
                infeasible_set[instance_i, subsidy_ub, fare_ub] = []
                for demand_r in demand_scales:
                    t_start_each = time.time()
                    print('(instance, subsidy upper bound, fare upper bound, demand ratio) = (%d, %.1f, %.1f, %.1f)'%(instance_i, subsidy_ub, fare_ub, demand_r))
                    data, params = process_net_data(instance_i, subsidy_ub, fare_ub, demand_r)
                    print(params)
                    ## --- solve the model --- ##
                    data['branching_rule'] = br
                    LB, gap, runtime, fopt, sopt, objs, link_flow, path_flow, path_gcost, tree, status, obj_bounds = algo_NDP(data)
                    # print('link-based fare',fopt)
                    # print('path-based subsidy',sopt)
                    ## --- process results --- ##
                    try:
                        if status != 'infeasible':
                            fopt_var = [fopt[a] for a_set in params['A_var'].values() for a in a_set]
                            print('fares: %s \nsubsidies: %s'%(stat(fopt_var), stat(list(sopt.values()))))
                            print('fares: %s \n subsidies: %s'%(fopt,sopt))
                            result['link_res'][demand_r] = {'fare_old':data['F_a'], 'fare':fopt, 'link_flow':link_flow}
                            result['path_res'][demand_r] = {'subsidy':sopt, 'path_flow':path_flow}
                            path_fare = {}
                            for OD in data['ODs']:
                                for path in data['path_idx'][OD]:
                                    path_fare[(OD, path)] = sum(fopt[link] for link in data['path_data']['links_of_path'][OD][path])
                            result['path_res'][demand_r]['path_fare'] = path_fare
                    except:
                        infeasible_set[instance_i, subsidy_ub, fare_ub].append(demand_r)
                        print('results are not available. Please check the format of res or the problem is infeasible. %.2f'%demand_r)
                    ## --- obj results --- ##
                    result['obj_res'][demand_r] = {}
                    result['obj_res'][demand_r]['leader'] = LB
                    if objs != None:
                        for foll, val_ in objs.items():
                            result['obj_res'][demand_r][foll] = val_
                    else:
                        for foll in data['followers']:
                            result['obj_res'][demand_r][foll] = -1
                    ## --- obj bound results for convergence plot --- ##
                    result['convergence'][demand_r] = obj_bounds
                    ## --- running time --- ##
                    t_end_each = time.time()
                    result['running_time'][demand_r] = t_end_each - t_start_each

                res['res'][instance_i, subsidy_ub, fare_ub] = result
                res['setting'][instance_i, subsidy_ub, fare_ub] = {'params':params, 'data':data}
                print('current results: ',result['obj_res'])
    print('-'*10,'\n infeasible demand ratio cases are: ', infeasible_set)


    t_end  = time.time()
    print('total time used: %.2f s'%(t_end-t_start))
    res['setting']['total_time_used'] =  round(t_end-t_start,2)
    res['setting']['subsidy_range'] = subsidy_range
    res['setting']['fare_range'] = fare_range
    res['setting']['demand_scales'] = demand_scales

    with open('%s/results_%s.txt'%(folder_json, info), 'w') as json_file:
        json_file.write(ujson.dumps(str(res)))
    print(' ---- obj results saved ---- ')


fig_info = {'net':net, 'ins':instance_i,'cases':cases,'br':br,'plot_path':True,'plot_convergence':False}
from visual import visual_all_link, visual_the_price_of_competition
visual_all_link.visual_all_link(fig_info)


