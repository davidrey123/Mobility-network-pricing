from lib2to3.pytree import convert
import time
import copy
import numpy as np
from docplex.mp.model import Model
from psutil import virtual_memory
from utils import stat
import time
import pandas as pd

#---check complementarity slackness conditions and determine branching variable
def check_CS(data,SP,CStype,tol,branching_rule):
    A_var_set = {a for a_set in data['A_var'].values() for a in a_set}
    bilevelopt = True
    maxviolation = 0.0
    list_violated = {cs:[] for cs in CStype}
    for a in A_var_set:
        for cs in CStype:
            if SP['CS'][a][cs] > tol:
                list_violated[cs].append((a,SP['CS'][a][cs]))
                bilevelopt = False
            if SP['CS'][a][cs] > maxviolation:
                maxviolation = SP['CS'][a][cs]
                bvar = (a,cs) #bvar is a link and a type
    
    violated_len = [len(list_violated[cs]) for cs in CStype]
    if sum(violated_len)==0:
        bilevelopt = True
        print('found a solution without violating CS')
    # print('bilevelopt',bilevelopt)
    
    if bilevelopt == True:
        return bilevelopt,None,violated_len
            
    elif branching_rule == 'max_violation':
        print(bvar)
        return bilevelopt,bvar,violated_len
        
        
    elif branching_rule == 'fmax_fmin_gcap':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['fmin']) > 0:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')
        else:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        return bilevelopt,bvar,violated_len
    
    elif branching_rule == 'fmax_gcap_fmin':        
        if len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        elif len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')        
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')        
        return bilevelopt,bvar,violated_len

    elif branching_rule == 'gcap_fmax_fmin':        
        if len(list_violated['gcap']) > 0:            
            list_violated['gcap'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['gcap'][0][0],'gcap')                
        elif len(list_violated['fmax']) > 0:
            list_violated['fmax'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmax'][0][0],'fmax')            
        else:
            list_violated['fmin'].sort(key=lambda y: y[1], reverse=True)
            bvar = (list_violated['fmin'][0][0],'fmin')            
        return bilevelopt,bvar,violated_len
    
    else:
        print('no valid branching rule specified')
        return bilevelopt,None,None
    
     
#---node selection rule: best bound first search
def node_selection(candidates,tree):
    temp = []
    for i in candidates:
        temp.append([i, tree[tree[i]['parent']]['UB']])
        # temp.append([i, tree[i]['UB']])
    temp = sorted(temp, key=lambda x: x[1], reverse=True)
    # print('temp-\n\n:', temp)
    out = []
    for item in temp:
        out.append([tree[item[0]], item[0]])
    return(out)

#---branching rule: branch on max violated CS constraint
# only happen if it is feasible but not bilevel optimal and upper bound is greater than lower bound. 
def branch(SP,can,tree,bvar):
    
    cnt = len(tree)-1
    tree[can] = copy.deepcopy(SP)
    if bvar[1] == 'gcap': ## type of CS
        tree[can]['children'].append(cnt+1)
        cap0 = copy.deepcopy(SP['cap0'])
        cap0.append(bvar[0])
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':cap0,'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        lbd0 = copy.deepcopy(SP['lbd0'])
        lbd0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':lbd0,'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmin':
        tree[can]['children'].append(cnt+1)
        fmin0 = copy.deepcopy(SP['fmin0'])
        fmin0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':fmin0,'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        nul0 = copy.deepcopy(SP['nul0'])
        nul0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':nul0,
                       'fmax0':SP['fmax0'],'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}}  
        
    elif bvar[1] == 'fmax':
        tree[can]['children'].append(cnt+1)
        fmax0 = copy.deepcopy(SP['fmax0'])
        fmax0.append(bvar[0])        
        tree[cnt+1] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':fmax0,'nuu0':SP['nuu0'],'s':{},'f':{},'CS':{}} 
        tree[can]['children'].append(cnt+2)
        nuu0 = copy.deepcopy(SP['nuu0'])
        nuu0.append(bvar[0])        
        tree[cnt+2] = {'parent':can,'children':[],'solved':False,'active':True,'LB':None,'UB':SP['UB'],
                       'cap0':SP['cap0'],'lbd0':SP['lbd0'],'fmin0':SP['fmin0'],'nul0':SP['nul0'],
                       'fmax0':SP['fmax0'],'nuu0':nuu0,'s':{},'f':{},'CS':{}}  
   
    return tree


#---relaxed single-level reformulation
def solve_RNDP(data,SP,CStype):
    RNDP = Model(name='RNDP',log_output=False)
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    al = data['alpha'] 
    us = data['ub_s']
    ls = data['lb_s']
    uf = data['ub_f']
    lf = data['lb_f']
    beta = data['beta']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_foll']
    ga = data['gamma_a']

    A_var_set = {a for a_set in data['A_var'].values() for a in a_set} # decision links

    s = {(r,k): RNDP.continuous_var() for r in R for k in P[r]}
    lbd = {a: RNDP.continuous_var() for a in A}
    f = {a: RNDP.continuous_var() for a in A_var_set}  # only for decision links
    nul = {a: RNDP.continuous_var() for a in A_var_set}
    nuu = {a: RNDP.continuous_var() for a in A_var_set}
    for a in A_foll[0]:
        f[a] = data['F_a'][a] # set constant to non-decision links

    for r in R:
        RNDP.add_constraint(sum(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for k in P[r]) <= 1)
        for k in P[r]:
            RNDP.add_constraint(B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) >= 0)
            RNDP.add_constraint(s[r,k] <= sum(f[a] for a in L[r][k]))
            RNDP.add_constraint(s[r,k] <= us[r,k])
            RNDP.add_constraint(s[r,k] >= ls[r,k])

    followers  = list(data['A_var'].keys()) # only followers with decision links. foll 0 not included
    for foll in followers:
        for a in data['A_var'][foll]:
            temp = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - 2*f[a] + ga[a] + lbd[a]
                                         - sum(f[b] for b in L[r][k] if b != a) - sum((f[b] - ga[b]) for b in L[r][k] if b != a and b in data['A_var'][foll])))
                                        for k in P[r]) for r in R)
            RNDP.add_constraint(temp - nuu[a] + nul[a] == 0)

    ############# flow conservation
    flows = {}
    for a in A: # for all links in the network
        flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R)
        RNDP.add_constraint(flows[a] <= C[a])
        RNDP.add_constraint(lbd[a] >= 0)
    for a in A_var_set:
        RNDP.add_constraint(f[a] <= uf[a])
        RNDP.add_constraint(f[a] >= lf[a])
        RNDP.add_constraint(nul[a] >= 0)
        RNDP.add_constraint(nuu[a] >= 0)
        
    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['cap0']:
        RNDP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k]))) for k in P[r]) for r in R) == C[a])
    for a in SP['lbd0']:
        RNDP.add_constraint(lbd[a] == 0)
    for a in SP['fmin0']:
        RNDP.add_constraint(f[a] == lf[a])
    for a in SP['nul0']:
        RNDP.add_constraint(nul[a] == 0)
    for a in SP['fmax0']:
        RNDP.add_constraint(f[a] == uf[a])
    for a in SP['nuu0']:
        RNDP.add_constraint(nuu[a] == 0)
    
    ### --- objective function
    proportion = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
    leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R)
    ### --- obj 2: penalized obj
    pen_coef = 0.00000  ### --- pen_coef = 0 --> original obj
    pen = pen_coef*sum(sum(s[r,k]*Q[r]*(B[r,k] + al*s[r,k] ) for k in P[r]) for r in R )
    # leader_obj = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R) - pen*sum(sum(Q[r]*(s[r,k]*s[r,k]*B[r,k] + al*s[r,k]**2 ) for k in P[r]) for r in R )
    leader_obj = leader_obj - pen 
    RNDP.maximize(leader_obj)

    RNDP.parameters.threads = 1
    # RNDP.parameters.simplex.display = 2
    # RNDP.parameters.barrier.display = 2
    # RNDP.parameters.output = 2
    RNDP.parameters.simplex.tolerances.optimality = 1e-6
    RNDP.parameters.lpmethod = 0
    # RNDP.parameters.BarDisplay = 1
    # print(RNDP.parameters)
    RNDP.parameters.timelimit = 10800
    sol = RNDP.solve()
    print('status\t%s' % RNDP.solve_details.status)
    print('time  \t%s' % RNDP.solve_details.time)
    # if RNDP.solve_details.status == 'infeasible':
    if RNDP.solve_details.status != 'optimal':
        SP['UB'] = 'infeasible'
        SP['s'] = {}
        SP['f'] = {}
        SP['CS'] = {}
        return SP
    objopt = RNDP.solution.get_value(leader_obj)
    print('obj   \t%s' %objopt)
  
    # grab the results
    sopt = {(r,k):RNDP.solution.get_value(s[r,k]) for r in R for k in P[r]}
    lbdopt = {a:RNDP.solution.get_value(lbd[a]) for a in A}
    fopt = {a:RNDP.solution.get_value(f[a]) for a in A_var_set}
    for a in A_foll[0]:
        fopt[a] = data['F_a'][a] # set constant to no-decision links
    nulopt = {a:RNDP.solution.get_value(nul[a]) for a in A_var_set}
    nuuopt = {a:RNDP.solution.get_value(nuu[a]) for a in A_var_set}



    gcap, CS = {}, {}
    for a in A_var_set:
        gcap[a] = np.abs(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(sopt[r,k] - sum(fopt[b] for b in L[r][k]))) for k in P[r]) for r in R) - C[a])
        CStemp = {}    
        for cs in CStype:
            if cs == 'gcap':
                CStemp[cs] = gcap[a]*lbdopt[a]
                #print(a,cs,gcap[a],lbdopt[a])
            elif cs == 'fmin':
                CStemp[cs] = np.abs(fopt[a] - lf[a])*nulopt[a]
                #print(a,cs,np.abs(fopt[a] - lf[a]),nulopt[a])
            elif cs == 'fmax':
                CStemp[cs] = np.abs(fopt[a] - uf[a])*nuuopt[a]
                #print(a,cs,np.abs(fopt[a] - uf[a]),nuuopt[a])
        CS[a] = CStemp
    
    SP['UB'] = objopt
    SP['s'] = sopt
    SP['f'] = fopt
    SP['CS'] = CS
    SP['solve_status'] = RNDP.solve_details.status
    if RNDP.solve_details.status == 'optimal':
        link_flow_opt = {a:RNDP.solution.get_value(flows[a]) for a in A}
        path_flow_opt = {(r,k): Q[r]*RNDP.solution.get_value(proportion[r,k]) for r in R for k in P[r]}
        SP['link_flow'] = link_flow_opt ## flow on links
        SP['foll_obj'] = { foll: sum( fopt[a] * link_flow_opt[a] for a in A_foll[foll] ) for foll in followers} ## obj of followers
        SP['path_flow'] = path_flow_opt ## flow on paths
        SP['path_gcost'] = {} ## generalized cost of path
        for r in R:
            for k in P[r]:
                SP['path_gcost'][(r,k)] = sum( fopt[a] for a in L[r][k] ) + beta*path_data[r][k]['travel_time'] - sopt[r,k]
    return SP


def single_task(data, SP, can, CStype):
    if SP['solved'] == False:
        SP = solve_RNDP(data,SP,CStype)
        SP['solved'] = True
        print('solved RNDP')
        SP['solve_status'] = 'feasible'
    else:
        print('not solved?')
        SP['solve_status'] = 'infeasible'
    return (SP, can)

import multiprocessing
def paral_slove_RNDP(data,SP_can_list,CStype,paral_len):
    if paral_len >= 2:
        num_cpu = multiprocessing.cpu_count() # number of cpu
        pool = multiprocessing.Pool(num_cpu)
        ## inputs for paraller task function
        paral_input = []
        for i in range(min(paral_len,len(SP_can_list))): # if the num of cans is less than paral len
            paral_input.append([data,SP_can_list[i][0],SP_can_list[i][1],CStype])
        output = pool.starmap(single_task, paral_input)
        pool.close()
        pool.join()
    else:
        SP, can = single_task(data,SP_can_list[0][0],SP_can_list[0][1], CStype) # the one with maximum UB
        output = [[SP, can]]
    return(output)


from utils import gauss_seidel, solve_TSP
#---solve NDP with Branch and Bound
def algo_NDP(data, params):
    converged = False
    nit = 0
    node = 0
    gap = 1e4 # 1.0*float('inf')
    UB = 1e8
    LB = 0
    tol = 1e-4
    CStype = ['gcap','fmin','fmax']
    sopt = {}
    fopt = {}
    tree = {0:{'parent':0,'children':[],'solved':False,'active':True,'LB':None,'UB':1e8,
               'cap0':[],'lbd0':[],'fmin0':[],'nul0':[],'fmax0':[],'nuu0':[],'s':{},'f':{},'CS':{}}}
    candidates = [0]
    t0 = time.time()
    timelimit = params['timelimit']

    obj_bounds = {'lb':[],'ub':[]}
    
    #---specify the branching rule
    # max_violation: branches on most violated CS constraint
    # fmax_fmin_gcap: branches on most violated CS constraint of fmax type, then fmin, then gcap
    # fmax_gcap_fmin: branches on most violated CS constraint of fmax type, then gcap, then fmin
    # gcap_fmax_fmin: branches on most violated CS constraint of gcap type, then fmax, then fmin
    
    branching_rule = data['branching_rule']

    #---on/off swith and counter for triggering the Gauss-Seidel heuristic
    GS = params['GS'] # True, False
    GS_activate = False
    DF_activate = False
    GS_freeze = params['GS_freeze'] 
    n_GS = GS_freeze
    LB_GS = 0
    paral_len = params['paral_len'] # num of nodes to be solved in parallel
    
    # can = candidates[0]
    print('branching_rule:',branching_rule)
    print('\n---NDP---------------------------------')
    bilevelopt = False
    depth_flag = 0
    DF_freeze = 0
    new_tree = {}

    ## placeholder
    skew, kurt = [0], [0]
    while converged == False: 
        ##---node selection
        if depth_flag < params['DF_depth'] and DF_freeze >= params['DF_freeze'] and DF_activate == True and params['depth_first'] == True:
            SP_can_list = node_selection(new_tree,tree)
            depth_flag += 1
            print('\n>>>>>> activate depth first search for %s time(s)\n'%(depth_flag))
        else:
            #---select subproblems to explore
            SP_can_list = node_selection(candidates,tree)
            depth_flag = 0
            DF_activate = False
            DF_freeze += 1

        ### trigger conditions for Depth first search
        if len(candidates)>0 and len(new_tree)>0:
            UB_list = [tree[i]['UB'] for i in candidates ]
            lb_UB, UB = min(UB_list), max(UB_list)
            if len(UB_list) >= 3:
                skew.append(round(pd.Series(UB_list).skew(),2))
                kurt.append(round(pd.Series(UB_list).kurt(),2))
            print('\n>>>>>')
            print('current UB statistics:\n ',stat(UB_list))
            print('UBs skew: %s'%(skew[-6:-1])) if len(skew)>5 else print('\n>>>>> UBs skew',skew[-1])
            print('UBs kurt: %s'%(kurt[-6:-1])) if len(kurt)>5 else print('>>>>> UBs kurt',kurt[-1])
            print('>>>>>')
            if params['depth_first'] == True:
                if abs(skew[-1]) > params['GS_tri_skew'] and abs(kurt[-1]) > params['GS_tri_kurt']:
                    if DF_freeze >= params['DF_freeze']:
                        print('activate depth first search for |skew| > %s and |kurt| > %s'%(params['GS_tri_skew'], params['GS_tri_kurt']))
                # if abs(skew[-1]) > params['GS_tri_skew'] or abs(kurt[-1]) > params['GS_tri_kurt']:  ###--------------------------------------changes changes changes
                #     if DF_freeze >= params['DF_freeze']:
                #         print('activate depth first search for |skew| > %s or |kurt| > %s'%(params['GS_tri_skew'], params['GS_tri_kurt']))
                # if (abs(skew[-1]) > 0.5*params['GS_tri_skew'] and abs(kurt[-1]) > 0.5*params['GS_tri_kurt']) or \
                #     abs(skew[-1]) > params['GS_tri_skew'] or abs(kurt[-1]) > params['GS_tri_kurt']:  ###--------------------------------------changes changes changes
                #     if DF_freeze >= params['DF_freeze']:
                #         print('activate depth first search for |skew| > %s or |kurt| > %s or both 0.5 skew and 0.5 kurt'%(params['GS_tri_skew'], params['GS_tri_kurt']))
                    DF_activate = True
                    # Early stop DF
                    if depth_flag >= params['DF_depth'] or max([tree[i]['UB'] for i in new_tree ]) <= np.mean(UB_list):
                        DF_freeze = 0
                        DF_activate = False
                        GS_activate = True
                        info = 'reaching maximum depth search iters' if depth_flag >= params['DF_depth'] else 'UBs of new trees are low'
                        print('\n>>>>>> stop depth first search. Reason: %s; freeze depth first search for %s time(s)\n'%(info,params['DF_freeze']))
                        if GS == True:
                            print('\n>>>>>> active GS for one time') 


        min_len = min( len (SP_can_list), paral_len )
        print('selected nodes are:%s'%([{SP_can_list[i][1]: SP_can_list[i][0]['UB']} for i in range(min_len)]))
        SP_can_res = paral_slove_RNDP(data, SP_can_list, CStype, paral_len)
        cur_trees = set(tree.keys())
        for SP, can in SP_can_res:
            ##---check if all CS conditions are verified
            tree[can] = copy.deepcopy(SP)
            if SP['UB'] != 'infeasible':
                ## update tree with new SP
                bilevelopt,bvar,violated_len = check_CS(data,SP,CStype,tol,branching_rule)            
                if bilevelopt == True:
                    # SP['LB'] = SP['UB']
                    ##*********save the optimal SP
                    SPopt = copy.deepcopy(SP)
                    converged = True
                    LB = SP['UB']
                    sopt = SP['s']
                    fopt = SP['f']
                    UB = LB
                    # #---if new LB is better than incumbent, update LB and solution
                    # if SP['LB'] > LB:
                    #     print('update LB')
                    #     LB = SP['LB']
                    #     sopt = SP['s']
                    #     fopt = SP['f']
                    #     #---prune tree with new LB
                    #     for i in tree:
                    #         if tree[i]['active'] == True and tree[i]['UB'] < LB:
                    #             tree[i]['active'] = False    
                #---if local UB > best bilevelopt solution, branch on bvar else prune tree
                elif SP['UB'] > LB:
                    tree = branch(SP,can,tree,bvar)
            SP['active'] = False
            tree[can]['active'] = False
        candidates = [i for i in tree if tree[i]['active']==True]
        if len(candidates) == 0:
            print('all trees are inactive in SP_can_res. Reason: all nodes are infeasible')

        new_tree = list(set(tree.keys()) - cur_trees)  ## candidates that are newly added
        new_tree = [i for i in new_tree if tree[i]['active']==True]
        if len(new_tree) == 0:
            DF_activate, GS_activate = False, False
            print('all new trees are pruned in depth first search. Returend to normal search')

        # ### trigger conditions for Depth first search
        # if len(candidates)>0 and len(new_tree)>0:
        #     UB_list = [tree[i]['UB'] for i in candidates ]
        #     lb_UB, UB = min(UB_list), max(UB_list)
        #     if len(UB_list) >= 3:
        #         skew.append(round(pd.Series(UB_list).skew(),2))
        #         kurt.append(round(pd.Series(UB_list).kurt(),2))
        #     print('\n>>>>>')
        #     print('current UB statistics:\n ',stat(UB_list))
        #     print('UBs skew: %s'%(skew[-6:-1])) if len(skew)>5 else print('\n>>>>> UBs skew',skew[-1])
        #     print('UBs kurt: %s'%(kurt[-6:-1])) if len(kurt)>5 else print('>>>>> UBs kurt',kurt[-1])
        #     print('>>>>>')
        #     if params['depth_first'] == True:
        #         # if abs(skew[-1]) > params['GS_tri_skew'] and abs(kurt[-1]) > params['GS_tri_kurt']:
        #         #     print('activate depth first search for |skew| > %s and |kurt| > %s'%(params['GS_tri_skew'], params['GS_tri_kurt']))
        #         if abs(skew[-1]) > params['GS_tri_skew'] or abs(kurt[-1]) > params['GS_tri_kurt']:  ###--------------------------------------changes changes changes
        #             print('activate depth first search for |skew| > %s or |kurt| > %s'%(params['GS_tri_skew'], params['GS_tri_kurt']))
        #             DF_activate = True
        #             # Early stop DF
        #             if depth_flag >= params['DF_depth'] or max([tree[i]['UB'] for i in new_tree ]) <= np.mean(UB_list):
        #                 DF_freeze = 0
        #                 DF_activate = False
        #                 GS_activate = True
        #                 info = 'reaching maximal depth search iters' if depth_flag >= params['DF_depth'] else 'UBs of new trees are low'
        #                 print('\n>>>>>> stop depth first search. Reason: %s; freeze depth first search for %s time(s)\n'%(info,params['DF_freeze']))
        #                 if GS == True:
        #                     print('\n>>>>>> active GS for one time') 

        ### trigger conditions for Gauss-Seidel heuristic
        if bilevelopt == False:
            list_violated_len = []
            for SP,_ in SP_can_res:
                if SP['UB'] != 'infeasible':
                    _,_,violated_len = check_CS(data,SP,CStype,tol,branching_rule)
                    list_violated_len.append(sum(violated_len))
                else:
                    list_violated_len.append(10**4)
            sp_idx = list_violated_len.index(min(list_violated_len))
            SP = SP_can_res[sp_idx][0] ## pick the one with minimum violated len

            A_var_set = {a for a_set in data['A_var'].values() for a in a_set}
            print('the min vialated len: %s; the num of total vars (not cons): %s'%(min(list_violated_len),len(A_var_set)))
            if min(list_violated_len) <= len(A_var_set)*params['GS_tri_len'] and GS == True:
                GS_activate = True
                print('activate GS. Reason: reaching min violated len: %s'%(min(list_violated_len)))
        #---start Gauss-Seidel (GS) heuristic------------------
        if n_GS <= GS_freeze:
            GS_activate = False
        if bilevelopt == False and SP['UB'] != 'infeasible':
            if GS == True and GS_activate == True:
                n_GS = 0
                conv_GS,LB_GS,f_GS = gauss_seidel(data,SP)
                if conv_GS == True:
                    print('==> Gauss-Seidel LB',LB_GS)
                    SP['LB'] = LB_GS
                    #---if new LB is better than incumbent, update LB and solution
                    if SP['LB'] > LB:
                        print('*** update LB (GS) ***')
                        LB = SP['LB']
                        sopt = SP['s']
                        fopt = f_GS
                        #---prune tree with new LB
                        cnt_pruned = 0
                        for i in tree:
                            if tree[i]['active'] == True and tree[i]['UB'] < LB:
                                tree[i]['active'] = False
                                cnt_pruned += 1
                        if cnt_pruned > 0:
                            print('pruned nodes',cnt_pruned)
                        SPopt = copy.deepcopy(SP)
                    if len(candidates)==0:
                        SPopt = copy.deepcopy(SP)
                        SPopt['f'] = f_GS
                        converged = True
                        print('\n>>convergence by inspection in GS')
                GS_activate = False
        #---end heuristic------------------------------------

        #---update candidate list
        print('>>> %d >>> %d >>> %d >>> %d' % (nit,len(tree),len(candidates),can))
        candidates = [i for i in tree if tree[i]['active']==True]
        if len(candidates) == 0 or converged == True:
            #-- convergence by inspection
            converged = True
            UB = LB
            gap = 0
            # SPopt = copy.deepcopy(SP)  ## set the opt SP as the last SP
            # temp = paral_slove_RNDP(data,[SP,can],CStype,1)
            # SPopt, _ = temp[0]
            print('\n>>convergence by inspection')
        else:
            ub_UB = max([tree[i]['UB'] for i in candidates])
            lb_UB = min([tree[i]['UB'] for i in candidates])
            print('the num of active trees: %d; the LB: %.2f; the range of current UBs: [%.2f, %.2f]; LB_GS (latest): %s' %(len(candidates),LB,lb_UB,ub_UB,LB_GS))
            if len(list(fopt.values())) != 0:
                print('fare and subsidy statisitcs:')
                print(stat(list(fopt.values())), stat(list(sopt.values())))
                gap = (ub_UB - LB)/ub_UB

        obj_bounds['lb'].append(LB)
        obj_bounds['ub'].append(UB)
        
        if gap<=tol:
            #--convergence by optimality gap
            print('\n>>convergence by optimality gap', gap)
            break    
        if (time.time() - t0) >= timelimit:
            print('\n>> time limit')
            break
        nit += 1; n_GS += 1

        print('\n>>>>>> keep running for %.2fs'%(time.time()-t0))    

    runtime = min(time.time() - t0,timelimit)
    print('*'*30)
    print('time\t%.2f' % (runtime))
    print('OPT\t%.3f' % (LB))
    print('GAP\t%.3f' % (gap))
    print('nit\t%d' % (nit))
    print('*'*30)
    
    # return LB, gap, runtime, nit, fopt, sopt, SPopt['foll_obj'], SPopt['link_flow'], SPopt['path_flow'], SPopt['path_gcost'], tree, SPopt['solve_status'], obj_bounds
    try:
        print('current objective of followers are: ', SPopt['foll_obj'])
        # return LB, gap, runtime, SPopt['f'], SPopt['s'], SPopt['foll_obj'], SPopt['link_flow'], SPopt['path_flow'], SPopt['path_gcost'], tree, SPopt['solve_status'], obj_bounds
        return LB, gap, runtime, nit, fopt, sopt, SPopt['foll_obj'], SPopt['link_flow'], SPopt['path_flow'], SPopt['path_gcost'], tree, SPopt['solve_status'], obj_bounds, skew, kurt
    except:
        return LB, gap, runtime, nit, fopt, sopt, None, None, None, None, tree, SP['solve_status'], obj_bounds, skew, kurt











