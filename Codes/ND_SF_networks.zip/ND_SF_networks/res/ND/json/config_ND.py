
import numpy as np
import ujson
from get_net_data import get_net_data
from net_config import net_config
import os

##  basic settings  ##
params = {
    'net': 'ND',
    'A_var': {
        # 1: { (1,2),(3,8),},
        # 2: { (1,4),(3,4),},

        # 1: { (1,2),(3,8),(2,5),(2,7),(8,11),},
        # 2: { (1,4),(3,4),(4,5),(4,8),(5,6),(8,9),},
        1: { (1,2),(2,7),(7,13),(3,8),(8,11),(11,12),},
        2: { (4,5),(5,6),(6,10),(4,8),(8,9),(9,10),(5,9),},
        # 2: { (1,4),(3,4),(4,5),(5,6),(6,10),(4,8),(8,9),(9,10),(5,9),},

        # 1: { (1,2),(2,7),(7,13),(3,8),(8,11),(11,12),},
        # 2: { (1,4),(3,4),},
        # 3: { (4,5),(5,6),(6,10),(4,8),(8,9),(9,10),(5,9),},
    
    },
    'not_foll':[  ], 
    ##-- how competitive of reference mode is to the mean cost of that of all paths of a OD pair
    'coef_G': 1/2, # 1.1  ## the smaller, the more competitive, 1/3
    'coef_U': 1.5,  ## the value of utility of path, OD-based, coef_U * max(path_gcost)
    'beta': 120/60, # value of time 
    'alpha': 0.008, #0.001
    ## assume followers: {0: bus, 1: auto, 2: ride-sourcing, 3: others}
    # 'base_fare':      { 0: 1.0, 1: 2.0, 2: 6.0, 3: 4.0 }, 
    # 'mean_oper_cost': { 0: 0.5, 1: 1.0, 2: 3.0, 3: 2.0 }, # operational_cost = 0.5 * base_fare
    'oper_flag':'foll_based', # or 'foll_based'
    'base_fare':{
        'link_based': {},
        'foll_based': { 0: 1.0, 1: 2.0, 2: 6.0, 3: 4.0, 4: 3.0 },
    },
    'oper_cost':{
        'link_based': {},
        'foll_based': { 0: 0.5, 1: 1.0, 2: 3.0, 3: 2.0, 4: 1.5 },
        },
    'K': 3, # number of K-shortest paths

    ##-- instance related --##
    'COV': 0.1, # the coefficiency of variation of operational cost 0.01
    'regenerate_instances': False, # if the oper_cost is changed, turn it to True
    'num_of_instances': 20,

    ## early condition to stop DF: if the max(UB of new trees) < 1/2 * UB_of_all(active)_trees, stop DF 
    ##-- computation related --##
    'paral_len': 8, # num of nodes branching and updating simultaneously
    'GS': True,
    'GS_freeze': 0,
    'GS_tri_len': 0.1, # (min violated vars / total vars) < GS_trigger len
    'GS_tri_skew': 3, # skewness to trigger GS
    'GS_tri_kurt': 3, # kurtosis to trigger GS
    'depth_first': True, # DF for short
    'DF_depth': 5, # num of branching steps in depth, 15
    'DF_freeze': 0, # num of steps to freeze the DF search (avoid exploring too far)
    # 'DF_trigger_width': 40000, # num of active trees
    # 'DF_trigger_density': {'percentile':75, 'den':0.5}, # the density of active trees whose UB over 75-th of BU > 'den' -->activate DF. 
    ## \\ if den = 0, the programme becomes a depth-first search algorithm
    # 'DF_trigger_UB_prop': 0.00005, # 0.015, activated too often, # if (UB - lb_UB)/UB <= this value --> activate DF
    'timelimit':3600,

}




## define paths to save results ##
folder_fig = 'res/%s/fig'%(params['net'])
folder_json = 'res/%s/json'%(params['net'])
for folder in [folder_fig, folder_json]:
    if not os.path.exists(folder):
        os.makedirs(folder)


def instance_generator(base_fare, oper_cost, COV, num):
    np.random.seed(2022)
    instances = {'base_fare':{},'oper_cost':{}}
    for key, val in zip(['base_fare','oper_cost'],[base_fare, oper_cost]):
        for i in range(num):
            instances[key][i] = {}
            for type, val_ in val.items():
                instances[key][i][type] = { i_: np.random.normal(val[type][i_], COV*val[type][i_]) for i_ in val_.keys()}
    with open('%s/instances.txt'%folder_json, 'w') as json_file:
        json_file.write(ujson.dumps(str(instances)))
    print('-'*10, 'instances were generated and saved', '-'*10)
    return (instances)



import itertools
def check_link_set(A_var_set):
    common_links = {}
    folls = list(A_var_set.keys())
    for pair in itertools.combinations(folls,2):
        com_links = A_var_set[pair[0]] & A_var_set[pair[1]]
        if com_links != set():
            common_links[pair] = com_links
    # if len(common_links.keys()) == 0:
    #     print('links are operated by multiple followers. followers: common links %s'%(common_links))
    return (common_links)


def process_net_data(instance_i, subsidy_ub, fare_ub, demand_r):
    ## check link operators: no common links of different followers
    common_links =  check_link_set(params['A_var'])
    if common_links != {}:
        print('links are operated by multiple followers. followers: common links %s'%(common_links))
        return (None, None)
    ## get the base net data
    data = get_net_data(net=params['net'], path='net_data/', K=params['K'])
    data['beta'], data['alpha'] = params['beta'], params['alpha']
    for OD, demand_ in data['demand'].items():
        data['demand'][OD] = demand_ * demand_r

    ## load instances
    if params['regenerate_instances'] == False:
        try:
            print('-'*10,'loading follower instances','-'*10)
            with open(r'%s/instances.txt'%folder_json,'r') as f:
                for line in f.readlines(): 
                    dic = line #string
            instances = eval(eval(dic))
        except:
            print('-'*10,'no follower intance was found and generating instances','-'*10)
            instances = instance_generator(params['base_fare'], params['oper_cost'], COV=params['COV'], num=params['num_of_instances'])
    else:
        print('-'*10,' regenerating instances','-'*10)
        instances = instance_generator(params['base_fare'], params['oper_cost'], COV=params['COV'], num=params['num_of_instances'])
    params['oper_cost'] = instances['oper_cost'][instance_i]
    params['base_fare'] = instances['base_fare'][instance_i]
    
    ## bound settings
    data['bounds'] = {'fare': [0, fare_ub], 'subsidy': [0, subsidy_ub] }

    ## network configuration
    data = net_config(data, params)
    return (data, params)






