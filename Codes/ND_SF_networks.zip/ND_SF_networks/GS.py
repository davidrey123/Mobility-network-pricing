from asyncio import constants
from docplex.mp.model import Model
import numpy as np

def gauss_seidel(data,SP): 

    #---initialization of Gauss-Seidel        
    s = SP['s']   
    f = SP['f']
    
    followers = list(data['A_var'].keys())    
       
    nit = 0
    maxit = 10
    obj_TSP_it = [] 
    conv_GS = False
    
    while nit < maxit:
        
        obj_TSP = []
        OK = True
        
        for foll in followers:
            obj,f = solve_TSP(data,SP,f,s,foll)
            
            if obj == None:
                OK = False
                break
            else:
                obj_TSP.append(obj)
         
        if OK == False:
            break
        
        else:
            #---check convergence between last two iterations
            obj_TSP_it.append(obj_TSP)
            if nit >= 1:
                if np.allclose(obj_TSP_it[-2], obj_TSP_it[-1], rtol=1e-4):
                    conv_GS = True
                    break        
        nit += 1
             
    if OK == False:
        print('--> Gauss-Seidel failed',nit)
        return False,None,None
        
    elif conv_GS == True:
        print('--> Gauss-Seidel converged',nit)
        
        R = data['ODs']
        P = data['path_idx']
        L = data['path_data']['links_of_path']
        B = data['B']
        al = data['alpha']   
        Q = data['demand']
        
        #---calculate corresponding LB 
        proportion = {(r,k): B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for r in R for k in P[r]}
        # LB_GS = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R) - 0.000005*sum([s[r,k]**2 for r in R for k in P[r]])
        LB_GS = sum(sum(Q[r]*proportion[r,k] for k in P[r]) for r in R) ## please keep the obj the same as that in model.py.
        # foll_obj = {foll: i for foll,i in zip(followers,obj_TSP)}
        ## check feasibility
        # for r in R:
        #     if sum([B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) for k in P[r]]) > 1:
        #         print('--> GS log: feasibility conditions violated--total demand proportion is greater than 1')
        #         return False,None,None
        #     for k in P[r]:
        #         if B[r,k] + al*(s[r,k] - sum(f[a] for a in L[r][k])) < 0:
        #             print('--> GS log: feasibility conditions violated--demand proportion less than 0')
        #             return False,None,None
        #         if s[r,k] - sum(f[a] for a in L[r][k]) > 0:
        #             print('--> GS log: feasibility conditions violated-- subsidy greater than path fare')
        #             return False,None,None 
        return True,LB_GS,f
    else:
        print('--> Gauss-Seidel did not converge',nit)
        return False,None,None


def solve_TSP(data,SP,f,s,foll):
    
    R = data['ODs']
    P = data['path_idx']
    A = data['links']
    L = data['path_data']['links_of_path']
    Q = data['demand']
    de = data['delta']
    C = data['capacity']    
    B = data['B'] #A_r^k
    al = data['alpha'] 
    us = data['ub_s']
    ls = data['lb_s']
    uf = data['ub_f']
    lf = data['lb_f']
    beta = data['beta']
    path_data = data['path_data'] ## contains path index, links in path, and path length (travel time)
    A_foll = data['A_var']  ### decision link
    ga = data['gamma_a']

    not_solved = False

    A_var_set = {a for a_set in data['A_var'].values() for a in a_set} # decision links
    
    TSP = Model(name='TSP',log_output=False)
    ff = {a: TSP.continuous_var() for a in A_foll[foll]}
    
    flows = {}
    for a in A:
        flows[a] = sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]))) for k in P[r]) for r in R)
        TSP.add_constraint(flows[a] <= C[a])
        
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] <= uf[a])
            TSP.add_constraint(ff[a] >= lf[a])
            

    #---upper-level feasibility conditions
    ## len(*) != 0 ensures that not adding constraints for constant variables
    for r in R:
        if len([ff[b] for k in P[r] for b in L[r][k] if b in A_foll[foll]]) != 0: ## not adding constraints for constant variables
            total_prop = sum([B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]) ) for k in P[r]])
            TSP.add_constraint(total_prop <= 1)
            for k in P[r]:
                if len([ff[b] for b in L[r][k] if b in A_foll[foll]]) != 0: ## not adding constraints for constant variables
                    prop_rk = B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]))
                    TSP.add_constraint(prop_rk <= 1)
                    s_f = s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll])
                    TSP.add_constraint(s_f <= 0)



    #---complementarity slackness conditions at SP #branch and bound
    for a in SP['cap0']:
        TSP.add_constraint(sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]))) for k in P[r]) for r in R) == C[a])
    for a in SP['fmin0']:
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] == lf[a])
    for a in SP['fmax0']:
        if a in A_foll[foll]:
            TSP.add_constraint(ff[a] == uf[a])

    #---objective function
    foll_obj = sum((ff[a] - ga[a])*sum(sum(de[a,r,k]*Q[r]*(B[r,k] + al*(s[r,k] - sum(f[b] for b in L[r][k] if b not in A_foll[foll]) - sum(ff[b] for b in L[r][k] if b in A_foll[foll]))) for k in P[r]) for r in R) for a in A_foll[foll])
    TSP.maximize(foll_obj)
    
    TSP.parameters.threads = 4
    TSP.parameters.timelimit = 600
    sol = TSP.solve()
    
    if TSP.solve_details.status == 'infeasible' or not_solved == True:
        print('infeasible TSP',foll)
        return None,f
    
    else:
        #print('%s\t%.1f\t%.3f' % (foll,TSP.objective_value,TSP.solve_details.time))
              
        #---update the fare vector
        for a in A_foll[foll]:
            f[a] = TSP.solution.get_value(ff[a])  
            
        return TSP.objective_value,f
