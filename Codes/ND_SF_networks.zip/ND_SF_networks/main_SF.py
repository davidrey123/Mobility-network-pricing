import time
import numpy as np
import pandas as pd
from copy import deepcopy
import json, ujson
import os

from model import algo_NDP
from utils import stat

if __name__ == '__main__':
    #########################################################################################
    ## specify inputs ##
    instance_range  = list(np.arange(0,20,1))#[0]  # integer
    subsidy_range = [40] # upper bound of subsidy [200]
    fare_range = [40] #list( np.arange(10, 100, 30) ) # upper bound of fare [50]
    demand_ratios = list( np.arange(1.0, 1.1, 0.2) )
    net = 'SF' # "ND"
    branch_rules = ['max_violation','fmax_fmin_gcap','fmax_gcap_fmin','gcap_fmax_fmin']

    instance_range_temp = np.arange(0,20,1)
    for br in ['fmax_fmin_gcap','max_violation']:
        for case in [True,False]:
            #########################################################################################
            ## define paths to save results ##
            folder_fig = 'res/%s/fig'%net
            folder_json = 'res/%s/json'%net
            for folder in [folder_fig, folder_json]:
                if not os.path.exists(folder):
                    os.makedirs(folder)
            ## specify net configurations ##
            if net == 'SF':
                from config_SF import process_net_data, params
            elif net == 'ND':
                from config_ND import process_net_data, params
            else:
                print('the config_net file of %s is not found'%net)

            params['GS'], params['depth_first'] = case, case

            ## result information
            info = '%s_mid_trips_K%s_alpha_%s_%s_DF_%s_GS_%s'%(net,params['K'],params['alpha'],br,params['depth_first'],params['GS'])
            #########################################################################################
            try:
                ## reload data
                with open('res/%s/json/results_%s_%s.txt'%(net,info,params['paral_len']),'r') as f:
                    for line in f.readlines():
                        dic = line #string
                res = eval(eval(dic))
                print('reloading data from history')
            except:
                res = { 'setting':{}, 'res':{} }                         
            
            infeasible_set = {}
            t_start = time.time()
            for instance_i in instance_range_temp:
                for subsidy_ub in subsidy_range:
                    for fare_ub in fare_range:
                        result = {'link_res':{}, 'path_res':{}, 'obj_res':{}, 'convergence':{}, 'running_time':{}, 'iter':{}, 'gap':{}}
                        infeasible_set[instance_i, subsidy_ub, fare_ub] = []
                        for demand_r in demand_ratios:
                            t_start_each = time.time()
                            print('(instance, subsidy upper bound, fare upper bound, demand ratio) = (%d, %.1f, %.1f, %.1f)'%(instance_i, subsidy_ub, fare_ub, demand_r))
                            data, params = process_net_data(instance_i, subsidy_ub, fare_ub, demand_r)
                            print(params)
                            ## --- solve the model --- ##
                            data['branching_rule'] = br
                            LB, gap, runtime, nit, fopt, sopt, objs, link_flow, path_flow, path_gcost, tree, status, obj_bounds, skew, kurt = algo_NDP(data, params)
                            # print('link-based fare',fopt)
                            # print('path-based subsidy',sopt)
                            ## --- process results --- ##
                            try:
                                if status != 'infeasible':
                                    fopt_var = [fopt[a] for a_set in params['A_var'].values() for a in a_set]
                                    print('fares:\n',stat(fopt_var), '\n subsidy:\n', stat(list(sopt.values())))
                                    print('fares: %s \n subsidies: %s'%(fopt,sopt))
                                    result['link_res'][demand_r] = {'fare_old':data['F_a'], 'fare':fopt, 'link_flow':link_flow}
                                    result['path_res'][demand_r] = {'subsidy':sopt, 'path_flow':path_flow}
                                    path_fare = {}
                                    for OD in data['ODs']:
                                        for path in data['path_idx'][OD]:
                                            path_fare[(OD, path)] = sum(fopt[link] for link in data['path_data']['links_of_path'][OD][path])
                                    result['path_res'][demand_r]['path_fare'] = path_fare
                            except:
                                infeasible_set[instance_i, subsidy_ub, fare_ub].append(demand_r)
                                print('results are not available. Please check the format of res or the problem is infeasible. %.2f'%demand_r)
                            ## --- obj results --- ##
                            result['obj_res'][demand_r] = {}
                            result['obj_res'][demand_r]['leader'] = LB
                            if objs != None:
                                for foll, val_ in objs.items():
                                    result['obj_res'][demand_r][foll] = val_
                            else:
                                for foll in data['followers']:
                                    result['obj_res'][demand_r][foll] = -1
                            ## --- obj bound results for convergence plot --- ##
                            result['convergence'][demand_r] = obj_bounds
                            ## --- running time --- ##
                            t_end_each = time.time()
                            result['running_time'][demand_r] = t_end_each - t_start_each
                            result['iter'][demand_r] = nit
                            result['gap'][demand_r] = gap


                        res['res'][instance_i, subsidy_ub, fare_ub] = result
                        res['setting'][instance_i, subsidy_ub, fare_ub] = {'params':params, 'data':data, 'skew':skew, 'kurt':kurt}
                        print('current results: ',result['obj_res'])
            

                ### save res after each instance ###
                t_end  = time.time()
                print('total time used: %.2f s'%(t_end-t_start))
                res['setting']['total_time_used'] =  round(t_end-t_start,2)
                res['setting']['subsidy_range'] = subsidy_range
                res['setting']['fare_range'] = fare_range
                res['setting']['demand_ratios'] = demand_ratios
                res['setting']['instance_range'] = instance_range
                


                with open('%s/results_%s_%s.txt'%(folder_json, info, params['paral_len']), 'w') as json_file:
                    json_file.write(ujson.dumps(str(res)))
                print(' ---- obj results saved ---- ')
            print('-'*10,'\n infeasible demand ratio cases are: ', infeasible_set)

            with open('%s/results_%s_%ds_%s.txt'%(folder_json, info, res['setting']['total_time_used'],params['paral_len']), 'w') as json_file:
                json_file.write(ujson.dumps(str(res)))

    # import parse_res_computation

